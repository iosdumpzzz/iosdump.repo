//
//  DebsProjectMetadata.swift
//  Debs
//
//  Created by Z on 2025/10/13.
//

// 文件路径: Debs/Models/DebsProjectMetadata.swift
import Foundation

struct DebsProjectMetadata: Codable, Identifiable {
    var id: String { projectName }
    let projectName: String
    let iconData: Data?
    let compressionFormat: String?
    var architecture: String?
    var creationDate: Date?
    // ▼▼▼ 修正 #1：将 projectURL 属性加回来 ▼▼▼
    // 它只在程序运行时使用，不会被保存到文件中
    var projectURL: URL?
    
    // ▼▼▼ 修正 #2：添加 CodingKeys ▼▼▼
    // 这会告诉 Codable 只需要保存和读取 projectName 和 iconData，
    // 从而自动忽略 projectURL，避免了文件读写错误。
    enum CodingKeys: String, CodingKey {
        case projectName
        case iconData
        case compressionFormat
        case architecture
    }
}
