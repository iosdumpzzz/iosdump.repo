//
//  Package.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import Foundation

struct Package: Identifiable, Hashable, Codable { 
    var id = UUID()
    let name: String
    let version: String
    let architecture: String
    let maintainer: String
    let packageDescription: String
    let filename: String
    let iconPath: String?
    
    init(controlData: [String: String]) {
        self.name = controlData["Name"] ?? "Unknown"
        self.version = controlData["Version"] ?? "Unknown"
        self.architecture = controlData["Architecture"] ?? "unknown"
        self.maintainer = controlData["Author"] ?? (controlData["Maintainer"] ?? "")
        self.packageDescription = controlData["Description"] ?? "No description available."
        self.filename = controlData["Filename"] ?? ""
        self.iconPath = controlData["Icon"]
    }

    func iconURL(forSource source: Source) -> URL? {
        guard let iconPath = self.iconPath, !iconPath.isEmpty else {
            return nil
        }

        if let absoluteURL = URL(string: iconPath), absoluteURL.scheme != nil {
            return absoluteURL
        }

        return URL(string: iconPath, relativeTo: source.url)
    }
}
