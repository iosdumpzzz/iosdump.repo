//
//  FrameworkInfo.swift
//  Debs
//
//  Created by Z on 2025/10/11.
//

// 文件路径: Debs/Models/FrameworkInfo.swift
import Foundation

struct FrameworkInfo: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let path: String
    // 指向解压后文件的临时URL，用于后续导出
    let tempURL: URL
}
