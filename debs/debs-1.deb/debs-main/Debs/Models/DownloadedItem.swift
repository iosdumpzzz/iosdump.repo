//
//  DownloadedItem.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import Foundation

struct DownloadedItem: Codable, Identifiable {
    var id: String { fileName }

    let fileName: String
    
    let package: Package
    
    let source: Source
}
