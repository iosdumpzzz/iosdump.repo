//
//  SearchablePackage.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import Foundation

struct SearchablePackage: Codable, Identifiable {
    
    var id: UUID { package.id }
    
    let package: Package
    let source: Source
    
}
