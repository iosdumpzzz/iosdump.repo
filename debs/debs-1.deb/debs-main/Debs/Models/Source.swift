//
//  Source.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import Foundation
import UIKit

struct Source: Identifiable, Codable, Hashable {
    var id: URL { url }
    let url: URL
    var name: String
    
    var iconData: Data?
    
    var icon: UIImage? {
        if let data = iconData {
            return UIImage(data: data)
        }
        return UIImage(systemName: "shippingbox.fill")
    }
}
