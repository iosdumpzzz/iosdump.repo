//
//  ContentView.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appUIState: AppUIState
    @EnvironmentObject var sourceService: SourceService
    @State private var searchText = ""
    
    var body: some View {
        Group {
            if #available(iOS 26.0, *) {
                TabView(selection: $appUIState.selectedTab) {
                    Tab("越狱源", systemImage: "shippingbox.fill", value: 0) {
                        SourcesView()
                    }
                    
                    Tab("Debs", systemImage: "hammer.fill", value: 1) {
                        DebsView()
                    }
                    
                    Tab("管理文件", systemImage: "folder.fill", value: 2) {
                        DownloadsView()
                    }
                    
                    Tab(value: 3, role: .search) {
                        NavigationStack {
                            SearchTabContent(searchText: $searchText)
                                .environmentObject(sourceService)
                                .navigationTitle("搜索")
                        }
                    }
                }
                .searchable(text: $searchText, prompt: "搜索所有源中的插件")
            } else {
                // 使用 TabView 创建底部标签栏
                TabView(selection: $appUIState.selectedTab) { // <-- 修改这里
                    // 第一个标签页：越狱源
                    SourcesView()
                        .tabItem {
                            Label("越狱源", systemImage: "shippingbox.fill")
                        }
                        .tag(0) // <-- 为第一个标签页添加 tag
                    
                    // --- ▼▼▼ 在这里添加新的 Tab ▼▼▼ ---
                               DebsView() // 我们即将创建的新视图
                                   .tabItem {
                                       Label("Debs", systemImage: "hammer.fill") // 使用一个合适的图标
                                   }
                                   .tag(1) // 新页面的 tag
                               // --- ▲▲▲ 新增结束 ▲▲▲ ---

                    // 第二个标签页：下载列表
                    DownloadsView()
                        .tabItem {
                            Label("管理文件", systemImage: "folder.fill")
                        }
                        .tag(2) // <-- 为第二个标签页添加 tag
                }
            }
        }
        .overlay {
            // --- ▼▼▼ 修改后的代码 ▼▼▼ ---
            // 修改 if 条件，加入 isAddingSources
            if appUIState.isAddingSources || appUIState.isExtracting || appUIState.isZipping || appUIState.isRefreshing || appUIState.isDeleting {
                ZStack {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                    VStack(spacing: 20) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.5)
                        // 修改 Text，使其显示 loadingMessage
                        Text(appUIState.loadingMessage)
                            .foregroundColor(.white)
                            .font(.headline)
                    }
                    .padding(30)
                    .background(Material.ultraThinMaterial)
                    .cornerRadius(15)
                }
            }
            // --- ▲▲▲ 修改结束 ▲▲▲
        }
               // ▲▲▲ 新增代码结束 ▲▲▲
        
    }
}

// MARK: - iOS 26+ 搜索 Tab 内容（仅 iOS 26+ 使用，不影响原有逻辑）
@available(iOS 26.0, *)
private struct SearchTabContent: View {
    @Binding var searchText: String
    @EnvironmentObject var sourceService: SourceService
    
    @State private var searchResults: [SearchablePackage] = []
    @State private var selectedArchIndex = 1
    private let architectures = ["arm", "arm64", "arm64e"]
    @State private var searchTask: Task<Void, Never>?
    
    var body: some View {
        VStack(spacing: 0) {
            if !searchText.isEmpty {
                FilterControl(selectedIndex: $selectedArchIndex, items: architectures)
                    .padding(.horizontal)
                    .padding(.vertical, 8)
            }
            
            List(searchResults) { result in
                NavigationLink(destination: PackageDetailView(package: result.package, source: result.source)) {
                    HStack(spacing: 12) {
                        CachedAsyncImage(url: result.package.iconURL(forSource: result.source)) { image in
                            image.resizable().aspectRatio(contentMode: .fit)
                        } placeholder: {
                            Image(systemName: "archivebox.fill").foregroundColor(.secondary)
                        }
                        .frame(width: 44, height: 44)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text(result.package.name)
                                .font(.headline)
                            
                            Text(result.package.packageDescription)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                                
                            Text(result.package.version)
                                .font(.caption2)
                                .foregroundColor(.accentColor)
                                
                            Text("来自: \(result.source.name)")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                    .frame(minHeight: 65)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .overlay {
                if searchText.isEmpty {
                    ContentUnavailableView("搜索插件", systemImage: "magnifyingglass", description: Text("输入关键词搜索所有源中的插件"))
                } else if searchResults.isEmpty {
                    ContentUnavailableView.search
                }
            }
        }
        .background(Color(.systemGroupedBackground))
        .onChange(of: searchText) { _ in
            debounceAndPerformSearch()
        }
        .onChange(of: selectedArchIndex) { _ in
            if !searchText.isEmpty {
                debounceAndPerformSearch()
            }
        }
        .onAppear {
            if !searchText.isEmpty {
                Task { await performSearch() }
            }
        }
    }
    
    private func debounceAndPerformSearch() {
        searchTask?.cancel()
        searchTask = Task {
            do {
                try await Task.sleep(nanoseconds: 300_000_000)
                if Task.isCancelled { return }
                await performSearch()
            } catch {}
        }
    }
    
    private func performSearch() async {
        if Task.isCancelled { return }
        if searchText.isEmpty {
            await MainActor.run { searchResults = [] }
            return
        }
        do {
            let selectedArch = architectures[selectedArchIndex]
            let results = try await sourceService.searchAllPackages(query: searchText, architecture: selectedArch)
            if Task.isCancelled { return }
            await MainActor.run { searchResults = results }
        } catch {
            print("Search task was cancelled or failed with error: \(error.localizedDescription)")
        }
    }
}
