//
//  DebsProjectDetailView.swift
//  Debs
//
//  Created by Z on 2025/10/13.
//

// 文件路径: Debs/Views/DebsProjectDetailView.swift
import SwiftUI

// 让 URL 支持 .sheet(item:)
extension URL: @retroactive Identifiable {
    public var id: String { absoluteString }
}

struct DebsProjectDetailView: View {
    let projectURL: URL
    let isRootLevel: Bool
    
    @State private var items: [URL] = []
    @State private var errorAlertMessage: String?
    @State private var showErrorAlert = false
    
    // 用于重新打包和分享
    @State private var packagedDebURL: URL?
    @State private var showingShareSheet = false
    @EnvironmentObject var appUIState: AppUIState
    @State private var searchText = ""
    
    // 重新打包后的动作区分与源选择弹窗
    enum RepackageActionType {
        case share
        case upload
    }
    @State private var repackageAction: RepackageActionType = .share
    @State private var showingRepoPicker = false
    
    // 替换/导出变量
    @State private var itemToReplace: URL?
    @State private var showingFileImporterForReplace = false
    @State private var itemToExport: URL?
    @State private var showingExportShareSheet = false
    @State private var exportableZipURL: URL?
    @State private var isReplacingFolder = false
    @State private var showReplaceErrorAlert = false
    @State private var replaceErrorMessage = ""
    
    // 重命名变量
    @State private var showRenameConfirmAlert = false
    @State private var pendingRenameNewURL: URL?
    @State private var pendingRenameOldURL: URL?
    
    @State private var showingRepackageConfirmAlert = false
    @State private var showDeleteConfirmAlert = false
    @State private var itemToDelete: URL?
    
    // 导入文件与新建文件夹相关状态
    @State private var showingFileImporterForAdd = false
    @State private var showingNewFolderAlert = false
    @State private var newFolderName = ""
    
    // 控制文本编辑器的状态（改用 item 方式，彻底解决空白 sheet）
    @State private var editingFileURL: URL?
    
    private var filteredItems: [URL] {
        if searchText.isEmpty {
            return items
        } else {
            return items.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        List(filteredItems, id: \.self) { itemURL in
            if isDirectory(url: itemURL) {
                NavigationLink(destination: DebsProjectDetailView(projectURL: itemURL, isRootLevel: false).environmentObject(appUIState)) {
                    label(for: itemURL, isDirectory: true)
                }
                .isDetailLink(false)
                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                    Button(role: .destructive) {
                        itemToDelete = itemURL
                        showDeleteConfirmAlert = true
                    } label: {
                        Label("删除", systemImage: "trash")
                    }

                    Button {
                        itemToExport = itemURL
                        exportItem()
                    } label: {
                        Label("导出", systemImage: "square.and.arrow.up")
                    }
                    .tint(.blue)
                }
            } else {
                // 点击事件，并采用黑名单模式智能放行文件编辑
                label(for: itemURL, isDirectory: false)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        if isEditable(itemURL) {
                            editingFileURL = itemURL
                        }
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            itemToDelete = itemURL
                            showDeleteConfirmAlert = true
                        } label: {
                            Label("删除", systemImage: "trash")
                        }

                        Button {
                            itemToReplace = itemURL
                            isReplacingFolder = isDirectory(url: itemURL)
                            showingFileImporterForReplace = true
                        } label: {
                            Label("替换", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .tint(.orange)

                        Button {
                            itemToExport = itemURL
                            exportItem()
                        } label: {
                            Label("导出", systemImage: "square.and.arrow.up")
                        }
                        .tint(.blue)
                    }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(projectURL.lastPathComponent)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    if isRootLevel {
                        Button {
                            repackageAction = .share
                            showingRepackageConfirmAlert = true
                        } label: {
                            Label("重新打包", systemImage: "hammer.fill")
                        }
                        
                        Button {
                            repackageAction = .upload
                            showingRepackageConfirmAlert = true
                        } label: {
                            Label("重新打包并上传越狱源", systemImage: "arrow.up.circle.fill")
                        }
                        
                        Divider()
                    }
                    
                    Button {
                        showingFileImporterForAdd = true
                    } label: {
                        Label("导入文件", systemImage: "doc.badge.plus")
                    }
                    
                    Button {
                        showingNewFolderAlert = true
                    } label: {
                        Label("新建文件夹", systemImage: "folder.badge.plus")
                    }
                    
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.system(size: 18))
                }
            }
        }
        .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索文件或文件夹")
        .onAppear(perform: loadContents)
        .alert("新建文件夹", isPresented: $showingNewFolderAlert) {
            TextField("文件夹名称", text: $newFolderName)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            Button("取消", role: .cancel) {
                newFolderName = ""
            }
            Button("创建") {
                createNewFolder()
            }
        }
        .sheet(isPresented: $showingFileImporterForAdd) {
            DocumentPicker { pickedURL in
                performFileImport(with: pickedURL)
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            if let debURL = packagedDebURL {
                ShareSheet(items: [debURL]) { _, _, _, _ in
                    try? FileManager.default.removeItem(at: debURL)
                }
            }
        }
        .alert("操作失败", isPresented: $showErrorAlert) {
            Button("好的") { }
        } message: {
            Text(errorAlertMessage ?? "发生未知错误。")
        }
        .sheet(isPresented: $showingFileImporterForReplace) {
            if isReplacingFolder {
                FolderPicker { pickedURL in
                    performReplacement(with: pickedURL)
                }
            } else {
                DocumentPicker { pickedURL in
                    performReplacement(with: pickedURL)
                }
            }
        }
        .alert("替换错误", isPresented: $showReplaceErrorAlert) {
            Button("好的") { }
        } message: {
            Text(replaceErrorMessage)
        }
        .alert("替换成功", isPresented: $showRenameConfirmAlert) {
            Button("确定") {
                renameItem()
            }
            Button("取消", role: .cancel) {
                pendingRenameNewURL = nil
                pendingRenameOldURL = nil
            }
        } message: {
            Text("是否要重命名为 “\(pendingRenameOldURL?.lastPathComponent ?? "原始名称")”？")
        }
        .sheet(isPresented: $showingExportShareSheet) {
            if let zipURL = exportableZipURL {
                ShareSheet(items: [zipURL]) { _, _, _, _ in
                    try? FileManager.default.removeItem(at: zipURL)
                }
            }
        }
        .alert("确定删除？", isPresented: $showDeleteConfirmAlert, presenting: itemToDelete) { urlToDelete in
            Button("删除", role: .destructive) {
                deleteItem(at: urlToDelete)
            }
            Button("取消", role: .cancel) {}
        } message: { urlToDelete in
            Text("确定要删除 “\(urlToDelete.lastPathComponent)” 吗？此操作不可撤销。")
        }
        .alert("提示", isPresented: $showingRepackageConfirmAlert) {
            Button("继续打包", role: .destructive, action: repackageProject)
            Button("取消", role: .cancel) {}
        } message: {
            Text(repackageAction == .upload ? "即将重新打包并上传至越狱源，确认继续？" : "重新打包Deb？")
        }
        // 使用 item 方式，彻底杜绝空白 sheet
        .sheet(item: $editingFileURL) { fileURL in
            TextEditorSheet(fileURL: fileURL)
        }
        // 打包后上传仓库选择器
        .sheet(isPresented: $showingRepoPicker) {
            if let url = packagedDebURL {
                RepoPickerSheet(debURL: url, repoService: GitHubRepoService.shared, appUIState: appUIState) {
                    try? FileManager.default.removeItem(at: url)
                }
            }
        }
    }
    
    // 采用黑名单模式，彻底解放各种脚本的编辑限制
    private func isEditable(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        // 将明显的二进制不可编辑文件过滤掉，其他的全部允许作为文本去读取尝试
        let binaryExts = ["dylib", "png", "jpg", "jpeg", "zip", "deb", "car", "nib", "bin", "caf", "pdf", "mp3", "mp4"]
        return !binaryExts.contains(ext)
    }
    
    private func getStandardDebName(from projectURL: URL) -> String? {
        let controlURL = projectURL.appendingPathComponent("DEBIAN/control")
        guard let data = try? Data(contentsOf: controlURL) else { return nil }
        let content = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .ascii) ?? ""
        var package = "", version = "", arch = ""
        for line in content.components(separatedBy: .newlines) {
            if line.hasPrefix("Package:") { package = String(line.dropFirst(8)).trimmingCharacters(in: .whitespaces) }
            else if line.hasPrefix("Version:") { version = String(line.dropFirst(8)).trimmingCharacters(in: .whitespaces) }
            else if line.hasPrefix("Architecture:") { arch = String(line.dropFirst(13)).trimmingCharacters(in: .whitespaces) }
        }
        if !package.isEmpty && !version.isEmpty && !arch.isEmpty {
            return "\(package)_\(version)_\(arch).deb"
        }
        return nil
    }
    
    private func performFileImport(with pickedURL: URL) {
        let shouldStopAccessing = pickedURL.startAccessingSecurityScopedResource()
        defer {
            if shouldStopAccessing {
                pickedURL.stopAccessingSecurityScopedResource()
            }
        }
        
        let destinationURL = projectURL.appendingPathComponent(pickedURL.lastPathComponent)
        do {
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.copyItem(at: pickedURL, to: destinationURL)
            loadContents()
        } catch {
            errorAlertMessage = "导入文件失败: \(error.localizedDescription)"
            showErrorAlert = true
        }
    }

    private func createNewFolder() {
        let trimmedName = newFolderName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        let newFolderURL = projectURL.appendingPathComponent(trimmedName)
        do {
            try FileManager.default.createDirectory(at: newFolderURL, withIntermediateDirectories: true)
            loadContents() 
            newFolderName = "" 
        } catch {
            errorAlertMessage = "创建文件夹失败: \(error.localizedDescription)"
            showErrorAlert = true
        }
    }

    private func renameItem() {
        guard let newURL = pendingRenameNewURL, let oldURL = pendingRenameOldURL else { return }
        
        do {
            try FileManager.default.moveItem(at: newURL, to: oldURL)
            loadContents()
        } catch {
            errorAlertMessage = "重命名失败: \(error.localizedDescription)"
            showErrorAlert = true
        }
        
        pendingRenameNewURL = nil
        pendingRenameOldURL = nil
    }

    @ViewBuilder
    private func label(for url: URL, isDirectory: Bool) -> some View {
        HStack {
            Image(systemName: isDirectory ? "folder.fill" : "doc.text.fill")
                .foregroundColor(.accentColor)
                .font(.title3)
                .frame(width: 30)
            Text(url.lastPathComponent)
        }
    }
    
    private func loadContents() {
        do {
            let contents = try FileManager.default.contentsOfDirectory(at: projectURL, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            
            self.items = contents.sorted {
                let isDir1 = isDirectory(url: $0)
                let isDir2 = isDirectory(url: $1)
                if isDir1 != isDir2 {
                    return isDir1 
                }
                return $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
            }
        } catch {
            self.errorAlertMessage = "无法加载文件夹内容: \(error.localizedDescription)"
            self.showErrorAlert = true
        }
    }
    
    private func isDirectory(url: URL) -> Bool {
        var isDirectory: ObjCBool = false
        FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
        return isDirectory.boolValue
    }
    
    private func repackageProject() {
        Task(priority: .userInitiated) {
            await performRepackage(isRetry: false)
        }
    }

    private func performRepackage(isRetry: Bool) async {
        await MainActor.run {
            appUIState.loadingMessage = "正在重新打包..."
            appUIState.isZipping = true
        }
        
        do {
            guard let permissions = DebsProjectManager.shared.loadPermissions(from: self.projectURL) else {
                await MainActor.run {
                    self.errorAlertMessage = "无法加载权限文件 (.permissions.plist)。打包已取消。"
                    self.showErrorAlert = true
                    appUIState.isZipping = false
                }
                return
            }
            
            let symlinks = DebsProjectManager.shared.loadSymlinks(from: self.projectURL) ?? [:]
            let metadata = DebsProjectManager.shared.listProjects().first(where: { $0.projectURL == self.projectURL })
            let compressionFormat = metadata?.compressionFormat ?? "gz"

            let newDebURL = try await DebPackager.packageProject(
                    projectURL: self.projectURL,
                    permissions: permissions,
                    symlinks: symlinks,
                    compressionFormat: compressionFormat
                )
            
            var finalDebURL = newDebURL
            if let standardName = getStandardDebName(from: self.projectURL) {
                let renamedURL = newDebURL.deletingLastPathComponent().appendingPathComponent(standardName)
                if FileManager.default.fileExists(atPath: renamedURL.path) {
                    try? FileManager.default.removeItem(at: renamedURL)
                }
                if let _ = try? FileManager.default.moveItem(at: newDebURL, to: renamedURL) {
                    finalDebURL = renamedURL
                }
            }
            
            await MainActor.run {
                self.packagedDebURL = finalDebURL
                appUIState.isZipping = false
                if repackageAction == .upload {
                    self.showingRepoPicker = true
                } else {
                    self.showingShareSheet = true
                }
            }
        } catch {
            let nsError = error as NSError
            
            if !isRetry && nsError.domain == NSCocoaErrorDomain && nsError.code == NSFileReadNoPermissionError {
                await MainActor.run {
                    appUIState.loadingMessage = "权限不足，正在尝试修复..."
                }
                
                let fileManager = FileManager.default
                if let enumerator = fileManager.enumerator(at: self.projectURL, includingPropertiesForKeys: [.isRegularFileKey]) {
                    let allFileURLs = enumerator.compactMap { $0 as? URL }
                    for fileURL in allFileURLs {
                        try? fileManager.setAttributes([.posixPermissions: 0o644], ofItemAtPath: fileURL.path)
                    }
                }
                
                await performRepackage(isRetry: true)
                
            } else {
                await MainActor.run {
                    self.errorAlertMessage = error.localizedDescription
                    self.showErrorAlert = true
                    appUIState.isZipping = false
                }
            }
        }
    }

    private func deleteItem(at url: URL) {
        do {
            try FileManager.default.removeItem(at: url)
            loadContents()
        } catch {
            errorAlertMessage = "删除失败: \(error.localizedDescription)"
            showErrorAlert = true
        }
    }

    private func performReplacement(with pickedURL: URL) {
        guard let originalURL = itemToReplace else { return }

        let shouldStopAccessing = pickedURL.startAccessingSecurityScopedResource()
        defer {
            if shouldStopAccessing {
                pickedURL.stopAccessingSecurityScopedResource()
            }
        }
        
        let isOriginalDirectory = isDirectory(url: originalURL)
        let isPickedDirectory = isDirectory(url: pickedURL)

        if isOriginalDirectory != isPickedDirectory {
            replaceErrorMessage = isOriginalDirectory ? "替换失败：必须用一个文件夹来替换一个文件夹。" : "替换失败：必须用一个文件来替换一个文件。"
            showReplaceErrorAlert = true
            return
        }

        let fileManager = FileManager.default
        let destinationURL = originalURL.deletingLastPathComponent().appendingPathComponent(pickedURL.lastPathComponent)

        do {
            try fileManager.removeItem(at: originalURL)
            try fileManager.copyItem(at: pickedURL, to: destinationURL)
            loadContents()
            
            self.pendingRenameNewURL = destinationURL
            self.pendingRenameOldURL = originalURL
            self.showRenameConfirmAlert = true
            
        } catch {
            errorAlertMessage = "替换文件失败: \(error.localizedDescription)"
            showErrorAlert = true
            loadContents()
        }
    }
    
    private func exportItem() {
        guard let url = itemToExport else { return }

        appUIState.loadingMessage = "正在压缩..."
        appUIState.isZipping = true

        Task {
            do {
                let zipURL = try await ZipService.createZip(from: [url], zipFileName: url.lastPathComponent)
                await MainActor.run {
                    self.exportableZipURL = zipURL
                    self.showingExportShareSheet = true
                    appUIState.isZipping = false
                }
            } catch {
                await MainActor.run {
                    self.errorAlertMessage = "导出失败: \(error.localizedDescription)"
                    self.showErrorAlert = true
                    appUIState.isZipping = false
                }
            }
        }
    }
}

// ▼▼▼ 最终强化版文本编辑器：UITextView + 彻底清理控制字符 + Binary Plist 转 XML ▼▼▼
struct TextEditorSheet: View {
    let fileURL: URL
    @Environment(\.dismiss) var dismiss
    @State private var textContent: String = ""
    @State private var showError = false
    @State private var errorMsg = ""
    @State private var isLoading = true
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemBackground).edgesIgnoringSafeArea(.all)
                
                if isLoading {
                    ProgressView("正在读取文件...")
                } else {
                    // 使用 UITextView 彻底解决 TextEditor 空白问题
                    UITextViewWrapper(text: $textContent)
                        .padding(.horizontal, 4)
                }
            }
            .navigationTitle(fileURL.lastPathComponent)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveFile()
                    }
                }
            }
            .onAppear {
                loadFileContent()
            }
            .alert("错误", isPresented: $showError) {
                Button("好的", role: .cancel) { dismiss() }
            } message: {
                Text(errorMsg)
            }
        }
    }
    
    private func loadFileContent() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let data = try? Data(contentsOf: fileURL) else {
                DispatchQueue.main.async {
                    self.errorMsg = "无法读取该文件的数据内容。"
                    self.showError = true
                    self.isLoading = false
                }
                return
            }
            
            var loadedText: String? = nil
            
            // 1. Binary / XML Plist 优先转成标准 XML
            let isPlist = fileURL.pathExtension.lowercased() == "plist"
                       || fileURL.lastPathComponent.hasSuffix(".plist")
                       || fileURL.pathExtension.lowercased() == "strings"
            
            if isPlist {
                if let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
                   let xmlData = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0),
                   let xmlString = String(data: xmlData, encoding: .utf8) {
                    loadedText = xmlString
                }
            }
            
            // 2. 普通文本（control / 脚本等）多编码尝试
            if loadedText == nil {
                let encodings: [String.Encoding] = [
                    .utf8,
                    .utf16,
                    .utf16LittleEndian,
                    .utf16BigEndian,
                    .ascii,
                    .macOSRoman,
                    .isoLatin1
                ]
                for encoding in encodings {
                    if let str = String(data: data, encoding: encoding) {
                        loadedText = str
                        break
                    }
                }
            }
            
            DispatchQueue.main.async {
                if var text = loadedText {
                    // 彻底清理所有控制字符（只保留 \t \n \r 和可打印字符）
                    // 这是解决 control / 解压残留 \0 导致空白的最终方案
                    text = String(text.unicodeScalars.filter { scalar in
                        let v = scalar.value
                        return v == 9 || v == 10 || v == 13 ||   // \t \n \r
                               (v >= 32 && v != 127) ||          // 可打印 ASCII
                               v > 127                           // 非 ASCII
                    })
                    self.textContent = text
                } else {
                    self.errorMsg = "不支持的文件编码格式，无法作为文本编辑。"
                    self.showError = true
                }
                self.isLoading = false
            }
        }
    }
    
    private func saveFile() {
        do {
            try textContent.write(to: fileURL, atomically: true, encoding: .utf8)
            dismiss()
        } catch {
            errorMsg = "保存失败: \(error.localizedDescription)"
            showError = true
        }
    }
}

// 可靠的 UITextView 包装（比 TextEditor 强太多）
struct UITextViewWrapper: UIViewRepresentable {
    @Binding var text: String
    
    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.font = UIFont.monospacedSystemFont(ofSize: 15, weight: .regular)
        textView.isEditable = true
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.textContainerInset = UIEdgeInsets(top: 8, left: 4, bottom: 8, right: 4)
        textView.delegate = context.coordinator
        return textView
    }
    
    func updateUIView(_ uiView: UITextView, context: Context) {
        if uiView.text != text {
            uiView.text = text
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UITextViewDelegate {
        var parent: UITextViewWrapper
        
        init(_ parent: UITextViewWrapper) {
            self.parent = parent
        }
        
        func textViewDidChange(_ textView: UITextView) {
            parent.text = textView.text
        }
    }
}
// ▲▲▲ 最终修复结束 ▲▲▲
