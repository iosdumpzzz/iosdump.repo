//
//  IpaFrameworksView.swift
//  Debs
//
//  Created by Z on 2025/10/11.
//

// 文件路径: Debs/Views/IpaFrameworksView.swift
import SwiftUI

struct IpaFrameworksView: View {
    @Environment(\.dismiss) var dismiss
    let ipaFileName: String
    let items: [FrameworkInfo]

    @State private var selection = Set<FrameworkInfo.ID>()
    @State private var shareableZipURL: URL?
    @State private var showingShareSheet = false
    @State private var zipError: String?
    @State private var showZipErrorAlert = false
    @EnvironmentObject var appUIState: AppUIState

    var body: some View {
        NavigationView {
            List {
                if items.isEmpty {
                    Text("未能在此 IPA 文件中找到任何框架或动态库。")
                        .foregroundColor(.secondary)
                } else {
                    Section(header: Text("在 \(ipaFileName) 中找到 \(items.count) 个项目")) {
                        ForEach(items) { item in
                            HStack {
                                Image(systemName: item.name.hasSuffix(".framework") ? "shippingbox.fill" : "gearshape.2.fill")
                                    .foregroundColor(.accentColor)
                                
                                VStack(alignment: .leading) {
                                    Text(item.name).bold()
                                    Text(item.path)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .lineLimit(2)
                                }
                                
                                Spacer()
                                
                                if selection.contains(item.id) {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.accentColor)
                                }
                            }
                            .frame(height: 65)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                if selection.contains(item.id) {
                                    selection.remove(item.id)
                                } else {
                                    selection.insert(item.id)
                                }
                            }
                        }
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("提取框架或动态库")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("导出 \(selection.count) 个") {
                        exportSelectedItems()
                    }
                    .disabled(selection.isEmpty)
                }
            }
            .sheet(isPresented: $showingShareSheet) {
                if let url = shareableZipURL {
                    ShareSheet(items: [url])
                }
            }
            .alert("压缩失败", isPresented: $showZipErrorAlert) {
                Button("好的") {}
            } message: {
                Text(zipError ?? "发生未知错误")
            }
        }
    }

    private func exportSelectedItems() {
        let selectedItems = items.filter { selection.contains($0.id) }
        guard !selectedItems.isEmpty else { return }

        Task {
            appUIState.loadingMessage = "正在压缩文件..."
            appUIState.isZipping = true
            do {
                let urlsToZip = selectedItems.map { $0.tempURL }
                let baseName = ipaFileName.replacingOccurrences(of: ".ipa", with: "") + "-Frameworks"
                let zipURL = try await ZipService.createZip(from: urlsToZip, zipFileName: baseName)
                
                await MainActor.run {
                    self.shareableZipURL = zipURL
                    self.showingShareSheet = true
                }
            } catch {
                await MainActor.run {
                    self.zipError = error.localizedDescription
                    self.showZipErrorAlert = true
                }
            }
            await MainActor.run {
                appUIState.isZipping = false
            }
        }
    }
}
