//
//  ManagedReposListView.swift
//  Debs
//

import SwiftUI

struct ManagedReposListView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var repoService = GitHubRepoService.shared
    @EnvironmentObject var appUIState: AppUIState
    
    @State private var showingAddRepo = false
    
    var body: some View {
        NavigationView {
            List {
                if repoService.repos.isEmpty {
                    Text("您尚未绑定任何 GitHub 源仓库。\n点击右上角 '+' 使用 Token 绑定仓库。")
                        .foregroundColor(.secondary)
                        .padding(.vertical)
                }
                
                ForEach(repoService.repos) { repo in
                    NavigationLink(destination: ManagedRepoDetailView(repo: repo).environmentObject(appUIState)) {
                        HStack(spacing: 12) {
                            // ▼▼▼ 动态显示 GitHub 源头像 ▼▼▼
                            CachedAsyncImage(url: URL(string: "https://github.com/\(repo.owner).png")) { image in
                                image.resizable().aspectRatio(contentMode: .fill)
                            } placeholder: {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .foregroundColor(.secondary)
                            }
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(repo.repoName).font(.headline)
                                Text("Owner: \(repo.owner)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                .onDelete(perform: repoService.deleteRepo)
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("管理我的源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingAddRepo = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            // ▼▼▼ 添加了 interactiveDismissDisabled(true) 以阻止下滑关闭 ▼▼▼
            .sheet(isPresented: $showingAddRepo) {
                AddGitHubRepoView().environmentObject(repoService)
                    .interactiveDismissDisabled(true)
            }
        }
    }
}

struct AddGitHubRepoView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var repoService: GitHubRepoService
    
    @State private var owner = ""
    @State private var repoName = ""
    @State private var token = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("仓库信息"), footer: Text("例如你的项目是 github.com/iosdumpzzz/repo，则用户名填 iosdumpzzz，仓库名填 repo")) {
                    TextField("GitHub 用户名", text: $owner)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    TextField("仓库名", text: $repoName)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
                
                Section(header: Text("身份验证"), footer: Text("前往 GitHub网页端 -> Settings -> Developer settings -> Personal access tokens (classic) 生成一个勾选了 'repo' 权限的 Token 粘贴在此处。")) {
                    SecureField("GitHub Token (PAT)", text: $token)
                }
                
                Section {
                    Button("保存并绑定") {
                        repoService.addRepo(owner: owner, repoName: repoName, token: token)
                        dismiss()
                    }
                    .disabled(owner.isEmpty || repoName.isEmpty || token.isEmpty)
                }
            }
            .navigationTitle("绑定 GitHub 仓库")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }
}
