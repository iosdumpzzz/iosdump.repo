//
//  DocumentPicker.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import SwiftUI
import UniformTypeIdentifiers // 导入此框架以指定文件类型

struct DocumentPicker: UIViewControllerRepresentable {
    
    // 定义一个回调闭包，当用户选择文件后，将 URL 传回
    var onFilePicked: (URL) -> Void

    // 创建并返回一个 UIDocumentPickerViewController
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // 允许选择 .deb 文件。由于 iOS 没有 .deb 的官方 UTI，
        // 允许选择 .deb, .ipa (作为zip) 和通用数据文件
        let supportedTypes: [UTType] = [UTType(filenameExtension: "deb") ?? .data, UTType(filenameExtension: "ipa") ?? .zip, .data]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        picker.delegate = context.coordinator
        picker.shouldShowFileExtensions = true
        return picker
    }

    // 更新视图控制器（此处无需操作）
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    // 创建协调器
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    // 协调器类，用于处理来自 UIDocumentPickerViewController 的代理回调
    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(_ parent: DocumentPicker) {
            self.parent = parent
        }

        // 当用户成功选择一个或多个文件后调用
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            parent.onFilePicked(url)
        }
    }
}
