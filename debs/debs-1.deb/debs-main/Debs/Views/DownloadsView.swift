// Debs/Views/DownloadsView.swift
import SwiftUI

struct DownloadsView: View {
    @State private var downloadedFiles: [URL] = []
    @State private var selection = Set<URL>()
    @State private var searchText = ""
    @State private var fileToShare: URL?
    @State private var showingShareSheet = false
    @State private var editMode: EditMode = .inactive
    @State private var showingActionSheet = false
    @State private var selectedFile: URL?
    @State private var showingDeleteConfirm = false
    @State private var showingFileImporter = false
    @State private var showDebExtractConfirm = false

    @EnvironmentObject var appUIState: AppUIState
    
    @State private var selectedIpaURL: URL?
    @State private var showIpaActionSheet = false
    @State private var ipaAnalysisResult: Result<[FrameworkInfo], Error>?
    @State private var showIpaResultView = false
    @State private var analysisError: String?
    @State private var showAnalysisErrorAlert = false
    @State private var showDebActionSheet = false
    @State private var showingIpaTapActionSheet = false
    
    @State private var showCleanupAlert = false
    @State private var showCleanupConfirmAlert = false
    @State private var showingSettings = false
    
    @StateObject private var metadataService = DownloadMetadataService.shared
    
    @State private var extractedDylibs: [URL] = []
    @State private var showDylibExportView = false
    @State private var shareableURL: URL?
    @State private var showingDylibShareSheet = false
    @State private var extractionError: String?
    @State private var showExtractionErrorAlert = false
    @State private var zipError: String?
    @State private var showZipErrorAlert = false
    
    // 上传越狱源需要的状态变量
    @State private var showingRepoPicker = false
    @State private var urlToUpload: URL?
    @StateObject private var repoService = GitHubRepoService.shared

    var filteredFiles: [URL] {
        if searchText.isEmpty {
            return downloadedFiles
        } else {
            return downloadedFiles.filter { $0.lastPathComponent.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    @ViewBuilder
    private var navigationContent: some View {
        NavigationView {
            let mainListContent = ZStack {
                List(selection: editMode.isEditing ? $selection : .constant(Set<URL>())) {
                    if filteredFiles.isEmpty {
                        Text(searchText.isEmpty ? "还没有文件。" : "未找到匹配的文件。")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(filteredFiles, id: \.self) { fileURL in
                            HStack(spacing: 12) {
                                let itemInfo = metadataService.getItem(for: fileURL.lastPathComponent)

                                CachedAsyncImage(url: itemInfo?.package.iconURL(forSource: itemInfo!.source)) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                } placeholder: {
                                    Image(systemName: "archivebox.fill")
                                        .font(.system(size: 24))
                                        .foregroundColor(.secondary)
                                }
                                .frame(width: 44, height: 44)
                                .background(Color(.systemGray6))
                                .cornerRadius(8)

                                VStack(alignment: .leading) {
                                    Text(fileURL.lastPathComponent)
                                        .font(.headline)
                                        .lineLimit(2)
                                    Text(fileSize(for: fileURL))
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                            }
                            .frame(height: 60)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                if editMode.isEditing {
                                    if self.selection.contains(fileURL) {
                                        self.selection.remove(fileURL)
                                    } else {
                                        self.selection.insert(fileURL)
                                    }
                                } else {
                                    self.selectedFile = fileURL
                                    if ["ipa", "tipa"].contains(fileURL.pathExtension.lowercased()) {
                                        self.showingIpaTapActionSheet = true
                                    } else {
                                        self.showingActionSheet = true
                                    }
                                }
                            }
                        }
                    }
                }
                .listStyle(InsetGroupedListStyle())
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("管理文件") 
            .searchable(text: $searchText,
                        placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "搜索文件")
            .onAppear(perform: loadFiles)
            .environment(\.editMode, $editMode)
            
            if editMode.isEditing {
                mainListContent
                    .toolbar {
                        ToolbarItemGroup(placement: .navigationBarLeading) {
                            Button("取消") {
                                selection.removeAll()
                                editMode = .inactive
                            }
                        }
                        ToolbarItemGroup(placement: .navigationBarTrailing) {
                            Button(selection.count == filteredFiles.count && !filteredFiles.isEmpty ? "取消全选" : "全选") {
                                if selection.count == filteredFiles.count {
                                    selection.removeAll()
                                } else {
                                    selection = Set(filteredFiles)
                                }
                            }
                            Button("删除") {
                                showingDeleteConfirm = true
                            }
                            .disabled(selection.isEmpty)
                        }
                    }
            } else {
                mainListContent
                    .toolbar {
                        ToolbarItemGroup(placement: .navigationBarTrailing) {
                            
                            // 1. 设置按钮排在左侧
                            Button {
                                showingSettings = true
                            } label: {
                                Image(systemName: "gearshape.fill")
                            }
                            
                            // 2. 三个点的气泡菜单排在最右侧边缘
                            Menu {
                                Button {
                                    showingFileImporter = true
                                } label: {
                                    Label("导入文件", systemImage: "plus.circle")
                                }

                                Button {
                                    editMode = .active
                                } label: {
                                    Label("批量编辑", systemImage: "signature")
                                }
                                .disabled(downloadedFiles.isEmpty)
                                
                                Divider()
                                
                                Button(role: .destructive) {
                                    self.showCleanupConfirmAlert = true
                                } label: {
                                    Label("清理缓存", systemImage: "trash.fill")
                                }
                                
                            } label: {
                                Image(systemName: "ellipsis.circle")
                                    .font(.system(size: 18))
                            }
                        }
                    }
            }
        }
        .navigationViewStyle(.stack)
    }

    var body: some View {
        navigationContent
            .confirmationDialog(
                selectedFile?.lastPathComponent ?? "操作",
                isPresented: $showingActionSheet,
                titleVisibility: .visible
            ) {
                Button("分享") {
                    if let file = selectedFile {
                        self.fileToShare = file
                        self.showingShareSheet = true
                    }
                }
                Button("解压 Deb") {
                    if let file = selectedFile {
                        extractDebToProjects(for: file)
                    }
                }
                Button("上传越狱源") {
                    if let fileToProcess = selectedFile {
                        Task {
                            await MainActor.run {
                                appUIState.loadingMessage = "正在读取包信息..."
                                appUIState.isExtracting = true
                            }
                            
                            // 1. 后台解压并提取 control 文件获取真实包名
                            var finalUploadURL = fileToProcess
                            let fm = FileManager.default
                            let tempExtractDir = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
                            
                            do {
                                try fm.createDirectory(at: tempExtractDir, withIntermediateDirectories: true)
                                // 静默解压以获取 metadata
                                _ = try await DebExtractor.extractAllFilesWithPermissions(from: fileToProcess, to: tempExtractDir)
                                
                                let controlURL = tempExtractDir.appendingPathComponent("DEBIAN/control")
                                if let data = try? Data(contentsOf: controlURL),
                                   let content = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .ascii) {
                                    
                                    var package = "", version = "", arch = ""
                                    for line in content.components(separatedBy: .newlines) {
                                        if line.hasPrefix("Package:") { package = String(line.dropFirst(8)).trimmingCharacters(in: .whitespaces) }
                                        else if line.hasPrefix("Version:") { version = String(line.dropFirst(8)).trimmingCharacters(in: .whitespaces) }
                                        else if line.hasPrefix("Architecture:") { arch = String(line.dropFirst(13)).trimmingCharacters(in: .whitespaces) }
                                    }
                                    
                                    // 2. 构造出带真实包名的标准文件
                                    if !package.isEmpty && !version.isEmpty && !arch.isEmpty {
                                        let standardName = "\(package)_\(version)_\(arch).deb"
                                        let renamedURL = fm.temporaryDirectory.appendingPathComponent(standardName)
                                        
                                        if fm.fileExists(atPath: renamedURL.path) {
                                            try? fm.removeItem(at: renamedURL)
                                        }
                                        // 拷贝到临时目录并重命名供上传
                                        try fm.copyItem(at: fileToProcess, to: renamedURL)
                                        finalUploadURL = renamedURL
                                    }
                                }
                            } catch {
                                print("解析包名失败，将使用原文件名上传: \(error)")
                            }
                            
                            // 3. 清理后台解压的临时文件
                            try? fm.removeItem(at: tempExtractDir)
                            
                            await MainActor.run {
                                appUIState.isExtracting = false
                                self.urlToUpload = finalUploadURL
                                self.showingRepoPicker = true
                            }
                        }
                    }
                }
                Button("提取动态库") {
                    if let file = selectedFile {
                        extractAndShowDylibs(for: file)
                    }
                }
                Button("删除", role: .destructive) {
                    if let file = selectedFile {
                        deleteFile(at: file)
                    }
                }
                Button("取消", role: .cancel) {}
            }
            .sheet(isPresented: $showingShareSheet) {
                if let urlToShare = fileToShare {
                    ShareSheet(items: [urlToShare])
                }
            }
            .sheet(isPresented: $showDylibExportView) {
                DylibExportView(dylibs: extractedDylibs) { selectedDylibs in
                    self.showDylibExportView = false
                    guard !selectedDylibs.isEmpty else { return }
                    Task {
                        appUIState.loadingMessage = "正在压缩..."
                        appUIState.isZipping = true
                        do {
                            let baseName = selectedFile?.deletingPathExtension().lastPathComponent ?? "Dylibs"
                            let zipURL = try await ZipService.createZip(from: selectedDylibs, zipFileName: baseName)
                            await MainActor.run {
                                self.shareableURL = zipURL
                                self.showingDylibShareSheet = true
                                appUIState.isZipping = false
                            }
                        } catch {
                            await MainActor.run {
                                self.zipError = error.localizedDescription
                                self.showZipErrorAlert = true
                                appUIState.isZipping = false
                            }
                        }
                    }
                }
            }
            .sheet(isPresented: $showingDylibShareSheet) {
                if let shareableURL = shareableURL {
                    ShareSheet(items: [shareableURL])
                }
            }
            .alert("压缩失败", isPresented: $showZipErrorAlert) {
                Button("好的", role: .cancel) {}
            } message: {
                Text(zipError ?? "发生未知错误")
            }
            .alert("错误", isPresented: $showExtractionErrorAlert) {
                Button("好的", role: .cancel) {}
            } message: {
                Text(extractionError ?? "发生未知错误")
            }
            .alert("确定删除", isPresented: $showingDeleteConfirm) {
                Button("删除", role: .destructive) {
                    deleteSelectedFiles()
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("确定要删除选中的 \(selection.count) 个文件吗？此操作不可撤销。")
            }
            .sheet(isPresented: $showingFileImporter) {
                DocumentPicker { url in
                    importFile(from: url)
                }
            }
            .confirmationDialog(
                "分析 \(selectedIpaURL?.lastPathComponent ?? "IPA 文件")",
                isPresented: $showIpaActionSheet,
                titleVisibility: .visible
            ) {
                Button("提取框架或动态库") {
                    if let url = selectedIpaURL {
                        analyzeIpa(url: url)
                    }
                }
                Button("导入到管理文件列表") {
                    if let url = selectedIpaURL {
                        copyFileToDownloads(from: url)
                    }
                }
                Button("取消", role: .cancel) {}
            }
            .sheet(isPresented: $showIpaResultView) {
                if case .success(let items) = ipaAnalysisResult {
                    IpaFrameworksView(ipaFileName: selectedIpaURL?.lastPathComponent ?? "IPA", items: items)
                        .environmentObject(appUIState)
                }
            }
            .alert("分析失败", isPresented: $showAnalysisErrorAlert) {
                Button("好的") {}
            } message: {
                Text(analysisError ?? "发生未知错误")
            }
            .onChange(of: appUIState.pendingIpaAnalysisURL) { newURL in
                if let url = newURL {
                    self.selectedIpaURL = url
                    self.showIpaActionSheet = true
                    appUIState.pendingIpaAnalysisURL = nil
                }
            }
            .onChange(of: appUIState.needsFileListRefresh) { _ in
                loadFiles()
            }
            .onChange(of: appUIState.pendingDebExtractionURL) { newURL in
                if let url = newURL {
                    self.selectedFile = url
                    self.showDebActionSheet = true
                    appUIState.pendingDebExtractionURL = nil
                }
            }
            .confirmationDialog(
                "处理 \(selectedFile?.lastPathComponent ?? "Deb 文件")",
                isPresented: $showDebActionSheet,
                titleVisibility: .visible
            ) {
                Button("导入到管理文件") {
                        guard let tempURL = selectedFile else { return }
                        if FileImportService.shared.copyFileToDownloads(from: tempURL) != nil {
                            loadFiles()
                        }
                        cleanupTemporaryFile()
                    }
                
                Button("解压 Deb") {
                        guard let tempURL = selectedFile else { return }
                        if let permanentURL = FileImportService.shared.copyFileToDownloads(from: tempURL) {
                            loadFiles()
                            extractDebToProjects(for: permanentURL)
                        }
                        cleanupTemporaryFile()
                    }
                    
                Button("提取动态库") {
                    guard let tempURL = selectedFile else { return }
                    if let permanentURL = FileImportService.shared.copyFileToDownloads(from: tempURL) {
                        loadFiles()
                        extractAndShowDylibs(for: permanentURL)
                    }
                    cleanupTemporaryFile()
                }
                
                Button("取消", role: .cancel) {
                    cleanupTemporaryFile()
                }
            }
            .confirmationDialog(
                selectedFile?.lastPathComponent ?? "IPA 操作",
                isPresented: $showingIpaTapActionSheet,
                titleVisibility: .visible
            ) {
                Button("分享") {
                    if let file = selectedFile {
                        self.fileToShare = file
                        self.showingShareSheet = true
                    }
                }
                Button("提取框架与动态库") {
                    guard let url = selectedFile else { return }
                    guard let tempURL = FileImportService.shared.copyFileToTemporaryDirectory(from: url) else { return }
                    appUIState.activeTemporaryFileURL = tempURL
                    analyzeIpa(url: tempURL)
                }
                Button("删除", role: .destructive) {
                    if let file = selectedFile {
                        deleteFile(at: file)
                    }
                }
                Button("取消", role: .cancel) {}
            }
            .alert("清理完成", isPresented: $showCleanupAlert) {
                Button("好的", role: .cancel) {}
            } message: {
                Text("临时文件已全部被清理。")
            }
            .alert("确认清理？", isPresented: $showCleanupConfirmAlert) {
                Button("确认", role: .destructive) {
                    performCleanup() 
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("此操作将删除应用部分缓存文件。")
            }
            .sheet(isPresented: $showingSettings) {
                SettingsView()
            }
            .sheet(isPresented: $showingRepoPicker, onDismiss: {
                // 如果用户没有上传直接下滑关闭弹窗，确保清理生成的临时包名文件，绝不残留
                if let url = urlToUpload, url.path.contains(FileManager.default.temporaryDirectory.path) {
                    try? FileManager.default.removeItem(at: url)
                }
            }) {
                if let url = urlToUpload {
                    RepoPickerSheet(debURL: url, repoService: repoService, appUIState: appUIState) {
                        cleanupTemporaryFile()
                    }
                }
            }
    }
    
    private func extractDebToProjects(for fileURL: URL) {
        appUIState.loadingMessage = "正在解压到 Debs..."
        appUIState.isExtracting = true

        Task(priority: .userInitiated) {
            var iconData: Data?
            if let downloadedItem = metadataService.getItem(for: fileURL.lastPathComponent) {
                if let iconURL = downloadedItem.package.iconURL(forSource: downloadedItem.source) {
                    if let cachedImage = ImageCacheService.shared.getImage(forKey: iconURL.absoluteString) {
                        iconData = cachedImage.pngData()
                    } else {
                        if let (data, _) = try? await URLSession.shared.data(from: iconURL) {
                            iconData = data
                            if let image = UIImage(data: data) {
                                ImageCacheService.shared.setImage(image, forKey: iconURL.absoluteString)
                            }
                        }
                    }
                }
            }

            guard let projectURL = DebsProjectManager.shared.createProjectDirectory(for: fileURL.lastPathComponent) else {
                await MainActor.run { appUIState.isExtracting = false }
                return
            }
            
            do {
                       let result = try await DebExtractor.extractAllFilesWithPermissions(from: fileURL, to: projectURL)
                       DebsProjectManager.shared.savePermissions(result.permissions, in: projectURL)
                       DebsProjectManager.shared.saveSymlinks(result.symlinks, in: projectURL)

                       let architecture = DebsProjectManager.shared.getArchitecture(from: projectURL)
                       
                       let metadata = DebsProjectMetadata(
                           projectName: projectURL.lastPathComponent,
                           iconData: iconData,
                           compressionFormat: result.compressionFormat,
                           architecture: architecture,
                           creationDate: Date()
                       )
                       DebsProjectManager.shared.saveMetadata(metadata, in: projectURL)
                       
                       await MainActor.run {
                           appUIState.isExtracting = false
                           appUIState.selectedTab = 1
                       }
                   } catch {
                       DebsProjectManager.shared.deleteProject(at: projectURL)
                       await MainActor.run {
                           self.extractionError = "解压到 Debs 失败: \(error.localizedDescription)"
                           self.showExtractionErrorAlert = true
                           appUIState.isExtracting = false
                       }
                   }
        }
    }

    private func performCleanup() {
        let fileManager = FileManager.default
        var didPerformCleanup = false

        let tempDirectory = fileManager.temporaryDirectory
        do {
            let tempContents = try fileManager.contentsOfDirectory(at: tempDirectory, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            for itemURL in tempContents {
                try fileManager.removeItem(at: itemURL)
            }
            if !tempContents.isEmpty {
                didPerformCleanup = true
            }
        } catch {
            print("Error cleaning temporary directory: \(error)")
        }

        let downloadsDir = downloadsDirectory()
        let allowedExtensions = ["tipa", "ipa", "deb"]
        do {
            let downloadContents = try fileManager.contentsOfDirectory(at: downloadsDir, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            for itemURL in downloadContents {
                let fileExtension = itemURL.pathExtension.lowercased()
                
                if !allowedExtensions.contains(fileExtension) {
                    try fileManager.removeItem(at: itemURL)
                    didPerformCleanup = true
                }
            }
        } catch {
            print("Error cleaning invalid files from downloads directory: \(error)")
        }
        
        loadFiles()
        
        if didPerformCleanup {
            self.showCleanupAlert = true
        }
    }
    
    private func extractAndShowDylibs(for fileURL: URL) {
        appUIState.loadingMessage = "正在提取动态库..."
        appUIState.isExtracting = true
        Task(priority: .userInitiated) {
            do {
                let dylibs = try await DebExtractor.extractDylibs(from: fileURL)
                await MainActor.run {
                    self.extractedDylibs = dylibs
                    self.appUIState.isExtracting = false
                    self.showDylibExportView = true
                }
            } catch {
                await MainActor.run {
                    self.appUIState.isExtracting = false
                    self.extractionError = "解压失败: \(error.localizedDescription)"
                    self.showExtractionErrorAlert = true
                }
            }
        }
    }
    
    private func downloadsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        let debsDir = documentsDirectory.appendingPathComponent("Downloads/DEBs")
        if !FileManager.default.fileExists(atPath: debsDir.path) {
            try? FileManager.default.createDirectory(at: debsDir, withIntermediateDirectories: true, attributes: nil)
        }
        return debsDir
    }
    
    private func loadFiles() {
        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(
                at: downloadsDirectory(),
                includingPropertiesForKeys: [.creationDateKey]
            )
            
            let sortedContents = directoryContents.sorted { url1, url2 in
                let date1 = (try? url1.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
                let date2 = (try? url2.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
                
                return date1 > date2
            }
            
            downloadedFiles = sortedContents.filter {
                let lowercasedExtension = $0.pathExtension.lowercased()
                let allowedExtensions = ["deb", "ipa", "tipa"]
                return allowedExtensions.contains(lowercasedExtension)
            }
        } catch {
            print("Error loading downloaded files: \(error)")
        }
    }
    
    private func fileSize(for url: URL) -> String {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            if let size = attributes[.size] as? NSNumber {
                return ByteCountFormatter.string(fromByteCount: size.int64Value, countStyle: .file)
            }
        } catch {
            print("Error getting file size: \(error)")
        }
        return "N/A"
    }
    
    private func importFile(from sourceURL: URL) {
        if ["ipa", "tipa"].contains(sourceURL.pathExtension.lowercased()) {
            self.selectedIpaURL = sourceURL
            self.showIpaActionSheet = true
        } else {
            self.selectedFile = sourceURL
            self.showDebActionSheet = true
        }
    }

    private func copyFileToDownloads(from sourceURL: URL) {
        let fileManager = FileManager.default
        let destinationDir = downloadsDirectory()
        var destinationURL = destinationDir.appendingPathComponent(sourceURL.lastPathComponent)
        var counter = 1
        let baseFileName = destinationURL.deletingPathExtension().lastPathComponent
        let fileExtension = destinationURL.pathExtension

        while fileManager.fileExists(atPath: destinationURL.path) {
            let newFileName = "\(baseFileName) (\(counter)).\(fileExtension)"
            destinationURL = destinationDir.appendingPathComponent(newFileName)
            counter += 1
        }
        
        do {
            try fileManager.copyItem(at: sourceURL, to: destinationURL)
            loadFiles()
        } catch {
            print("Error importing file: \(error.localizedDescription)")
        }
    }
    
    private func deleteSelectedFiles() {
        let selectedFileURLs = Array(selection)
        for fileURL in selectedFileURLs {
            do {
                try FileManager.default.removeItem(at: fileURL)
                metadataService.removeItem(for: fileURL.lastPathComponent)
            } catch {
                print("Failed to delete file \(fileURL.lastPathComponent): \(error)")
            }
        }
        selection.removeAll()
        editMode = .inactive
        loadFiles()
    }
    
    private func deleteFile(at fileURL: URL) {
        do {
            try FileManager.default.removeItem(at: fileURL)
            metadataService.removeItem(for: fileURL.lastPathComponent)
            loadFiles()
        } catch {
            print("Failed to delete file \(fileURL.lastPathComponent): \(error)")
        }
    }
    
    private func analyzeIpa(url: URL) {
        appUIState.loadingMessage = "正在分析IPA文件..."
        appUIState.isExtracting = true 
        
        Task {
            do {
                let items = try await IpaAnalyzerService.analyze(ipaURL: url)
                self.ipaAnalysisResult = .success(items)
                self.showIpaResultView = true
            } catch {
                self.ipaAnalysisResult = .failure(error)
                self.analysisError = error.localizedDescription
                self.showAnalysisErrorAlert = true
            }
            
            await MainActor.run {
                appUIState.isExtracting = false
            }
        }
    }
 
    private func cleanupTemporaryFile() {
        FileImportService.shared.cleanup(temporaryItemURL: appUIState.activeTemporaryFileURL)
        appUIState.activeTemporaryFileURL = nil
    }
}

// 全局可复用的越狱源选择与直传弹窗视图
struct RepoPickerSheet: View {
    let debURL: URL
    @ObservedObject var repoService: GitHubRepoService
    @ObservedObject var appUIState: AppUIState
    var onComplete: () -> Void
    
    @Environment(\.dismiss) var dismiss
    @State private var alertMsg = ""
    @State private var showAlert = false
    @State private var uploadingRepoID: UUID? = nil
    
    // 引入全局环境变量
    @AppStorage("globalUploadRepoPath") private var globalUploadPath: String = "debs"

    var body: some View {
        NavigationView {
            List {
                if repoService.repos.isEmpty {
                    Text("还未绑定任何 GitHub 仓库，先在源页面的“我的越狱源”中进行绑定配置。")
                        .foregroundColor(.secondary)
                }
                
                ForEach(repoService.repos) { repo in
                    Button {
                        uploadingRepoID = repo.id
                        uploadDeb(fileURL: debURL, repo: repo)
                    } label: {
                        HStack(spacing: 12) {
                            CachedAsyncImage(url: URL(string: "https://github.com/\(repo.owner).png")) { image in
                                image.resizable().aspectRatio(contentMode: .fill)
                            } placeholder: {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .foregroundColor(.secondary)
                            }
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                            
                            VStack(alignment: .leading) {
                                Text(repo.repoName).font(.headline).foregroundColor(.primary)
                                Text("Owner: \(repo.owner)").font(.caption).foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            if uploadingRepoID == repo.id {
                                ProgressView()
                            }
                        }
                    }
                    .disabled(uploadingRepoID != nil)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("选择要上传的越狱源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") { dismiss() }
                        .disabled(uploadingRepoID != nil)
                }
            }
            .alert("提示", isPresented: $showAlert) {
                Button("好的", role: .cancel) {
                    uploadingRepoID = nil
                    if alertMsg.contains("成功") {
                        dismiss()
                        onComplete()
                    }
                }
            } message: {
                Text(alertMsg)
            }
        }
        .interactiveDismissDisabled(true)
    }

    private func uploadDeb(fileURL: URL, repo: ManagedRepo) {
        Task {
            do {
                try await GitHubRepoService.shared.pushDeb(to: repo, fileURL: fileURL, targetPath: globalUploadPath)
                await MainActor.run {
                    alertMsg = "上传成功！文件已直推至 GitHub 的 \(globalUploadPath.isEmpty ? "根" : globalUploadPath)/ 目录下。"
                    showAlert = true
                }
            } catch {
                await MainActor.run {
                    alertMsg = "上传失败: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}
