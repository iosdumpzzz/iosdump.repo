//
//  DebsView.swift
//  Debs
//
//  Created by Z on 2025/10/13.
//

import SwiftUI

struct DebsView: View {
    @State private var projects: [DebsProjectMetadata] = []
    @EnvironmentObject var appUIState: AppUIState
    
    @State private var editMode: EditMode = .inactive
    @State private var selection = Set<DebsProjectMetadata.ID>()
    
    @State private var searchText = ""
    
    @State private var showDeleteConfirmAlert = false
    @State private var projectToDelete: DebsProjectMetadata?
    @State private var projectToExport: DebsProjectMetadata?
    @State private var showingExportShareSheet = false
    @State private var exportableZipURL: URL?
    // 新增：用于控制“新建打包”页面跳转的状态变量
    @State private var navigateToPackager = false

    private var filteredProjects: [DebsProjectMetadata] {
        if searchText.isEmpty {
            return projects
        } else {
            return projects.filter { $0.projectName.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // 列表或空视图
                if !filteredProjects.isEmpty || !searchText.isEmpty {
                    List(selection: editMode.isEditing ? $selection : .constant(Set<DebsProjectMetadata.ID>())) {
                        ForEach(filteredProjects) { project in
                            if let projectURL = project.projectURL {
                                NavigationLink(destination: DebsProjectDetailView(projectURL: projectURL, isRootLevel: true).environmentObject(appUIState)) {
                                    projectRow(for: project)
                                }
                                .isDetailLink(false) // 核心修复：防止退栈 Bug
                                .disabled(editMode.isEditing)
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        projectToDelete = project
                                        showDeleteConfirmAlert = true
                                    } label: {
                                        Label("删除", systemImage: "trash.fill")
                                    }
 
                                    Button {
                                        projectToExport = project
                                        exportProject()
                                    } label: {
                                        Label("导出", systemImage: "square.and.arrow.up")
                                    }.tint(.blue)
                                }
                            }
                        }
                    }
                    .listStyle(InsetGroupedListStyle())
                } else {
                    emptyStateView
                }
                
                // 【核心修复】：隐藏的 NavigationLink，通过 isActive 监听布尔值来触发跳转
                NavigationLink(
                    destination: DylibPackagerView().environmentObject(appUIState),
                    isActive: $navigateToPackager
                ) {
                    EmptyView()
                }
                .isDetailLink(false)
                .hidden()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Debs 项目")
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索项目")
            .onAppear(perform: loadProjects)
            .refreshable { loadProjects() }
            .environment(\.editMode, $editMode)
            .toolbar {
                // --- 导航栏左侧按钮 ---
                ToolbarItemGroup(placement: .navigationBarLeading) {
                    if editMode.isEditing {
                        Button("取消") {
                            selection.removeAll()
                            editMode = .inactive
                        }
                    }
                }

                // --- 导航栏右侧按钮 ---
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if editMode.isEditing {
                        Button(selection.count == filteredProjects.count && !filteredProjects.isEmpty ? "取消全选" : "全选") {
                            if selection.count == filteredProjects.count {
                                selection.removeAll()
                            } else {
                                selection = Set(filteredProjects.map { $0.id })
                            }
                        }
                        
                        Button {
                            projectToDelete = nil
                            showDeleteConfirmAlert = true
                        } label: {
                            Image(systemName: "trash")
                        }
                        .disabled(selection.isEmpty)

                    } else {
                        // 正常模式下的按钮，收纳为三个点的气泡菜单
                        Menu {
                            // 1. 打包按钮 【核心修复】：改为 Button 触发状态
                            Button {
                                navigateToPackager = true
                            } label: {
                                Label("打包Deb", systemImage: "plus.app")
                            }
                            
                            // 2. 编辑按钮
                            Button {
                                editMode = .active
                            } label: {
                                Label("批量编辑", systemImage: "signature")
                            }
                            .disabled(projects.isEmpty)
                             
                        } label: {
                            Image(systemName: "ellipsis.circle")
                                .font(.system(size: 18))
                        }
                    }
                }
            }
            .alert("确定删除吗？", isPresented: $showDeleteConfirmAlert) {
                Button("删除", role: .destructive) {
                    if let project = projectToDelete {
                        if let url = project.projectURL {
                            DebsProjectManager.shared.deleteProject(at: url)
                        }
                    } else {
                        let projectsToDelete = projects.filter { selection.contains($0.id) }
                        for project in projectsToDelete {
                            if let url = project.projectURL {
                                DebsProjectManager.shared.deleteProject(at: url)
                            }
                        }
                    }
                    loadProjects()
                    selection.removeAll()
                    editMode = .inactive
                }
                Button("取消", role: .cancel) {}
            } message: {
                if let project = projectToDelete {
                    Text("确定要删除项目 “\(project.projectName)” 吗？此操作不可撤销。")
                } else {
                    Text("确定要删除选中的 \(selection.count) 个项目吗？此操作不可撤销。")
                }
            }
            .sheet(isPresented: $showingExportShareSheet) {
                if let zipURL = exportableZipURL {
                    ShareSheet(items: [zipURL]) { _, _, _, _ in
                        try? FileManager.default.removeItem(at: zipURL)
                    }
                }
            }
        }
        .navigationViewStyle(.stack) // 核心修复：强制堆栈导航
    }

    private var emptyStateView: some View {
        VStack(spacing: 15) {
            Spacer()
        
            Image(systemName: "hammer.circle.fill")
                .font(.system(size: 60))
                .foregroundColor(.secondary.opacity(0.6))
            Text("列表为空")
                .font(.title2).fontWeight(.bold)
            Text("请从“管理文件”页面解压一个 Deb 文件。")
                .font(.callout).foregroundColor(.secondary)
    
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func projectRow(for project: DebsProjectMetadata) -> some View {
        HStack(spacing: 12) {
            Group {
                if let iconData = project.iconData, let uiImage = UIImage(data: iconData) {
                    Image(uiImage: uiImage).resizable()
                } else {
                    Image(systemName: "shippingbox.fill").resizable().foregroundColor(.secondary)
                }
            }
            .aspectRatio(contentMode: .fit)
            .frame(width: 44, height: 44)
            .background(Color(.systemGray6))
            .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(project.projectName)
                    .font(.headline)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .truncationMode(.middle)
                
                HStack(spacing: 6) {
                    Text("DEBS")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color(.systemGray5))
                        .clipShape(Capsule())
                    
                    if let architecture = project.architecture, !architecture.isEmpty {
                        Text(architecture.lowercased().replacingOccurrences(of: "iphoneos-", with: ""))
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color(.systemGray5))
                            .clipShape(Capsule())
                    }
                    
                    if let date = project.creationDate {
                        // ▼▼▼ 修改：显示年月日时分 ▼▼▼
                        Text(date, format: .dateTime.year().month().day().hour().minute())
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color(.systemGray5))
                            .clipShape(Capsule())
                    }
                }
            }
        }
        .frame(height: 60)
    }
  
    private func loadProjects() {
        self.projects = DebsProjectManager.shared.listProjects()
    }
    
    private func exportProject() {
        guard let project = projectToExport else { return }
        Task {
            await performExport(for: project, isRetry: false)
        }
    }

    private func performExport(for project: DebsProjectMetadata, isRetry: Bool) async {
        guard let url = project.projectURL else { return }
        
        await MainActor.run {
            appUIState.loadingMessage = "正在导出项目..."
            appUIState.isZipping = true
        }
        
        do {
            let zipURL = try await ZipService.createZip(from: [url], zipFileName: url.lastPathComponent)
            await MainActor.run {
                self.exportableZipURL = zipURL
                self.showingExportShareSheet = true
                appUIState.isZipping = false
            }
        } catch {
            let nsError = error as NSError
            if !isRetry && nsError.domain == NSCocoaErrorDomain && nsError.code == NSFileReadNoPermissionError {
                await MainActor.run {
                    appUIState.loadingMessage = "权限不足，正在尝试修复..."
                }
                
                let fileManager = FileManager.default
                if let enumerator = fileManager.enumerator(at: url, includingPropertiesForKeys: [.isRegularFileKey]) {
                    let allFileURLs = enumerator.compactMap { $0 as? URL }
                    for fileURL in allFileURLs {
                        try? fileManager.setAttributes([.posixPermissions: 0o644], ofItemAtPath: fileURL.path)
                    }
                }
                
                await performExport(for: project, isRetry: true)
                
            } else {
                print("导出失败: \(error.localizedDescription)")
                await MainActor.run {
                    appUIState.isZipping = false
                }
            }
        }
    }
    
    private func deleteProject(at offsets: IndexSet) {
        let projectsToDelete = offsets.map { projects[$0] }
        for project in projectsToDelete {
            if let url = project.projectURL {
                DebsProjectManager.shared.deleteProject(at: url)
            }
        }
        loadProjects()
    }
}
