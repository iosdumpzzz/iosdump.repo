//
//  CachedAsyncImage.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct CachedAsyncImage<Content: View, Placeholder: View>: View {
    private let url: URL?
    private let content: (Image) -> Content
    private let placeholder: () -> Placeholder

    @State private var image: UIImage?
    @State private var isLoading = false

    init(url: URL?, @ViewBuilder content: @escaping (Image) -> Content, @ViewBuilder placeholder: @escaping () -> Placeholder) {
        self.url = url
        self.content = content
        self.placeholder = placeholder
        var initialImage: UIImage? = nil
                if let urlString = url?.absoluteString {
                    initialImage = ImageCacheService.shared.getImage(forKey: urlString)
                }
                // 使用特殊语法 `_image` 来直接初始化 @State 包装的属性
                self._image = State(initialValue: initialImage)
                // --- ▲▲▲ 修正结束 ▲▲▲ ---
            }


    var body: some View {
        Group {
            if let uiImage = image {
                content(Image(uiImage: uiImage))
            } else {
                placeholder()
            }
        }
        .task(id: url) { // 当 URL 变化时，重新执行加载任务
            await loadImage()
        }
    }

    private func loadImage() async {
        // --- ▼▼▼ 核心修正点 #2：避免不必要的网络请求 ▼▼▼ ---
        // 如果图片已经通过上面的同步加载完成了，就直接返回，不再执行网络请求。
        guard self.image == nil else { return }
        
        guard let url = url, !isLoading else { return }

        let urlString = url.absoluteString

        // 检查缓存
        if let cachedImage = ImageCacheService.shared.getImage(forKey: urlString) {
            self.image = cachedImage
            return
        }

        // 如果缓存中没有，则从网络下载
        self.isLoading = true
        defer { self.isLoading = false }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let uiImage = UIImage(data: data) {
                // 下载成功，存入缓存并更新视图
                ImageCacheService.shared.setImage(uiImage, forKey: urlString)
                self.image = uiImage
            }
        } catch {
            print("Failed to load image from \(url): \(error.localizedDescription)")
        }
    }
}
