//
//  AddSourceView.swift
//  Debs
//
//  Created by Z on 2025/10/15.
//

// 文件: Debs/Views/AddSourceView.swift (新文件)
import SwiftUI

struct AddSourceView: View {
    // 用于关闭此视图
    @Environment(\.dismiss) var dismiss
    
    // 用于接收用户输入的文本
    @State private var urlString: String = ""
    
    // 一个回调闭包，当用户点击“添加”时，将输入的文本传回给父视图
    var onAdd: (String) -> Void
    
    var body: some View {
        NavigationView {
            Form {
                Section(
                    header: Text("输入源 URL"),
                    footer: Text("您可以输入单个或多个URL，用逗号或换行分隔。")
                ) {
                    // 使用 TextField 并设置合适的样式
                    TextField("https://example.com/repo", text: $urlString)
                        .keyboardType(.URL)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
            }
            .navigationTitle("添加越狱源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // 导航栏左侧的“取消”按钮
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss() // 关闭视图
                    }
                }
                // 导航栏右侧的“添加”按钮
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("添加") {
                        // 只有在输入不为空时才执行
                        if !urlString.isEmpty {
                            onAdd(urlString) // 调用回调函数
                        }
                        dismiss() // 关闭视图
                    }
                    .disabled(urlString.isEmpty) // 如果输入为空，则禁用按钮
                }
            }
        }
    }
}
