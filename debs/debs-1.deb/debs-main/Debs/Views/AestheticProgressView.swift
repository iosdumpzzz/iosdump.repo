//
//  AestheticProgressView.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct AestheticProgressView: View {
    @State private var progress: CGFloat = 0.0

    var body: some View {
        ProgressView(value: progress)
            .progressViewStyle(.linear)
            .tint(.blue) // 1. 将颜色修改为蓝色
            .onAppear {
                // 2. 使用动画让进度条在2.5秒内缓慢从0走到1，并无限重复
                withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) {
                    progress = 1.0
                }
            }
    }
}
