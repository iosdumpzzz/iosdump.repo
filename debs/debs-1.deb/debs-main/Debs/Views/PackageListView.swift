//
//  PackageListView.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct PackageListView: View {
    @EnvironmentObject var sourceService: SourceService
    let source: Source
    
    @State private var packages: [Package] = []
    @State private var isLoading = true
    @State private var searchText = ""
    
    @State private var selectedArchIndex = 1 // 默认选中 arm64
    private let architectures = ["arm", "arm64", "arm64e"]
    
    // ▼▼▼ 排序选项状态，使用 @AppStorage 进行持久化保存 ▼▼▼
    @AppStorage("packageListSortOption") private var sortOption: Int = 0 // 0: A-Z, 1: 版本从小到大, 2: 版本从大到小
    // ▲▲▲ 新增结束 ▲▲▲
    
    var filteredPackages: [Package] {
        // 文本过滤
        let textFiltered = searchText.isEmpty ? packages : packages.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.packageDescription.localizedCaseInsensitiveContains(searchText)
        }

        // 仅在搜索时应用架构过滤
        let archFiltered: [Package]
        if searchText.isEmpty {
            archFiltered = textFiltered
        } else {
            let selectedArch = architectures[selectedArchIndex]
            archFiltered = textFiltered.filter { package in
                let pkgArch = package.architecture.lowercased()
                switch selectedArch {
                case "arm":
                    return (pkgArch.contains("arm") && !pkgArch.contains("arm64")) || pkgArch.contains("i386")
                case "arm64":
                    return pkgArch.contains("arm64") && !pkgArch.contains("arm64e")
                case "arm64e":
                    return pkgArch.contains("arm64e")
                default:
                    return true
                }
            }
        }
        
        // ▼▼▼ 排序逻辑 (精确识别版本号) ▼▼▼
        if sortOption == 1 {
            return archFiltered.sorted { $0.version.compare($1.version, options: .numeric) == .orderedAscending }
        } else if sortOption == 2 {
            return archFiltered.sorted { $0.version.compare($1.version, options: .numeric) == .orderedDescending }
        } else {
            return archFiltered.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // 仅在搜索文本不为空时显示架构筛选器
            if !searchText.isEmpty {
                FilterControl(selectedIndex: $selectedArchIndex, items: architectures)
                    .padding(.horizontal)
                    .padding(.vertical, 8)
            }

            List(filteredPackages) { package in
                packageRow(package)
            }
            .listStyle(InsetGroupedListStyle())
            .overlay {
                if isLoading {
                    ProgressView("正在加载插件...")
                }
            }
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(source.name)
        .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索插件")
        .toolbar {
            // ▼▼▼ 右上角新增排序按钮 ▼▼▼
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Picker("排序方式", selection: $sortOption) {
                        Text("按名称 (A-Z)").tag(0)
                        Text("版本号 (从小到大)").tag(1)
                        Text("版本号 (从大到小)").tag(2)
                    }
                } label: {
                    Image(systemName: "arrow.up.arrow.down.circle")
                }
            }
            // ▲▲▲ 排序按钮结束 ▲▲▲
        }
        .task {
            await loadPackages()
        }
    }
    
    @ViewBuilder
    private func packageRow(_ package: Package) -> some View {
        NavigationLink(destination: PackageDetailView(package: package, source: source)) {
            HStack(spacing: 12) {
                CachedAsyncImage(url: package.iconURL(forSource: source)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } placeholder: {
                    Image(systemName: "archivebox.fill")
                        .foregroundColor(.secondary)
                }
                .frame(width: 44, height: 44)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(package.name)
                        .font(.headline)

                    Text(package.packageDescription)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                    
                    Text(package.version)
                        .font(.caption2)
                        .foregroundColor(.accentColor)
                        .padding(.top, 1)
                }
            }
            .padding(.vertical, 4)
        }
    }
    
    private func loadPackages() async {
        guard packages.isEmpty else { return }
        let result = await sourceService.loadPackagesFromCache(for: source)
        packages = result
        isLoading = false
    }
}
