// 文件路径: Debs/Views/DylibExportView.swift
import SwiftUI

struct DylibExportView: View {
    @Environment(\.dismiss) var dismiss
    let dylibs: [URL]

    // --- 修改 #1: 回调函数现在接收一个 URL 数组 ---
    let onFinishSelection: ([URL]) -> Void

    // --- 新增 #2: 用于跟踪用户勾选了哪些文件的状态变量 ---
    @State private var selection = Set<URL>()

    var body: some View {
        NavigationView {
            List {
                if dylibs.isEmpty {
                    Text("未能在此 .deb 文件中找到任何 .dylib 文件。")
                        .foregroundColor(.secondary)
                } else {
                    Section(header: Text("选择要导出的文件")) { // 标题也可以适当修改
                        ForEach(dylibs, id: \.self) { dylibURL in
                            // --- 修改 #3: 改造列表行，用于显示勾选状态并处理点击 ---
                            HStack {
                                Image(systemName: "gearshape.2.fill")
                                    .foregroundColor(.accentColor)
                                Text(dylibURL.lastPathComponent)
                                    .foregroundColor(.primary)
                                Spacer()
                                // 如果文件被选中，则显示对勾
                                if selection.contains(dylibURL) {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.accentColor)
                                }
                            }
                            .contentShape(Rectangle()) // 让整行都可以点击
                            .onTapGesture {
                                // 处理点选逻辑
                                if selection.contains(dylibURL) {
                                    selection.remove(dylibURL)
                                } else {
                                    selection.insert(dylibURL)
                                }
                            }
                        }
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("选择要导出的文件")
            .navigationBarTitleDisplayMode(.inline) 
            .toolbar {
                // --- 修改 #4: 改造工具栏按钮 ---
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    // 按钮标题改为“导出”，并且只有在用户选择了至少一个文件时才能点击
                    Button("导出 \(selection.count) 个文件") {
                        // 将选中的文件数组通过回调函数传回
                        onFinishSelection(Array(selection))
                    }
                    .disabled(selection.isEmpty) // 当没有选择时禁用按钮
                }
            }
        }
    }
}
