//
//  PackageDetailView.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct PackageDetailView: View {
    let package: Package
    let source: Source
    @StateObject private var downloadManager = DownloadManager()

    var body: some View {
        List {
            Section {
                HStack(alignment: .center, spacing: 15) {
                    // 左侧：插件图标
                    CachedAsyncImage(url: package.iconURL(forSource: source)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    } placeholder: {
                        Image(systemName: "archivebox.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)
                    }
                    .frame(width: 80, height: 80)
                    .background(Color(.systemGray6))
                    .cornerRadius(16)

                    // 右侧：插件信息
                    VStack(alignment: .leading, spacing: 8) {
                        Text(package.name)
                            .font(.title)
                            .bold()

                        Text("版本: \(package.version)")
                        Text("作者: \(package.maintainer)")
                        Text("架构: \(package.architecture)")
                    }
                    // 允许文字信息占据剩余所有空间
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.vertical, 8) // 给整个左右布局增加一些垂直内边距
            }
            
            Section {
                if downloadManager.isDownloading {
                    // ▼▼▼ 核心修改点 ▼▼▼
                    HStack(spacing: 8) { // <-- 将 VStack 改为 HStack，并可以加一些间距
                        ProgressView(value: downloadManager.progress)
                        Text(String(format: "%.0f%%", downloadManager.progress * 100))
                            .font(.caption)
                    }
                } else {
                    Button(action: downloadDeb) {
                        Label("下载 Deb 文件", systemImage: "arrow.down.circle.fill")
                    }
                }
            }
            
            Section(header: Text("描述")) {
                Text(package.packageDescription)
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle(package.name)
        .alert(isPresented: $downloadManager.showSuccessAlert) {
            Alert(
                title: Text("下载完成"),
                message: Text("\(downloadManager.downloadedFileName) 已保存到“管理文件”页面。"),
                dismissButton: .default(Text("好的"))
            )
        }
    }
    
    private func downloadDeb() {
        // *** 修改 ***: 调用新的下载方法
        downloadManager.startDownload(package: package, from: source)
    }
}
