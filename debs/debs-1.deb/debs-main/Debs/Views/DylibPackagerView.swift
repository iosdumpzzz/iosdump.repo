//
//  DylibPackagerView.swift
//  Debs
//
//  Created by Z on 2025/11/6.
//

// 文件路径: Debs/Views/DylibPackagerView.swift

import SwiftUI

// 用于包装 URL 以便在 .sheet(item:) 中使用
struct IdentifiableURL: Identifiable {
    let id = UUID()
    let url: URL
}

struct DylibPackagerView: View {
    
    @EnvironmentObject var appUIState: AppUIState
    @Environment(\.dismiss) var dismiss
    
    // 表单状态
    @State private var packageName: String = ""
    @State private var version: String = ""
    @State private var author: String = ""
    @State private var description: String = ""
    
    @State private var displayName: String = ""
    @State private var maintainer: String = ""
    
    // 多 Dylib 列表
    @State private var dylibs: [DylibItem] = []
    
    // UI 控制
    @State private var showingFileImporter = false
    @State private var dylibToEdit: IdentifiableURL?
    
    // 打包架构设置 (初始化时暂定，onAppear 中会强制重置)
    @AppStorage("debs.pack.scheme") private var schemeStorage: String = "rootlessArm64"
    @State private var scheme: PackageScheme = .rootlessArm64
    
    @State private var packagedDebURL: URL?
    @State private var showingShareSheet = false
    @State private var showErrorAlert = false
    @State private var errorMessage = ""
    
    // 隐根打包提示弹窗状态
    @State private var showingRoothideAlert = false
    
    // 包名校验
    private var isPackageNameASCII: Bool { packageName.canBeConverted(to: .ascii) }
    private var isPackageNameValid: Bool {
        isPackageNameASCII &&
        packageName.range(of: "^[a-z0-9][a-z0-9+.-]*$", options: .regularExpression) != nil
    }
    
    private var isFormValid: Bool {
        !packageName.isEmpty &&
        isPackageNameValid &&
        !version.isEmpty &&
        !author.isEmpty &&
        !description.isEmpty &&
        !displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !dylibs.isEmpty &&
        dylibs.allSatisfy { !$0.targetsText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    var body: some View {
        Form {
           
            Section(header: Text("插件元数据")) {
                TextField("包名 (com.example.tweak)", text: $packageName)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                if !isPackageNameValid && !packageName.isEmpty {
                    Text("包名只能包含小写字母、数字，且必须为 ASCII，不能包含中文/空格/大写。示例：com.example.tweak")
                        .font(.footnote)
                        .foregroundColor(.red)
                }
                
                TextField("Sileo显示名称", text: $displayName)
                TextField("版本", text: $version)
                    .keyboardType(.numbersAndPunctuation)
                TextField("作者", text: $author)
                TextField("描述", text: $description)
                TextField("维护者 (可选)", text: $maintainer)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
            }
            
            Section(header: Text("打包方案")) {
                Picker("架构", selection: $scheme) {
                    Text("有根 (arm)").tag(PackageScheme.rootfulArm)
                    Text("无根 (arm64)").tag(PackageScheme.rootlessArm64)
                    Text("隐根 (arm64e)").tag(PackageScheme.roothideArm64e)
                }
                .pickerStyle(.segmented)
                
                Text({
                    switch scheme {
                    case .rootfulArm:
                        return "有根：/Library/MobileSubstrate/DynamicLibraries（Substrate）。"
                    case .rootlessArm64:
                        return "无根：前缀 /var/jb，注入目录 /usr/lib/TweakInject（ElleKit）。"
                    case .roothideArm64e:
                        return "RootHide"
                    }
                }())
                .font(.footnote)
                .foregroundColor(.secondary)
            }
            
            Section(header: Text("导入的 Dylib 及注入目标")) {
                ForEach($dylibs) { $item in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(alignment: .center) {
                            Image(systemName: "cube.fill").foregroundColor(.accentColor)
                            Text(item.name).bold()
                            Spacer()
                            
                            Button {
                                self.dylibToEdit = IdentifiableURL(url: item.url)
                            } label: {
                                Text("修改依赖")
                                    .font(.subheadline)
                                    .foregroundColor(.blue)
                            }
                            .buttonStyle(PlainButtonStyle())
                            .padding(.trailing, 8)
                
                            Button(role: .destructive) {
                                try? FileManager.default.removeItem(at: item.url)
                                dylibs.removeAll { $0.id == item.id }
                            } label: {
                                Image(systemName: "trash.fill")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Color.red)
                                    .clipShape(Circle())
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        
                        TextField("注入目标(多目标英文逗号分隔)", text: $item.targetsText)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Picker("目标类型", selection: $item.targetKeyRaw) {
                            Text("自动").tag("auto")
                            Text("Bundles").tag("bundles")
                            Text("Executables").tag("executables")
                        }
                        .pickerStyle(.segmented)
                 
                        Picker("匹配模式", selection: $item.plistModeRaw) {
                            Text("Any").tag("Any")
                            Text("All").tag("All")
                        }
                        .pickerStyle(.segmented)
                    }
                    .padding(.vertical, 8)
                }
     
                Button(action: {
                    showingFileImporter = true
                }) {
                    Label("添加 .dylib 文件", systemImage: "plus.circle.fill")
                        .foregroundColor(.blue)
                }
            }
            
            Section {
                // ▼▼▼ 恢复正常的打包按钮逻辑 ▼▼▼
                Button(action: packageDeb) {
                    HStack {
                        Spacer()
                        Text(dylibs.isEmpty ? "请先导入 Dylib" : "打包 Deb (\(dylibs.count) 个 Dylib)")
                            .bold()
                        Spacer()
                    }
                }
                .disabled(!isFormValid)
                // ▲▲▲ 恢复结束 ▲▲▲
            }
        }
        .onAppear {
            // ▼▼▼ 核心修改：每次进入页面，强制重置为无根模式 ▼▼▼
            scheme = .rootlessArm64
            schemeStorage = "rootlessArm64"
            
            if dylibs.isEmpty {
                let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
                let workspace = paths[0].appendingPathComponent("DylibWorkspace")
                try? FileManager.default.removeItem(at: workspace)
            }
        }
        .onChange(of: scheme) { newValue in
            // ▼▼▼ 核心修改：当用户切换滑块时的监听逻辑 ▼▼▼
            switch newValue {
            case .rootfulArm: 
                schemeStorage = "rootfulArm"
            case .rootlessArm64: 
                schemeStorage = "rootlessArm64"
            case .roothideArm64e:
                schemeStorage = "roothideArm64e"
                // 选中隐根时，直接弹出提示
                showingRoothideAlert = true
            }
        }
        .navigationTitle("Deb 打包")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $dylibToEdit) { identifiableURL in
            DylibDependencyView(dylibURL: identifiableURL.url)
        }
        .sheet(isPresented: $showingFileImporter) {
            DocumentPicker { url in
                if url.pathExtension.lowercased() == "dylib" {
                    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
                    let workspace = paths[0].appendingPathComponent("DylibWorkspace")
                    if !FileManager.default.fileExists(atPath: workspace.path) {
                        try? FileManager.default.createDirectory(at: workspace, withIntermediateDirectories: true)
                    }
                    
                    let destinationURL = workspace.appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
                    
                    if FileImportService.shared.secureCopyItem(from: url, to: destinationURL) {
                        let newItem = DylibItem(url: destinationURL, name: url.lastPathComponent)
                        self.dylibs.append(newItem)
                    } else {
                        self.errorMessage = "导入 .dylib 文件失败，无法复制到沙盒目录。"
                        self.showErrorAlert = true
                    }
                } else {
                    self.errorMessage = "请选择一个 .dylib 文件。"
                    self.showErrorAlert = true
                }
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            if let debURL = packagedDebURL {
                ShareSheet(items: [debURL]) { _, _, _, _ in
                    try? FileManager.default.removeItem(at: debURL)
                }
            }
        }
        .alert("打包失败", isPresented: $showErrorAlert) {
            Button("好的") { }
        } message: {
            Text(errorMessage)
        }
        // ▼▼▼ 核心修改：选中隐根时的提示弹窗 ▼▼▼
        .alert("注意", isPresented: $showingRoothideAlert) {
            Button("确定", role: .none) { 
                // 点击确定，保留隐根选项
            }
            Button("取消", role: .cancel) {
                // 如果用户觉得不对劲点击取消，防误触，自动退回到无根选项
                scheme = .rootlessArm64
            }
        } message: {
            // TODO: 请在这里修改为你自己的提示内容
            Text("隐根目前打包有些问题，注入目标只能官方应用生效，多开无效，并且部分动态库所需依赖可能不会加载导致插件失效！如需使用多动态库打包，建议使用无根打包后使用patcher转换即可正常使用。")
        }
        // ▲▲▲ 修改结束 ▲▲▲
    }
    
    private func packageDeb() {
        appUIState.loadingMessage = "正在打包 Deb..."
        appUIState.isZipping = true
        
        let metadata = DylibPackager.Metadata(
            packageName: packageName,
            version: version,
            author: author,
            description: description,
            displayName: displayName.trimmingCharacters(in: .whitespacesAndNewlines),
            maintainer: maintainer.trimmingCharacters(in: .whitespacesAndNewlines),
            dylibs: dylibs
        )
        
        Task {
            do {
                let newDebURL = try await DylibPackager.package(
                    metadata: metadata,
                    scheme: scheme
                )
                
                var finalDebURL = newDebURL
                
                // 隐根转译拦截点
                if scheme == .roothideArm64e {
                    finalDebURL = try await RoothidePatcherService.convertToRoothide(rootlessDebURL: newDebURL)
                }
                
                await MainActor.run {
                    appUIState.isZipping = false
                    self.packagedDebURL = finalDebURL
                    self.showingShareSheet = true
                }
            } catch {
                await MainActor.run {
                    appUIState.isZipping = false
                    self.errorMessage = error.localizedDescription
                    self.showErrorAlert = true
                 }
            }
        }
    }
}
