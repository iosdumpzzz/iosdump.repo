//
//  ManagedRepoDetailView.swift
//  Debs
//

import SwiftUI
import UniformTypeIdentifiers

// 用于支持多选文件的自定义 Picker
struct MultiDocumentPicker: UIViewControllerRepresentable {
    var onFilesPicked: ([URL]) -> Void
    
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let supportedTypes: [UTType] = [UTType(filenameExtension: "deb") ?? .data, .data]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: MultiDocumentPicker
        init(_ parent: MultiDocumentPicker) { self.parent = parent }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            parent.onFilesPicked(urls)
        }
    }
}

struct ManagedRepoDetailView: View {
    let repo: ManagedRepo
    var pathOverride: String? = nil // 用于支持文件夹无限层级导航
    
    @EnvironmentObject var appUIState: AppUIState
    @StateObject private var repoService = GitHubRepoService.shared
    
    @State private var remoteDebFiles: [GitHubContent] = []
    @State private var showingFilePicker = false
    @State private var alertMsg = ""
    @State private var showAlert = false
    
    // 目录设置相关的状态
    @State private var showingCustomPathAlert = false
    @State private var tempCustomPath = ""
    
    // 搜索状态
    @State private var searchText = ""
    
    // 展开状态
    @State private var expandedFileSHA: String? = nil
    
    // 滑动菜单状态
    @State private var fileToDelete: GitHubContent?
    @State private var showDeleteConfirm = false
    
    @State private var fileToRename: GitHubContent?
    @State private var newFileName = ""
    @State private var showRenameAlert = false
    
    // 动态获取最新的 repo 数据与当前激活目录
    private var currentRepo: ManagedRepo {
        repoService.repos.first(where: { $0.id == repo.id }) ?? repo
    }
    private var activePath: String {
        if let override = pathOverride { return override }
        return currentRepo.customPath ?? "debs"
    }
    
    // 过滤列表
    var filteredFiles: [GitHubContent] {
        if searchText.isEmpty { return remoteDebFiles }
        return remoteDebFiles.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        List {
            Section {
                Button(action: {
                    // 点击上传时，自动收回可能展开的文本，并打开文件选择器
                    withAnimation { expandedFileSHA = nil }
                    showingFilePicker = true
                }) {
                    HStack {
                        Spacer()
                        Label("上传 Deb 文件", systemImage: "arrow.up.doc.fill")
                            .font(.headline)
                        Spacer()
                    }
                }
            }
            
            Section(header: Text("目录 \(activePath.isEmpty ? "根目录" : activePath) 下的文件")) {
                if remoteDebFiles.isEmpty && !searchText.isEmpty {
                    Text("未搜索到匹配的文件")
                        .foregroundColor(.secondary)
                } else if remoteDebFiles.isEmpty {
                    Text("文件夹为空或不存在")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(filteredFiles, id: \.sha) { file in
                        if file.type == "dir" {
                            // 文件夹：点击深入下一级
                            let nextPath = activePath.isEmpty ? file.name : "\(activePath)/\(file.name)"
                            NavigationLink(destination: ManagedRepoDetailView(repo: currentRepo, pathOverride: nextPath).environmentObject(appUIState)) {
                                fileRow(for: file)
                            }
                            .isDetailLink(false)
                            // 兼容文件夹的长按展开
                            .simultaneousGesture(
                                LongPressGesture().onEnded { _ in
                                    withAnimation { expandedFileSHA = file.sha }
                                }
                            )
                        } else {
                            // 普通文件：包含长按展开、点击缩回、滑动删除与重命名
                            fileRow(for: file)
                                .onTapGesture {
                                    // 点击任意文件强制缩回展开的文本
                                    if expandedFileSHA != nil {
                                        withAnimation { expandedFileSHA = nil }
                                    }
                                }
                                .onLongPressGesture {
                                    withAnimation { expandedFileSHA = file.sha }
                                }
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        fileToDelete = file
                                        showDeleteConfirm = true
                                    } label: {
                                        Label("删除", systemImage: "trash")
                                    }
                                    
                                    Button {
                                        fileToRename = file
                                        newFileName = file.name
                                        showRenameAlert = true
                                    } label: {
                                        Label("重命名", systemImage: "pencil")
                                    }
                                    .tint(.orange)
                                }
                        }
                    }
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索列表")
        // 如果是根级，标题显示仓库名；如果是深入文件夹，显示文件夹名
        .navigationTitle(pathOverride == nil ? currentRepo.repoName : (pathOverride?.components(separatedBy: "/").last ?? currentRepo.repoName))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                // 只有处于根设置页面时，才显示气泡菜单以改变整体默认目录
                if pathOverride == nil {
                    Menu {
                        Button("默认 (debs目录)") {
                            repoService.updateCustomPath(for: currentRepo.id, newPath: "debs")
                            loadRemoteDebs()
                        }
                        Button("自定义目录") {
                            tempCustomPath = currentRepo.customPath ?? "debs"
                            showingCustomPathAlert = true
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .font(.system(size: 18))
                    }
                }
            }
        }
        .onAppear(perform: loadRemoteDebs)
        .refreshable { loadRemoteDebs() }
        .sheet(isPresented: $showingFilePicker) {
            MultiDocumentPicker { urls in
                uploadDebs(fileURLs: urls)
            }
        }
        .alert("提示", isPresented: $showAlert) {
            Button("好的", role: .cancel) { }
        } message: {
            Text(alertMsg)
        }
        // 自定义目录弹窗
        .alert("自定义目录", isPresented: $showingCustomPathAlert) {
            TextField("留空为根目录", text: $tempCustomPath)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            
            Button("取消", role: .cancel) { }
            Button("确定") {
                var trimmedPath = tempCustomPath.trimmingCharacters(in: .whitespacesAndNewlines)
                while trimmedPath.hasPrefix("/") { trimmedPath.removeFirst() }
                while trimmedPath.hasSuffix("/") { trimmedPath.removeLast() }
                
                repoService.updateCustomPath(for: currentRepo.id, newPath: trimmedPath)
                loadRemoteDebs()
            }
        } message: {
            Text("输入要管理的仓库目录路径（例如xxx/xxx）")
        }
        // 删除确认弹窗
        .alert("确定删除", isPresented: $showDeleteConfirm, presenting: fileToDelete) { file in
            Button("删除", role: .destructive) { deleteFile(file) }
            Button("取消", role: .cancel) { }
        } message: { file in
            Text("确定要删除文件 “\(file.name)” 吗？此操作将直接从 GitHub 中移除。")
        }
        // 重命名弹窗
        .alert("重命名", isPresented: $showRenameAlert) {
            TextField("新文件名", text: $newFileName)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            Button("取消", role: .cancel) { }
            Button("确定") {
                if let file = fileToRename, !newFileName.isEmpty {
                    renameFile(file, newName: newFileName)
                }
            }
        }
    }
    
    // 单行显示封装
    @ViewBuilder
    private func fileRow(for file: GitHubContent) -> some View {
        let isExpanded = expandedFileSHA == file.sha
        HStack {
            Image(systemName: file.type == "dir" ? "folder.fill" : (file.name.hasSuffix(".deb") ? "shippingbox.fill" : "doc.text.fill"))
                .foregroundColor(file.type == "dir" ? .blue : .accentColor)
            // 自动折行展开效果
            Text(file.name)
                .lineLimit(isExpanded ? nil : 1)
                .truncationMode(.middle)
        }
        .contentShape(Rectangle())
    }
    
    // ----------------------------------------------------
    // MARK: - 网络请求及处理逻辑
    // ----------------------------------------------------
    
    private func loadRemoteDebs() {
        Task {
            do {
                let debs = try await GitHubRepoService.shared.fetchDebs(for: currentRepo, targetPath: activePath)
                await MainActor.run {
                    self.remoteDebFiles = debs.sorted {
                        if $0.type == $1.type {
                            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
                        }
                        return $0.type == "dir"
                    }
                }
            } catch {
                print("拉取失败: \(error)")
                await MainActor.run {
                    self.remoteDebFiles = []
                }
            }
        }
    }
    
    private func uploadDebs(fileURLs: [URL]) {
        let debURLs = fileURLs.filter { $0.pathExtension.lowercased() == "deb" }
        guard !debURLs.isEmpty else {
            alertMsg = "选择至少一个 .deb 文件！"
            showAlert = true
            return
        }
        
        appUIState.loadingMessage = "正在推送到 GitHub (\(debURLs.count) 个文件)..."
        appUIState.isExtracting = true
        
        Task {
            var successCount = 0
            var failErrors: [String] = []
            
            for url in debURLs {
                let shouldStopAccessing = url.startAccessingSecurityScopedResource()
                do {
                    try await GitHubRepoService.shared.pushDeb(to: currentRepo, fileURL: url, targetPath: activePath)
                    successCount += 1
                } catch {
                    failErrors.append("\(url.lastPathComponent): \(error.localizedDescription)")
                }
                if shouldStopAccessing { url.stopAccessingSecurityScopedResource() }
            }
            
            await MainActor.run {
                if failErrors.isEmpty {
                    alertMsg = "成功推送 \(successCount) 个文件至 \(activePath.isEmpty ? "根" : activePath)/ 目录下。"
                } else {
                    alertMsg = "成功 \(successCount) 个文件。\n失败 \(failErrors.count) 个:\n" + failErrors.joined(separator: "\n")
                }
                showAlert = true
                appUIState.isExtracting = false
                loadRemoteDebs()
            }
        }
    }
    
    private func deleteFile(_ file: GitHubContent) {
        appUIState.loadingMessage = "正在删除文件..."
        appUIState.isExtracting = true
        Task {
            do {
                try await GitHubRepoService.shared.deleteRemoteFile(repo: currentRepo, fileName: file.name, sha: file.sha, targetPath: activePath)
                await MainActor.run {
                    alertMsg = "删除成功！"
                    showAlert = true
                    appUIState.isExtracting = false
                    loadRemoteDebs()
                }
            } catch {
                await MainActor.run {
                    alertMsg = "删除失败: \(error.localizedDescription)"
                    showAlert = true
                    appUIState.isExtracting = false
                }
            }
        }
    }
    
    private func renameFile(_ file: GitHubContent, newName: String) {
        let finalName = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !finalName.isEmpty && finalName != file.name else { return }
        
        appUIState.loadingMessage = "正在重命名..."
        appUIState.isExtracting = true
        Task {
            do {
                try await GitHubRepoService.shared.renameRemoteFile(repo: currentRepo, oldFileName: file.name, oldSha: file.sha, newFileName: finalName, targetPath: activePath)
                await MainActor.run {
                    alertMsg = "重命名成功！"
                    showAlert = true
                    appUIState.isExtracting = false
                    loadRemoteDebs()
                }
            } catch {
                await MainActor.run {
                    alertMsg = "重命名失败: \(error.localizedDescription)"
                    showAlert = true
                    appUIState.isExtracting = false
                }
            }
        }
    }
}
