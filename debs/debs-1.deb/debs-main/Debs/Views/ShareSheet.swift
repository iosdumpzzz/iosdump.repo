//  ShareSheet.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct ShareSheet: UIViewControllerRepresentable {
    // 要分享的内容
    var items: [Any]
    // 分享完成后执行的回调
    var completionHandler: ((UIActivity.ActivityType?, Bool, [Any]?, Error?) -> Void)? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        controller.completionWithItemsHandler = completionHandler
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            let keyWindow = UIApplication.shared.connectedScenes
                .filter { $0.activationState == .foregroundActive }
                .compactMap { $0 as? UIWindowScene }
                .first?.windows
                .first(where: { $0.isKeyWindow })

            controller.popoverPresentationController?.sourceView = keyWindow
            controller.popoverPresentationController?.sourceRect = CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 0, height: 0)
            controller.popoverPresentationController?.permittedArrowDirections = []
        }
        
        return controller
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {
        // 无需更新
    }
}
