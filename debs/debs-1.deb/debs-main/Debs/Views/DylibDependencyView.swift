//
//  DylibDependencyView.swift
//  Debs
//
//  Created by Z on 2025/11/6.
//

import SwiftUI

struct DylibDependencyView: View {
    @Environment(\.dismiss) var dismiss
    let dylibURL: URL
    
    // 依赖列表数据状态
    @State private var dependencies: [String] = []
    @State private var isLoading = true
    
    // 编辑弹窗状态
    @State private var showingEditPrompt = false
    @State private var selectedOldPath: String = ""
    @State private var editingNewPath: String = ""
    
    // 结果反馈状态
    @State private var isProcessing = false
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""

    var body: some View {
        NavigationView {
            Form {
                Section(
                    header: Text("当前依赖列表"),
                    footer: Text("高级功能，不懂不建议修改！")
                ) {
                    if isLoading {
                        HStack {
                            Spacer()
                            ProgressView("正在读取依赖...")
                            Spacer()
                        }
                    } else if dependencies.isEmpty {
                        Text("未在文件中找到任何依赖")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(dependencies, id: \.self) { dep in
                            Button(action: {
                                selectedOldPath = dep
                                editingNewPath = dep
                                showingEditPrompt = true
                            }) {
                                Text(dep)
                                    .font(.system(.subheadline, design: .monospaced))
                                    .foregroundColor(.primary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("修改依赖") // 已移除文件路径或名称，仅显示纯标题
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                loadDependencies()
            }
            .overlay(
                Group {
                    if isProcessing {
                        Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
                        ProgressView("正在替换...")
                            .padding()
                            .background(Color(.systemBackground))
                            .cornerRadius(10)
                            .shadow(radius: 10)
                    }
                }
            )
            .alert("修改依赖", isPresented: $showingEditPrompt) {
                TextField("请输入新路径", text: $editingNewPath)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                Button("取消", role: .cancel) { }
                Button("确认替换") {
                    applyDependencyChange(oldPath: selectedOldPath, newPath: editingNewPath)
                }
            } message: {
                Text("原路径:\n\(selectedOldPath)")
            }
            .alert(alertTitle, isPresented: $showAlert) {
                Button("好的", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private func loadDependencies() {
        isLoading = true
        Task(priority: .userInitiated) {
            do {
                let foundDeps = try MachODependencyEditor.readDependencies(from: dylibURL)
                await MainActor.run {
                    self.dependencies = foundDeps
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.alertTitle = "读取失败"
                    self.alertMessage = error.localizedDescription
                    self.showAlert = true
                    self.isLoading = false
                }
            }
        }
    }
    
    private func applyDependencyChange(oldPath: String, newPath: String) {
        let oldPathClean = oldPath.trimmingCharacters(in: .whitespacesAndNewlines)
        let newPathClean = newPath.trimmingCharacters(in: .whitespacesAndNewlines)
        
        isProcessing = true
        
        Task(priority: .userInitiated) {
            do {
                try MachODependencyEditor.changeDependency(in: dylibURL, oldPath: oldPathClean, newPath: newPathClean)
                
                await MainActor.run {
                    alertTitle = "修改成功"
                    alertMessage = "已成功将依赖路径修改为:\n\(newPathClean)"
                    showAlert = true
                    isProcessing = false
                    loadDependencies()
                }
            } catch {
                await MainActor.run {
                    alertTitle = "修改失败"
                    alertMessage = error.localizedDescription
                    showAlert = true
                    isProcessing = false
                }
            }
        }
    }
}
