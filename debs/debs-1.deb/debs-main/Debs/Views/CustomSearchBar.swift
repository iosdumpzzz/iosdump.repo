//
//  CustomSearchBar.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct CustomSearchBar: View {
    @Binding var text: String
    let prompt: String
    @State private var isEditing = false

    var body: some View {
        HStack {
            TextField(prompt, text: $text, onEditingChanged: { editing in
                withAnimation {
                    self.isEditing = editing
                }
            })
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .padding(7)
            .padding(.horizontal, 25)
            .background(Color(.systemGray6))
            .cornerRadius(8)
            .overlay(
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 8)

                    if isEditing && !text.isEmpty {
                        Button(action: {
                            self.text = ""
                        }) {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(.gray)
                                .padding(.trailing, 8)
                        }
                    }
                }
            )

            if isEditing {
                Button("取消") {
                    self.isEditing = false
                    self.text = ""
                    // 收起键盘
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }
                .padding(.trailing, 1)
                .transition(.move(edge: .trailing))
                .animation(.default, value: isEditing)
            }
        }
    }
}
