//  SourcesView.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct SourcesView: View {
    @EnvironmentObject var sourceService: SourceService
    @EnvironmentObject var appUIState: AppUIState
    // 状态变量
    @State private var editMode: EditMode = .inactive
    @State private var sourceToNavigate: Source?
    @State private var isRefreshingAll = false
    @State private var showingShareSheet = false
    @State private var selection = Set<Source.ID>()
    @State private var showingAddOptions = false
    @State private var showingAddManualAlert = false
    @State private var sourceURLString = ""
    @State private var searchText = ""
    @State private var showingDeleteConfirm = false
    @State private var sourceToDelete: Source?
    // 搜索与筛选
    @Environment(\.isSearching) private var isSearchBarFocused
    @State private var searchTask: Task<Void, Never>?
    @State private var searchResults: [SearchablePackage] = []
    @State private var selectedArchIndex = 1 // 默认选中 arm64
    private let architectures = ["arm", "arm64", "arm64e"]
    
    @State private var selectedSearchModeIndex = 0 // 0 for 插件, 1 for 越狱源
    private let searchModes = ["插件", "越狱源"]
    
    // 控制管理我的越狱源弹窗
    @State private var showingManagedRepos = false
    
    private var filteredSources: [Source] {
        if searchText.isEmpty {
            return []
        } else {
            // 根据源名称或URL进行过滤
            return sourceService.sources.filter {
                $0.name.localizedCaseInsensitiveContains(searchText) ||
                $0.url.absoluteString.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    // 判断是否应显示搜索结果
    private var isSearching: Bool {
        !searchText.isEmpty
    }
    
    @ViewBuilder
    private var navigationContent: some View {
        NavigationView {
            // 使用我们刚刚创建的、已经包含了 Toolbar 的 viewWithToolbar
            viewWithToolbar
                .navigationTitle(isRefreshingAll ? "正在刷新..." : "越狱源")
                .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索所有源中的插件")
                .onSubmit(of: .search) {
                    Task(priority: .background) {
                        await performSearch()
                    }
                }
                .onChange(of: selectedArchIndex) { _ in
                    // 如果正在搜索，则调用我们的防抖函数
                    if !searchText.isEmpty {
                        debounceAndPerformSearch()
                    }
                }
                .onAppear {
                    sourceService.loadSources()
                    selection.removeAll()
                }
        }
        .navigationViewStyle(.stack)
    }
    
    @ViewBuilder
    private var viewWithToolbar: some View {
        // 根据 editMode 的状态，返回一个带有不同 .toolbar 的 contentView
        if editMode.isEditing {
            contentView
                .toolbar {
                    // 编辑模式下的 Toolbar
                    ToolbarItemGroup(placement: .navigationBarLeading) {
                        Button("取消") {
                            selection.removeAll()
                            editMode = .inactive
                        }
                    }
                    ToolbarItemGroup(placement: .navigationBarTrailing) {
                        Button(selection.count == sourceService.sources.count && !sourceService.sources.isEmpty ? "取消全选" : "全选") {
                            if selection.count == sourceService.sources.count {
                                selection.removeAll()
                            } else {
                                selection = Set(sourceService.sources.map { $0.id })
                            }
                        }
                        Button("删除") {
                            showingDeleteConfirm = true
                        }
                        .disabled(selection.isEmpty)
                    }
                }
        } else {
            contentView
                .toolbar {
                    // 正常模式下的 Toolbar（替换为了三个点的 Menu）
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            // 1. 添加按钮
                            Button {
                                showingAddOptions = true
                            } label: {
                                Label("添加越狱源", systemImage: "plus.circle")
                            }
                            
                            // 管理我的越狱源按钮
                            Button {
                                showingManagedRepos = true
                            } label: {
                                Label("我的越狱源", systemImage: "server.rack")
                            }
                            
                            // 2. 编辑按钮
                            Button {
                                editMode = .active
                            } label: {
                                Label("编辑源列表", systemImage: "signature")
                            }
                            .disabled(sourceService.sources.isEmpty)
                            
                            Divider() // 分割线
                            
                            // 3. 分享按钮
                            Button {
                                showingShareSheet = true
                            } label: {
                                Label("分享全部源", systemImage: "square.and.arrow.up")
                            }
                            .disabled(sourceService.sources.isEmpty)
                            
                        } label: {
                            Image(systemName: "ellipsis.circle")
                                .font(.system(size: 18))
                        }
                    }
                }
        }
    }

    // MARK: - Body
    var body: some View {
        navigationContent 
            .alert("添加越狱源", isPresented: $showingAddOptions) {
                Button("手动输入") { showingAddManualAlert = true }
                Button("从剪贴板粘贴") { pasteFromClipboard() }
                Button("取消", role: .cancel) { }
            } message: {
                Text("选择一种添加方式。")
            }
            .sheet(isPresented: $showingAddManualAlert) {
                AddSourceView { urlText in
                    Task {
                        appUIState.loadingMessage = "正在加载源数据..."
                        appUIState.isAddingSources = true

                        await sourceService.batchAddSources(from: urlText)

                        appUIState.isAddingSources = false
                    }
                }
            }
            .sheet(isPresented: $showingShareSheet) {
                let urlString = sourceService.sources
                    .map { $0.url.absoluteString }
                    .joined(separator: "\n")
                ShareSheet(items: [urlString])
            }
            .alert("确定删除", isPresented: $showingDeleteConfirm) {
                Button("删除", role: .destructive) {
                    deleteSelectedSources()
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("确定要删除选中的 \(selection.count) 个越狱源吗？此操作不可撤销。")
            }
            .alert(
                "确定删除",
                isPresented: Binding(
                    get: { sourceToDelete != nil },
                    set: { if !$0 { sourceToDelete = nil } }
                ),
                presenting: sourceToDelete
            ) { source in
                Button("删除", role: .destructive) {
                    Task {
                        appUIState.loadingMessage = "正在删除..."
                        appUIState.isDeleting = true
                        await sourceService.deleteSource(source)
                        appUIState.isDeleting = false
                    }
                }
                Button("取消", role: .cancel) {}
            } message: { source in
                Text("确定要删除越狱源 “\(source.name)” 吗？此操作不可撤销。")
            }
            .sheet(isPresented: $showingManagedRepos) {
                ManagedReposListView()
                    .environmentObject(appUIState)
                    .interactiveDismissDisabled(true)
            }
    }


    // MARK: - Subviews
    
    @ViewBuilder
    private var contentView: some View {
        ZStack {
            // --- 视图一：默认的源列表 ---
            sourceList
                .opacity(searchText.isEmpty ? 1.0 : 0.0)

            // --- 视图二：完整的搜索界面 ---
            VStack(spacing: 0) {
                // “插件/源”模式切换器
                FilterControl(selectedIndex: $selectedSearchModeIndex, items: searchModes)
                    .padding(.horizontal)
                    .padding(.top, 8)
                    .padding(.bottom, 8)

                // 根据选择的模式，显示对应内容
                if selectedSearchModeIndex == 0 { // 模式 0: 搜索插件
                    FilterControl(selectedIndex: $selectedArchIndex, items: architectures)
                        .padding(.horizontal)
                        .padding(.vertical, 8)
 
                    searchResultsList
                } else { // 模式 1: 搜索越狱源
                    List(filteredSources) { source in
                        NavigationLink(destination: PackageListView(source: source)) {
                            HStack(spacing: 15) {
                                Image(uiImage: source.icon ?? UIImage(systemName: "shippingbox.fill")!)
                                    .resizable().aspectRatio(contentMode: .fit)
                                    .frame(width: 40, height: 40).cornerRadius(8)
                                VStack(alignment: .leading) {
                                    Text(source.name).font(.headline)
                                    Text(source.url.absoluteString).font(.caption).foregroundColor(.secondary).lineLimit(1)
                                }
                            }
                            .padding(.vertical, 5)
                        }
                    }
                    .listStyle(InsetGroupedListStyle())
                }
            }
            .opacity(searchText.isEmpty ? 0.0 : 1.0)
            .allowsHitTesting(!searchText.isEmpty)

        }
        .animation(.easeOut(duration: 0.2), value: searchText.isEmpty)
        .background(Color(.systemGroupedBackground))
    }
    
    @ViewBuilder
    private var sourceList: some View {
        if sourceService.sources.isEmpty {
            VStack(spacing: 15) {
                Spacer() 
                
                Image(systemName: "arrow.up.right.circle.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.secondary.opacity(0.6))
                
                Text("列表为空")
                    .font(.title2)
                    .fontWeight(.bold)
  
                Text("请点击右上角的 '+' 按钮添加越狱源。")
                    .font(.callout)
                    .foregroundColor(.secondary)
                
                Spacer() 
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .transition(.opacity.animation(.easeIn))
            
        } else {
            List(selection: $selection) {
                ForEach(sourceService.sources) { source in
                    NavigationLink(destination: PackageListView(source: source)) {
                        HStack(spacing: 15) {
                            Image(uiImage: source.icon ?? UIImage(systemName: "shippingbox.fill")!)
                                .resizable().aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40).cornerRadius(8)

                            VStack(alignment: .leading) {
                                Text(source.name).font(.headline)
                                Text(source.url.absoluteString).font(.caption).foregroundColor(.secondary).lineLimit(1)
                                Spacer()
                                    .frame(height: 8)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .overlay(alignment: .bottom) { 
                                if sourceService.refreshingSources.contains(source.id) {
                                    AestheticProgressView()
                                }
                            }
                            
                        }
                        .padding(.vertical, 5)
                    }
                    .disabled(editMode.isEditing)
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button {
                            UIPasteboard.general.string = source.url.absoluteString
                        } label: {
                            Label("复制", systemImage: "doc.on.doc")
                        }
                        .tint(.orange)

                        Button {
                            Task {
                                appUIState.loadingMessage = "正在刷新 \(source.name)..."
                                appUIState.isRefreshing = true
                                await sourceService.updateSourceDetails(for: source)
                                try? await Task.sleep(nanoseconds: 1_000_000_000)
                                appUIState.isRefreshing = false
                            }
                        } label: {
                            Label("刷新", systemImage: "arrow.clockwise")
                        }
                        .tint(.blue)
                        
                        Button(role: .destructive) {
                            sourceToDelete = source
                        } label: {
                            Label("删除", systemImage: "trash.fill")
                        }
                    }
                }
                // ▼▼▼ 新增：支持直接拖拽排序源列表 ▼▼▼
                .onMove { sourceIndices, destination in
                    sourceService.moveSource(from: sourceIndices, to: destination)
                }
                // ▲▲▲ 新增结束 ▲▲▲
            }
            .listStyle(InsetGroupedListStyle())
            .refreshable {
                isRefreshingAll = true
                appUIState.loadingMessage = "正在刷新所有源数据..."
                appUIState.isRefreshing = true
                await sourceService.refreshAllSources()
                isRefreshingAll = false
                appUIState.isRefreshing = false
            }
            .environment(\.editMode, $editMode)
        }
    }
    
    private var searchResultsList: some View {
        let searchID = "\(searchText)-\(selectedSearchModeIndex)-\(selectedArchIndex)"
        return List(searchResults) { result in
            NavigationLink(destination: PackageDetailView(package: result.package, source: result.source)) {
                HStack(spacing: 12) {
                    CachedAsyncImage(url: result.package.iconURL(forSource: result.source)) { image in
                        image.resizable().aspectRatio(contentMode: .fit)
                    } placeholder: {
                        Image(systemName: "archivebox.fill").foregroundColor(.secondary)
                    }
                    .frame(width: 44, height: 44)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    
                    VStack(alignment: .leading, spacing: 3) {
                        Text(result.package.name)
                            .font(.headline)
                        
                        Text(result.package.packageDescription)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .lineLimit(1) 
                            
                        Text(result.package.version) 
                            .font(.caption2)
                            .foregroundColor(.accentColor)
                            
                        Text("来自: \(result.source.name)")
                            .font(.caption2)
                            .foregroundColor(.secondary) 
                    }
                }
                .padding(.vertical, 4)
                .frame(minHeight: 65)
            }
        }
        .listStyle(InsetGroupedListStyle())
        .id(searchID)
    }
    
    // MARK: - Actions
    
    private func pasteFromClipboard() {
        if let pasteboardString = UIPasteboard.general.string {
            Task {
                appUIState.loadingMessage = "正在加载源数据..."
                appUIState.isAddingSources = true
                
                await sourceService.batchAddSources(from: pasteboardString)
                
                appUIState.isAddingSources = false
            }
        }
    }
    
    private func deleteSource(at offsets: IndexSet) {
        Task {
            appUIState.loadingMessage = "正在删除源数据..."
            appUIState.isDeleting = true
            await Task.yield()
            
            let sourcesToDelete = offsets.map { sourceService.sources[$0] }
            
            for source in sourcesToDelete {
                await sourceService.deleteSource(source)
            }
            
            appUIState.isDeleting = false
        }
    }
    
    private func debounceAndPerformSearch() {
        searchTask?.cancel()
        searchTask = Task {
            do {
                try await Task.sleep(nanoseconds: 300_000_000)

                if Task.isCancelled { return }
                await performSearch()

            } catch {
                print("Search task cancelled.")
            }
        }
    }

    private func performSearch() async {
        if Task.isCancelled { return }

        if searchText.isEmpty {
            await MainActor.run {
                searchResults = []
            }
        } else {
            do {
                let selectedArch = architectures[selectedArchIndex]
                let results = try await sourceService.searchAllPackages(query: searchText, architecture: selectedArch)
                
                if Task.isCancelled { return }
                
                await MainActor.run {
                    searchResults = results
                }
            } catch {
                print("Search task was cancelled or failed with error: \(error.localizedDescription)")
            }
        }
    }

    private func deleteSelectedSources() {
        Task {
            appUIState.loadingMessage = "正在删除源数据..."
            appUIState.isDeleting = true

            await Task.yield()

            let sourcesToDelete = sourceService.sources.filter { selection.contains($0.id) }
            for source in sourcesToDelete {
                await sourceService.deleteSource(source)
            }
            
            await MainActor.run {
                selection.removeAll()
                editMode = .inactive
            }

            appUIState.isDeleting = false
        }
    }
}
