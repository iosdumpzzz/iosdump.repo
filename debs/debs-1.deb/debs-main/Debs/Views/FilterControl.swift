//
//  FilterControl.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

struct FilterControl: View {
    @Binding var selectedIndex: Int
    let items: [String]

    @Namespace private var animation

    var body: some View {
        ZStack {
            // --- 背景层 ---
            // 修改为 secondarySystemGroupedBackground，在浅色模式下是白色，实现图片效果
            RoundedRectangle(cornerRadius: 9)
                .fill(Color(.secondarySystemGroupedBackground))

            // --- 气泡动画层 (独立布局) ---
            HStack(spacing: 2) {
                ForEach(items.indices, id: \.self) { index in
                    if selectedIndex == index {
                        // 选中的气泡为浅灰色，与白色背景形成对比
                        RoundedRectangle(cornerRadius: 7)
                            .fill(Color(.systemGray5))
                            .matchedGeometryEffect(id: "selectionBubble", in: animation)
                    } else {
                        Color.clear
                    }
                }
            }
            .padding(2)

            // --- 文字与交互层 (独立布局) ---
            HStack(spacing: 2) {
                ForEach(items.indices, id: \.self) { index in
                    Text(items[index])
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(selectedIndex == index ? .primary : .secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                                selectedIndex = index
                            }
                        }
                }
            }
            .padding(2)
        }
        .frame(height: 28)
    }
}
