//
//  SettingsView.swift
//  Debs
//

import SwiftUI

struct SettingsView: View {
    // 使用 @AppStorage 将设置直接保存在 UserDefaults 中
    @AppStorage("renameDebsToPackageNameEnabled") private var renameEnabled = true
    @AppStorage("com.apple.SwiftUI.IgnoreSolariumLinkedOnCheck") private var enableLiquidGlass: Bool = false
    @AppStorage("globalUploadRepoPath") private var globalUploadPath: String = "debs"

    // 用于关闭页面的环境值
    @Environment(\.dismiss) var dismiss
    
    // +++ 新增：用于控制退出确认弹窗的状态 +++
    @State private var showingQuitAlert = false
    
    @State private var showingCustomPathAlert = false
    @State private var tempCustomPath = ""
    
    // ▼▼▼ 新增：获取版本号的计算属性 ▼▼▼
        private var appVersion: String {
            // 从 Info.plist 读取版本号 (CFBundleShortVersionString)
            Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "N/A"
        }
        // ▲▲▲ 新增结束 ▲▲▲

    var body: some View {
        NavigationView {
            Form {
                // --- 下载设置区块 ---
                Section(
                    header: Text("下载设置"),
                    footer: Text("开启后，下载的.deb文件将自动重命名为“插件名-版本号.deb”，方便识别。关闭则保留原始文件名。")
                ) {
                    Toggle("以插件名称命名下载文件", isOn: $renameEnabled)

                }
                
                Section(
                    header: Text("上传越狱源设置"),
                    footer: Text("配置全局快捷上传越狱源时的目标文件夹。留空为根目录。")
                ) {
                    HStack {
                        Text("上传目录")
                        Spacer()
                        Menu {
                            Button("默认 (debs目录)") {
                                globalUploadPath = "debs"
                            }
                            Button("自定义目录") {
                                tempCustomPath = globalUploadPath
                                showingCustomPathAlert = true
                            }
                        } label: {
                            Text(globalUploadPath.isEmpty ? "根目录" : globalUploadPath)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // ▼▼▼ 在这里添加新的“关于” Section ▼▼▼
                                Section("关于") {
                                    // 使用受保护的链接
                                    Link(destination: URL(string: ResourceHelper.contactURLString())!) {
                                        // 自定义按钮的外观，使其看起来像一个标准的列表行
                                        HStack {
                                            Text("作者")
                                            Spacer()
                                            Image(systemName: "safari")
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                    .foregroundColor(.primary) // 确保文本颜色是标准的黑色/白色
                                    // 版本号显示行
                                                HStack {
                                                    Text("版本号")
                                                    Spacer()
                                                    Text(appVersion) // 使用我们新创建的计算属性
                                                        .foregroundColor(.secondary)
                                                }
                                                }
                                                // ▲▲▲ 修改结束 ▲▲▲

                
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
            // +++ 新增：添加弹窗逻辑 +++
            .alert("需要重启以应用更改", isPresented: $showingQuitAlert) {
                Button("立即退出", role: .destructive) {
                    // 用户点击“立即退出”，调用我们新创建的函数
                    UIApplication.shared.forceQuit()
                }
                Button("稍后手动重启", role: .cancel) {}
            } message: {
                Text("此设置需要退出应用才能生效。")
            }
            .alert("自定义目录", isPresented: $showingCustomPathAlert) {
                TextField("留空为根目录", text: $tempCustomPath)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                Button("取消", role: .cancel) {}
                Button("确定") {
                    var trimmed = tempCustomPath.trimmingCharacters(in: .whitespacesAndNewlines)
                    while trimmed.hasPrefix("/") { trimmed.removeFirst() }
                    while trimmed.hasSuffix("/") { trimmed.removeLast() }
                    globalUploadPath = trimmed
                }
            } message: {
                Text("输入快捷上传的默认目录。")
            }
            .onAppear {
                ResourceHelper.ensureValid()
            }
        }
    }
}
