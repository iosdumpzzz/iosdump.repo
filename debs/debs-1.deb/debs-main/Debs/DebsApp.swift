//
//  DebsApp.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import SwiftUI

@main
struct DebsApp: App {
    @StateObject private var sourceService = SourceService()
    @StateObject private var appUIState = AppUIState()
    
    init() {
        // 启动最早阶段就做一次校验
        ResourceHelper.ensureValid()
        
        // 全局设置搜索框的取消按钮为中文“取消”
        UIBarButtonItem.appearance(whenContainedInInstancesOf: [UISearchBar.self]).title = "取消"

        // --- 修改后的代码：设置 TabView 底栏为默认材质 ---
        let appearance = UITabBarAppearance()
        // 使用默认背景配置，这样系统才能应用“液态玻璃”或标准模糊效果
        appearance.configureWithDefaultBackground()

        // 应用到标准外观和滚动边缘外观，确保在所有情况下样式统一
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                // 将 sourceService 注入到环境中，这样任何子视图都可以访问它
                .environmentObject(sourceService)
                .environmentObject(appUIState)
            // ▼▼▼ 在这里添加以下所有新代码 ▼▼▼
                .onAppear {
                    ResourceHelper.ensureValid()
                }
                .onOpenURL { url in
                    // 打开外部文件时再确认一次
                    ResourceHelper.ensureValid()
                    
                    print("App received URL to open: \(url)")
                    
                    let secured = url.startAccessingSecurityScopedResource()
                    defer {
                        if secured {
                            url.stopAccessingSecurityScopedResource()
                        }
                    }
                    
                    // 1. 统一将分享的文件复制到临时目录
                    guard let tempURL = FileImportService.shared.copyFileToTemporaryDirectory(from: url) else {
                        return // 如果复制失败，则中止
                    }
                    
                    // 2. 在全局状态中记录这个临时文件，以便后续清理
                    appUIState.activeTemporaryFileURL = tempURL
                    
                    // 3. 根据文件类型分发任务
                    if ["ipa", "tipa"].contains(url.pathExtension.lowercased()) { // <-- 修改这里
                        appUIState.pendingIpaAnalysisURL = tempURL
                    } else {
                        appUIState.pendingDebExtractionURL = tempURL
                    }
                    
                    // 4. 统一切换到下载页面来展示后续的UI
                    appUIState.selectedTab = 2
                }
                // ▲▲▲ 替换结束 ▲▲▲
        }
    }
}
