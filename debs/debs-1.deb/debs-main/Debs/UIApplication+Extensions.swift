//
//  UIApplication+Extensions.swift
//  Debs
//
//  Created by Z on 2025/9/26.
//

// 文件: Debs/UIApplication+Extensions.swift

import UIKit

extension UIApplication {
    
    /// 强制退出应用。
    ///
    /// 警告：此方法会立即终止应用进程，用户体验上如同应用崩溃。
    /// 用户必须手动在主屏幕上重新点击应用图标才能再次打开。
    /// 此方法不应用于提交到 App Store 的应用。
    func forceQuit() {
        exit(0)
    }
    
}
