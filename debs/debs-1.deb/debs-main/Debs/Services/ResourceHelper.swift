//
//  ResourceHelper.swift
//  Debs
//

import Foundation

enum ResourceHelper {
    
    // MARK: - 内部还原（不要直接写明文）
    
    private static func _b() -> String {
        // com.iosdump.Debs.Debs
        let p1: [UInt8] = [99, 111, 109, 46]
        let p2: [UInt8] = [105, 111, 115, 100, 117, 109, 112, 46]
        let p3: [UInt8] = [68, 101, 98, 115, 46]
        let p4: [UInt8] = [68, 101, 98, 115]
        return String(bytes: p1 + p2 + p3 + p4, encoding: .utf8) ?? ""
    }
    
    private static func _t() -> String {
        // https://t.me/iosdumpzzz
        let a: [UInt8] = [104, 116, 116, 112, 115, 58, 47, 47, 116, 46, 109, 101, 47]
        let b: [UInt8] = [105, 111, 115, 100, 117, 109, 112, 122, 122, 122]
        return String(bytes: a + b, encoding: .utf8) ?? ""
    }
    
    private static func _h(_ s: String) -> UInt64 {
        var h: UInt64 = 14695981039346656037
        for byte in s.utf8 {
            h ^= UInt64(byte)
            h = h &* 1099511628211
        }
        return h
    }
    
    // 预计算哈希（FNV-1a）
    private static let _hb: UInt64 = 0x6545554108679f8f
    private static let _ht: UInt64 = 0xcaca2e504421f578
    
    // MARK: - 公开接口（名字故意普通）
    
    /// 获取受保护的 Telegram 链接（外部调用这个）
    static func contactURLString() -> String {
        return _t()
    }
    
    /// 静默校验（返回是否完整）
    @inline(__always)
    static func validateResources() -> Bool {
        let bid = Bundle.main.bundleIdentifier ?? ""
        let link = _t()
        
        let bidOK = _h(bid) == _hb
        let linkOK = _h(link) == _ht
        
        return bidOK && linkOK
    }
    
    /// 如果被篡改则触发看起来像普通崩溃的闪退
    @inline(__always)
    static func ensureValid() {
        #if !DEBUG
        guard validateResources() else {
            // 故意做成普通空指针崩溃，逆向时不容易立刻关联到校验逻辑
            let p: UnsafeMutablePointer<Int>? = nil
            p!.pointee = 0
            return
        }
        #endif
    }
}
