//  SourceService.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import Foundation
import UIKit

@MainActor
class SourceService: ObservableObject {
    @Published var sources: [Source] = []
    @Published var refreshingSources = Set<URL>()
    
    @Published var allPackages: [SearchablePackage] = []
    
    // 定义索引文件的存储路径
    private var searchIndexFileURL: URL {
        let paths = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        return paths[0].appendingPathComponent("search_index.plist")
    }

    /// 尝试从硬盘加载经过优化的索引文件
    /// - Returns: 如果加载成功则返回 true，否则返回 false
    private func loadIndexFromDisk() -> Bool {
        do {
            // 1. 读取包含优化后结构的索引文件
            let data = try Data(contentsOf: searchIndexFileURL)
            let decoder = PropertyListDecoder()
            let savedIndex = try decoder.decode(SavedIndex.self, from: data)

            // 2. 准备一个空数组，用于重建内存中的 allPackages 列表
            var reconstructedPackages: [SearchablePackage] = []
            
            // 3. 遍历从磁盘加载的字典，将其“展开”为内存中使用的 [SearchablePackage] 格式
            for (sourceURL, packages) in savedIndex.packagesBySource {
                // 从源字典中找到对应的源信息
                if let source = savedIndex.sources[sourceURL] {
                    // 遍历该源下的所有插件，并重新组合成 SearchablePackage
                    for package in packages {
                        reconstructedPackages.append(SearchablePackage(package: package, source: source))
                    }
                }
            }
            
            // 4. 将重建好的列表赋值给 allPackages，供 App 使用
            self.allPackages = reconstructedPackages
            print(" ✅ Successfully loaded (optimized) search index from disk with \(self.allPackages.count) packages.")
            return true
        } catch {
            // 如果加载新格式失败（可能是旧格式的索引文件或文件损坏），则打印错误并返回 false，
            // 这样 App 就会触发一次重建索引的流程。
            print("Could not load optimized index from disk (file may be old format or corrupt): \(error)")
            return false
        }
    }

    /// 将当前的内存索引以优化的结构保存到硬盘
    private func saveIndexToDisk() {
        // 1. 准备用于存储优化后数据的字典
        var sourcesDict: [URL: Source] = [:]
        var packagesDict: [URL: [Package]] = [:]

        // 2. 遍历内存中的 allPackages 列表，将其转换为去重、高效的字典结构
        for searchablePackage in allPackages {
            let sourceURL = searchablePackage.source.url
            
            // 如果源信息还没存，就存一次
            if sourcesDict[sourceURL] == nil {
                sourcesDict[sourceURL] = searchablePackage.source
            }
            
            // 如果这个源的插件列表还不存在，就为它创建一个空列表
            if packagesDict[sourceURL] == nil {
                packagesDict[sourceURL] = []
            }
            
            // 将当前插件添加到其对应源的插件列表中
            packagesDict[sourceURL]?.append(searchablePackage.package)
        }

        // 3. 创建最终要保存到磁盘的、经过优化的对象
        let indexToSave = SavedIndex(sources: sourcesDict, packagesBySource: packagesDict)

        // 4. 编码这个优化后的、体积小得多的对象。这一步的内存峰值会显著降低。
        do {
            let encoder = PropertyListEncoder()
            let data = try encoder.encode(indexToSave)
            try data.write(to: searchIndexFileURL)
            print(" ✅ Successfully saved (optimized) search index to disk.")
        } catch {
            print(" ❌ Failed to save (optimized) search index to disk: \(error)")
        }
    }
    
    private let sourcesFileURL: URL
    
    private struct SavedIndex: Codable {
            /// 存储所有源的信息，以 URL 为键，确保每个源只存一次
            let sources: [URL: Source]
            /// 存储每个源对应的插件列表，以源的 URL 为键
            let packagesBySource: [URL: [Package]]
        }

    init() {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        self.sourcesFileURL = paths[0].appendingPathComponent("sources.plist")
        loadSources()
        
        // 启动时，首先尝试从硬盘加载索引
        if !loadIndexFromDisk() {
            // 如果加载失败（比如首次启动），则在后台构建一次初始索引
            buildCombinedPackageIndex()
        }
    }
    
    func buildCombinedPackageIndex() {
        print("Building combined package index from source caches...")
        Task(priority: .background) {
            var combinedList: [SearchablePackage] = []
            let searchSources = self.sources
            
            // 这部分繁重工作已经在后台，保持不变
            for source in searchSources {
                let cacheURL = self.packagesCacheFileURL(for: source)
                guard let cachedData = try? Data(contentsOf: cacheURL) else { continue }
                
                do {
                    let packageDicts = try PropertyListDecoder().decode([[String: String]].self, from: cachedData)
                    let packages = packageDicts.compactMap { Package(controlData: $0) }
                    for package in packages {
                        combinedList.append(SearchablePackage(package: package, source: source))
                    }
                } catch {
                    print("Failed to decode package cache for \(source.name) while building index: \(error)")
                }
            }
            
            await MainActor.run {
                self.allPackages = combinedList
                print("✅ Combined package index built with \(self.allPackages.count) total packages. UI updated.")
            }
            
            // 步骤2: 在UI更新后，返回到后台线程继续执行耗时的保存操作
            print("Now saving index to disk in the background...")
            self.saveIndexToDisk()
        }
    }

    // MARK: - Source Management (Add, Delete, Load, Save)
    
    func loadSources() {
        do {
            let data = try Data(contentsOf: sourcesFileURL)
            let decoder = PropertyListDecoder()
            self.sources = try decoder.decode([Source].self, from: data)
        } catch {
            print("Could not load sources, starting fresh.")
            if self.sources.isEmpty {
                // User will start with an empty list.
            }
        }
    }

    private func saveSources() {
        do {
            let encoder = PropertyListEncoder()
            let data = try encoder.encode(sources)
            try data.write(to: sourcesFileURL)
        } catch {
            print("Failed to save sources: \(error.localizedDescription)")
        }
    }

    // 添加源时，也触发预缓存
    private func addSource(url: URL) async {
        guard !sources.contains(where: { $0.url == url }) else { return }
        let newSource = Source(url: url, name: url.host ?? url.absoluteString)
        sources.append(newSource)
        await updateSourceDetails(for: newSource) // updateSourceDetails now handles precaching
    }

    func batchAddSources(from string: String) async {
        let separators = CharacterSet(charactersIn: ",\n")
        let urlStrings = string.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        
        await withTaskGroup(of: Void.self) { group in
            for urlString in urlStrings {
                if let url = URL(string: urlString) {
                    group.addTask {
                        await self.addSource(url: url)
                    }
                }
            }
        }
        
        // buildCombinedPackageIndex() 现在是 batchAddSources 异步任务的一部分
        self.buildCombinedPackageIndex()
    }

    func deleteSource(_ source: Source) async {
        // 从源列表中移除
        sources.removeAll { $0.id == source.id }
        saveSources()
        
        // 从插件缓存文件中删除
        let cacheURL = packagesCacheFileURL(for: source)
        try? FileManager.default.removeItem(at: cacheURL)
        
        // 从内存索引中高效移除，并重新保存到硬盘
        allPackages.removeAll { $0.source.id == source.id }
        saveIndexToDisk()
    }
    
    // ▼▼▼ 新增：移动源位置并持久化保存 ▼▼▼
    func moveSource(from source: IndexSet, to destination: Int) {
        sources.move(fromOffsets: source, toOffset: destination)
        saveSources()
    }
    // ▲▲▲ 新增结束 ▲▲▲

    // MARK: - Source Refreshing & Pre-caching (The TrollStore Strategy)
    
    func refreshAllSources() async {
        print("Refreshing all sources...")
        await withTaskGroup(of: Void.self) { group in
            for source in self.sources {
                group.addTask {
                    await self.updateSourceDetails(for: source)
                }
            }
        }

        print("All sources refreshed. Now building index...")
        self.buildCombinedPackageIndex()
    }

    // 刷新单个源的详情（名称、图标），完成后立即预缓存其插件列表
    func updateSourceDetails(for source: Source) async {
        var failureCount = 0 // 1. 为每个源创建一个失败计数器
        let failureLimit = 3   // 2. 定义失败上限

        refreshingSources.insert(source.id)
        defer {
            refreshingSources.remove(source.id)
        }

        guard let index = sources.firstIndex(where: { $0.id == source.id }) else { return }

        // 1. Fetch Release file for name
        let releaseURL = source.url.appendingPathComponent("Release")
        var officialName = source.name
        do {
            let (releaseData, _) = try await URLSession.shared.data(from: releaseURL)
            if let releaseString = String(data: releaseData, encoding: .utf8) {
                let lines = releaseString.components(separatedBy: .newlines)
                let nameLine = lines.first { $0.starts(with: "Origin:") || $0.starts(with: "Label:") }
                if let nameLine = nameLine, let separatorIndex = nameLine.firstIndex(of: ":") {
                    officialName = String(nameLine[nameLine.index(after: separatorIndex)...]).trimmingCharacters(in: .whitespaces)
                }
            }
        } catch {
            print("Could not fetch Release file for \(source.url), using existing name. Error: \(error.localizedDescription)")
            failureCount += 1 // 3. 第一次失败
        }
        self.sources[index].name = officialName

        // 4. 在进行下一步网络请求前，检查失败次数
        guard failureCount < failureLimit else {
            print("  ❌  Source \(source.name) failed too many times (\(failureCount)) before fetching icon. Aborting.")
            return
        }

        // 2. Fetch Icon
        let iconFilenames = ["CydiaIcon@2x.png", "CydiaIcon.png", "icon.png"]
        var foundIconData: Data?
        for filename in iconFilenames {
            // 5. 在循环内部也检查，避免不必要的请求
            guard failureCount < failureLimit else { break }

            let iconURL = source.url.appendingPathComponent(filename)
            do {
                let (iconData, response) = try await URLSession.shared.data(from: iconURL)
                guard (response as? HTTPURLResponse)?.statusCode == 200, !iconData.isEmpty else {
                    failureCount += 1 // 6. 将非200状态码也视为失败
                    continue
                }
                foundIconData = iconData
                break
            } catch {
                failureCount += 1 // 7. 图标下载失败
                continue
            }
        }
        self.sources[index].iconData = foundIconData
        self.saveSources() // 保存已更新的源信息（即使后续失败，名称和图标也可能已更新）

        // 8. 在进行最终的插件列表缓存前，再次检查总失败次数
        guard failureCount < failureLimit else {
            print("  ❌  Source \(source.name) failed too many times (\(failureCount)) before precaching. Aborting.")
            return
        }

        // 9. 调用我们第一步修改的函数，并接收它返回的失败次数
        let precacheResult = await precachePackages(for: source)
        let precacheSuccess = precacheResult.success

        if precacheSuccess {
            Task(priority: .background) {
                print("Single source refresh successful. Rebuilding index in background...")
                self.buildCombinedPackageIndex()
            }
        }
    }
    
    // **核心优化**: 此方法现在返回一个元组，包含是否成功以及失败的次数
    private nonisolated func precachePackages(for source: Source) async -> (success: Bool, failures: Int) {
        print("Precaching packages for \(source.name) from network.")
        let packageFileNames = ["Packages.bz2", "Packages.gz", "Packages"]
        var failures = 0 // <-- 新增：失败计数器

        for fileName in packageFileNames {
            let url = source.url.appendingPathComponent(fileName)
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                    // 将服务器返回的非 200 状态码也视为一次失败
                    failures += 1
                    continue
                }

                let decompressedData: Data?
                if fileName.hasSuffix(".bz2") { decompressedData = decompressBZ2(data: data) }
                else if fileName.hasSuffix(".gz") { decompressedData = decompressGzip(data: data) }
                else { decompressedData = data }

                if let data = decompressedData, let packagesString = String(data: data, encoding: .utf8) {
                    let packageDicts = parsePackagesString(from: packagesString)
                    let cacheURL = packagesCacheFileURL(for: source)
                    do {
                        let plistData = try PropertyListEncoder().encode(packageDicts)
                        try plistData.write(to: cacheURL)
                        print("Successfully precached \(packageDicts.count) packages for \(source.name).")
                        return (success: true, failures: failures) // <-- 修改：成功时返回 true 和当前的失败次数
                    } catch {
                        print("Failed to write package cache for \(source.name): \(error)")
                        failures += 1 // 写入缓存失败也算一次失败
                        return (success: false, failures: failures) // <-- 修改：失败时返回 false 和当前的失败次数
                    }
                }
            } catch {
                // 网络错误等，增加失败计数并继续尝试下一个文件名
                print("Failed to fetch \(fileName) for \(source.name): \(error.localizedDescription)")
                failures += 1 // <-- 新增：网络请求失败，计数器加1
                continue
            }
        }

        // 如果循环结束都没有成功，说明此源无效
        print("  ❌  Failed to precache packages for \(source.name). All attempts failed.")
        return (success: false, failures: failures) // <-- 修改：最终失败时，返回 false 和总失败次数
    }

    // MARK: - Search Logic (Optimized for performance)
    
    func searchAllPackages(query: String, architecture: String) async throws -> [SearchablePackage] {
        // 步骤 1: 在主线程上安全地获取 allPackages 的一个副本。
        // 因为数组是值类型，这里会创建一个独立的数据拷贝。
        let packagesToSearch = self.allPackages

        return await Task.detached(priority: .userInitiated) {
                // --- 内部的过滤逻辑完全保持不变 ---
                let textFiltered = packagesToSearch.filter { result in
                    query.isEmpty ||
                    result.package.name.localizedCaseInsensitiveContains(query) ||
                    result.package.packageDescription.localizedCaseInsensitiveContains(query)
                }

            let filteredByArch = textFiltered.filter { result in
                let pkgArch = result.package.architecture.lowercased()
                switch architecture {
                case "arm":  return (pkgArch.contains("arm") && !pkgArch.contains("arm64")) || pkgArch.contains("i386")
                case "arm64":  return pkgArch.contains("arm64") && !pkgArch.contains("arm64e")
                case "arm64e":  return pkgArch.contains("arm64e")
                default :  return true
                }
            }

            return filteredByArch.sorted { $0.package.name.localizedCaseInsensitiveCompare($1.package.name) == .orderedAscending }
            
        }.value
    }

    // **核心优化**: 用于从单个源的插件列表页面加载，同样只读取缓存
    func loadPackagesFromCache(for source: Source) async -> [Package] {
        let cacheURL = packagesCacheFileURL(for: source)
        if let cachedData = try? Data(contentsOf: cacheURL) {
            do {
                let packageDicts = try PropertyListDecoder().decode([[String: String]].self, from: cachedData)
                return packageDicts.compactMap { Package(controlData: $0) }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            } catch {
                print("Failed to decode package cache for \(source.name) on package list view: \(error)")
            }
        }
        // 如果缓存不存在，说明预缓存失败或还未进行，返回空数组
        return []
    }

    // MARK: - Parsing & Decompression (Utility functions)
    
    // 解析 Packages 字符串为字典数组
    nonisolated private func parsePackagesString(from text: String) -> [[String: String]] {
        var packageDicts = [[String: String]]()
        let packageBlocks = text.components(separatedBy: "\n\n")
        for block in packageBlocks where !block.isEmpty {
            var controlData = [String: String]()
            let lines = block.components(separatedBy: .newlines)
            for line in lines {
                if let separatorIndex = line.firstIndex(of: ":") {
                    let key = String(line[..<separatorIndex]).trimmingCharacters(in: .whitespaces)
                    let value = String(line[line.index(after: separatorIndex)...]).trimmingCharacters(in: .whitespaces)
                    controlData[key] = value
                }
            }
            if !controlData.isEmpty {
                packageDicts.append(controlData)
            }
        }
        return packageDicts
    }

    // 获取缓存文件路径（现在用于已解析的 plist）
    nonisolated private func packagesCacheFileURL(for source: Source) -> URL {
        let paths = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        let cacheDirectory = paths[0].appendingPathComponent("pkg_cache_parsed")
        if !FileManager.default.fileExists(atPath: cacheDirectory.path) {
            try? FileManager.default.createDirectory(at: cacheDirectory, withIntermediateDirectories: true)
        }
        // 使用 URL 的 hash 作为文件名，安全且唯一
        let fileName = "\(source.url.absoluteString.hash).plist"
        return cacheDirectory.appendingPathComponent(fileName)
    }

    // Decompression methods (unchanged)
    nonisolated private func decompressBZ2(data: Data) -> Data? {
        guard !data.isEmpty else { return nil }
        var stream = bz_stream()
        var decompressedData = Data()
        guard BZ2_bzDecompressInit(&stream, 0, 0) == BZ_OK else { return nil }
        data.withUnsafeBytes { (sourcePtr: UnsafeRawBufferPointer) in
            stream.next_in = UnsafeMutablePointer<CChar>(mutating: sourcePtr.baseAddress!.assumingMemoryBound(to: CChar.self))
            stream.avail_in = UInt32(data.count)
            let bufferSize = 32768
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            var result: Int32
            repeat {
                result = buffer.withUnsafeMutableBytes { bufferPtr -> Int32 in
                    stream.next_out = bufferPtr.baseAddress!.assumingMemoryBound(to: CChar.self)
                    stream.avail_out = UInt32(bufferSize)
                    let decompressResult = BZ2_bzDecompress(&stream)
                    if decompressResult == BZ_OK || decompressResult == BZ_STREAM_END {
                        let bytesWritten = bufferSize - Int(stream.avail_out)
                        decompressedData.append(contentsOf: bufferPtr.prefix(bytesWritten))
                    }
                    return decompressResult
                }
            } while result == BZ_OK
        }
        BZ2_bzDecompressEnd(&stream)
        return decompressedData
    }
    
    nonisolated private func decompressGzip(data: Data) -> Data? {
        guard !data.isEmpty else { return nil }
        var stream = z_stream()
        var decompressedData: Data? = Data()
        data.withUnsafeBytes { (sourcePtr: UnsafeRawBufferPointer) in
            stream.next_in = UnsafeMutablePointer<Bytef>(mutating: sourcePtr.baseAddress!.assumingMemoryBound(to: Bytef.self))
            stream.avail_in = uInt(data.count)
            var buffer = [UInt8](repeating: 0, count: 32768)
            guard inflateInit2_(&stream, 16 + MAX_WBITS, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size)) == Z_OK else {
                decompressedData = nil
                return
            }
            var status: Int32
            repeat {
                status = buffer.withUnsafeMutableBytes { bufferPtr -> Int32 in
                    stream.next_out = bufferPtr.baseAddress!.assumingMemoryBound(to: Bytef.self)
                    stream.avail_out = uInt(bufferPtr.count)
                    let inflateResult = inflate(&stream, Z_NO_FLUSH)
                    if inflateResult == Z_OK || inflateResult == Z_STREAM_END {
                        let bytesWritten = bufferPtr.count - Int(stream.avail_out)
                        decompressedData?.append(contentsOf: bufferPtr.prefix(bytesWritten))
                    }
                    return inflateResult
                }
            } while status == Z_OK
            inflateEnd(&stream)
            if status != Z_STREAM_END {
                decompressedData = nil
            }
        }
        return decompressedData
    }
}
