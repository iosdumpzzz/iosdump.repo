//
//  IpaAnalyzerService.swift
//  Debs
//
//  Created by Z on 2025/10/11.
//

// 文件路径: Debs/Services/IpaAnalyzerService.swift
import Foundation
import ZIPFoundation

enum IpaAnalyzerError: LocalizedError {
    case unzipFailed(Error)
    case payloadNotFound
    case fileScanFailed(Error)

    var errorDescription: String? {
        switch self {
        case .unzipFailed(let error):
            return "解压 IPA 文件失败: \(error.localizedDescription)"
        case .payloadNotFound:
            return "未在 IPA 文件中找到有效的 Payload 文件夹。"
        case .fileScanFailed(let error):
            return "扫描解压后的文件时出错: \(error.localizedDescription)"
        }
    }
}

class IpaAnalyzerService {
    /// 分析指定的 IPA 文件，并返回其中包含的所有框架和动态库信息。
    /// - Parameter ipaURL: 指向 .ipa 文件的 URL。
    /// - Returns: 一个包含 `FrameworkInfo` 对象的数组。
    static func analyze(ipaURL: URL) async throws -> [FrameworkInfo] {
        let fileManager = FileManager.default
        let tempDirectory = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString)

        // 1. 解压 IPA 文件
        do {
            try fileManager.createDirectory(at: tempDirectory, withIntermediateDirectories: true)
            try fileManager.unzipItem(at: ipaURL, to: tempDirectory)
        } catch {
            throw IpaAnalyzerError.unzipFailed(error)
        }

        // 2. 找到 Payload 文件夹
        guard let payloadURL = try fileManager.contentsOfDirectory(at: tempDirectory, includingPropertiesForKeys: nil)
            .first(where: { $0.lastPathComponent == "Payload" }) else {
            throw IpaAnalyzerError.payloadNotFound
        }

        // 3. 递归扫描 Payload 文件夹，查找框架和动态库
        var foundItems: [FrameworkInfo] = []
        let enumerator = fileManager.enumerator(at: payloadURL, includingPropertiesForKeys: [.isDirectoryKey], options: .skipsHiddenFiles)

        while let elementURL = enumerator?.nextObject() as? URL {
            let lastComponent = elementURL.lastPathComponent
            
            if lastComponent.hasSuffix(".framework") || lastComponent.hasSuffix(".dylib") {
                // 计算文件在 Payload 中的相对路径
                let relativePath = elementURL.path.replacingOccurrences(of: payloadURL.path + "/", with: "")
                
                let info = FrameworkInfo(
                    name: lastComponent,
                    path: relativePath,
                    tempURL: elementURL
                )
                foundItems.append(info)
                
                // 如果是 .framework 文件夹，则不再遍历其内部
                if lastComponent.hasSuffix(".framework") {
                    enumerator?.skipDescendants()
                }
            }
        }
        
        return foundItems.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
}
