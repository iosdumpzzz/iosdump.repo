//
//  DebsProjectManager.swift
//  Debs
//
//  Created by Z on 2025/10/13.
//

// 文件路径: Debs/Services/DebsProjectManager.swift
import Foundation

class DebsProjectManager {
    static let shared = DebsProjectManager()
    private let fileManager = FileManager.default
    
    private var projectsDirectory: URL {
        let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let debsDir = documentsDirectory.appendingPathComponent("DebsProjects")
        if !fileManager.fileExists(atPath: debsDir.path) {
            try? fileManager.createDirectory(at: debsDir, withIntermediateDirectories: true)
        }
        return debsDir
    }
    
    private let permissionsFileName = ".permissions.plist"
    private let metadataFileName = ".metadata.plist"
    
    private init() {}

    func listProjects() -> [DebsProjectMetadata] {
        let fileManager = FileManager.default
        let projectsDirectory = self.projectsDirectory
        
        // 1. 在获取目录内容时，请求包含“创建日期”这个属性
        guard var projectURLs = try? fileManager.contentsOfDirectory(at: projectsDirectory,
                                                                     includingPropertiesForKeys: [.isDirectoryKey, .creationDateKey],
                                                                     options: .skipsHiddenFiles) else {
            return []
        }

        // 2. 核心修改：在加载元数据之前，先对 URL 数组按文件夹创建日期进行降序排序
        projectURLs.sort { url1, url2 in
            do {
                let values1 = try url1.resourceValues(forKeys: [.creationDateKey])
                let values2 = try url2.resourceValues(forKeys: [.creationDateKey])
                // 如果两个日期都存在，则比较它们，日期晚的（新的）排在前面
                if let date1 = values1.creationDate, let date2 = values2.creationDate {
                    return date1 > date2
                }
            } catch {
                print("Failed to get resource values for sorting: \(error)")
            }
            // 如果无法获取日期，则保持原顺序
            return false
        }

        // 3. 遍历已经排好序的 URL 数组来加载元数据
        return projectURLs.compactMap { url -> DebsProjectMetadata? in
                if var metadata = self.loadMetadata(from: url) {
                    metadata.projectURL = url
                    
                    var needsSave = false // 标记是否需要回写文件
                    
                    // 兼容旧数据：如果架构信息为空，则现场解析并准备回写
                    if metadata.architecture == nil {
                        metadata.architecture = self.getArchitecture(from: url)
                        needsSave = true
                    }
                    
                    // 兼容旧数据：如果创建日期为空，则从文件系统读取并准备回写
                    if metadata.creationDate == nil {
                        if let creationDate = (try? url.resourceValues(forKeys: [.creationDateKey]))?.creationDate {
                            metadata.creationDate = creationDate
                            needsSave = true
                        }
                    }
                    
                    // 如果数据有更新，则回写到 .metadata.plist 文件
                    if needsSave {
                        self.saveMetadata(metadata, in: url)
                    }
                    
                    return metadata
                }
                return nil
            }
        }

    /// 创建项目目录
    func createProjectDirectory(for debFileName: String) -> URL? {
        let baseName = debFileName.replacingOccurrences(of: ".deb", with: "")
        var projectURL = projectsDirectory.appendingPathComponent(baseName)
        var counter = 1
        
        while fileManager.fileExists(atPath: projectURL.path) {
            let newName = "\(baseName) (\(counter))"
            projectURL = projectsDirectory.appendingPathComponent(newName)
            counter += 1
        }
        
        do {
            try fileManager.createDirectory(at: projectURL, withIntermediateDirectories: true)
            return projectURL
        } catch {
            print("Failed to create project directory: \(error)")
            return nil
        }
    }
    
    func saveSymlinks(_ symlinks: [String: String], in projectURL: URL) {
        let plistURL = projectURL.appendingPathComponent(".symlinks.plist") // 新的文件名
        do {
            let data = try PropertyListEncoder().encode(symlinks)
            try data.write(to: plistURL)
        } catch {
            print("Failed to save symlinks file: \(error)")
        }
    }

    /// 加载符号链接字典
    func loadSymlinks(from projectURL: URL) -> [String: String]? {
        let plistURL = projectURL.appendingPathComponent(".symlinks.plist") // 新的文件名
        guard let data = try? Data(contentsOf: plistURL) else { return nil }
        return try? PropertyListDecoder().decode([String: String].self, from: data)
    }

    /// 保存权限字典
    func savePermissions(_ permissions: [String: UInt16], in projectURL: URL) {
        let plistURL = projectURL.appendingPathComponent(permissionsFileName)
        do {
            let data = try PropertyListEncoder().encode(permissions)
            try data.write(to: plistURL)
        } catch {
            print("Failed to save permissions file: \(error)")
        }
    }

    /// 加载权限字典
    func loadPermissions(from projectURL: URL) -> [String: UInt16]? {
        let plistURL = projectURL.appendingPathComponent(permissionsFileName)
        guard let data = try? Data(contentsOf: plistURL) else { return nil }
        return try? PropertyListDecoder().decode([String: UInt16].self, from: data)
    }

    /// 保存元数据
    func saveMetadata(_ metadata: DebsProjectMetadata, in projectURL: URL) {
        let plistURL = projectURL.appendingPathComponent(metadataFileName)
        do {
            let data = try PropertyListEncoder().encode(metadata)
            try data.write(to: plistURL)
        } catch {
            print("Failed to save metadata file: \(error)")
        }
    }

    // ▼▼▼ 确保这个函数在 DebsProjectManager 类的内部 ▼▼▼
    /// 从项目目录加载元数据
    private func loadMetadata(from projectURL: URL) -> DebsProjectMetadata? {
        let plistURL = projectURL.appendingPathComponent(metadataFileName)
        guard let data = try? Data(contentsOf: plistURL) else {
            // 如果元数据文件不存在，返回一个不带图标的默认元数据
            // 在这里我们不知道原始压缩格式，所以传入 nil 是最合适的。
            // 后续的打包逻辑在遇到 nil 时会默认使用 "gz"。
            return DebsProjectMetadata(projectName: projectURL.lastPathComponent, iconData: nil, compressionFormat: nil, projectURL: projectURL)
                        // ▲▲▲ 修正结束 ▲▲▲
        }
        return try? PropertyListDecoder().decode(DebsProjectMetadata.self, from: data)
    }
    // ▲▲▲ 函数结束 ▲▲▲

    /// 删除项目
    func deleteProject(at projectURL: URL) {
        try? fileManager.removeItem(at: projectURL)
    }

    /// 解析 control 文件以获取 "Architecture" 字段
    func getArchitecture(from projectURL: URL) -> String? {
        let controlFileURL = projectURL.appendingPathComponent("DEBIAN/control")
        
        guard let controlData = try? Data(contentsOf: controlFileURL),
              let controlString = String(data: controlData, encoding: .utf8) else {
            return nil
        }
        
        // 逐行查找包含 "Architecture:" 的行
        let lines = controlString.components(separatedBy: .newlines)
        for line in lines {
            if line.starts(with: "Architecture:") {
                // 找到后，移除前缀和空格，得到架构字符串
                return line.replacingOccurrences(of: "Architecture:", with: "").trimmingCharacters(in: .whitespaces)
            }
        }
        
        return nil // 如果没找到
    }
    // ▲▲▲ 新增函数结束 ▲▲▲
    
} // <-- 类的最后一个花括号，确保所有函数都在这之上
