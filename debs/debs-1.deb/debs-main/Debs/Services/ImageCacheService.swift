//
//  ImageCacheService.swift
//  Debs
//
//  Created by Z on 2025/9/25.
//

import UIKit

class ImageCacheService {
    // 创建一个单例，确保整个 App 共享同一个缓存实例
    static let shared = ImageCacheService()

    // 内存缓存：速度快，但 App 关闭后会清空
    private let memoryCache = NSCache<NSString, UIImage>()

    // 硬盘缓存的路径
    private let diskCachePath: URL

    private init() {
        // 设置硬盘缓存的文件夹路径
        let paths = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        self.diskCachePath = paths[0].appendingPathComponent("ImageCache")

        // 如果文件夹不存在，则创建它
        if !FileManager.default.fileExists(atPath: diskCachePath.path) {
            try? FileManager.default.createDirectory(at: diskCachePath, withIntermediateDirectories: true)
        }
    }

    /// 根据 URL 从缓存中获取图片
    func getImage(forKey key: String) -> UIImage? {
        // 1. 先尝试从内存缓存中获取
        if let cachedImage = memoryCache.object(forKey: key as NSString) {
            return cachedImage
        }

        // 2. 如果内存中没有，再尝试从硬盘缓存中获取
        let fileURL = diskCachePath.appendingPathComponent(cacheKey(for: key))
        if let image = UIImage(contentsOfFile: fileURL.path) {
            // 从硬盘读出后，存入内存以备下次快速访问
            memoryCache.setObject(image, forKey: key as NSString)
            return image
        }

        return nil
    }

    /// 将图片存入缓存
    func setImage(_ image: UIImage, forKey key: String) {
        // 1. 存入内存缓存
        memoryCache.setObject(image, forKey: key as NSString)

        // 2. 异步存入硬盘缓存
        DispatchQueue.global(qos: .background).async { [weak self] in
            guard let self = self else { return }
            let fileURL = self.diskCachePath.appendingPathComponent(self.cacheKey(for: key))
            if let data = image.pngData() {
                try? data.write(to: fileURL)
            }
        }
    }

    /// 将 URL 转换为安全的文件名
    private func cacheKey(for urlString: String) -> String {
        return urlString.components(separatedBy: CharacterSet(charactersIn: ":/\\?%*|\"<>")).joined()
    }
}
