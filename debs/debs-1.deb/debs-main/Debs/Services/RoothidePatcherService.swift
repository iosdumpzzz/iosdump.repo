//
//  RoothidePatcherService.swift
//  Debs
//

import Foundation

enum RoothidePatcherError: LocalizedError {
    case processingFailed(String)
    
    var errorDescription: String? {
        switch self {
        case .processingFailed(let msg): return "隐根转换处理失败: \(msg)"
        }
    }
}

/// 隐根 (Roothide) 转换核心服务
class RoothidePatcherService {
    
    static func convertToRoothide(rootlessDebURL: URL) async throws -> URL {
        let fm = FileManager.default
        let tempUUID = UUID().uuidString
        let workDir = fm.temporaryDirectory.appendingPathComponent("RoothideWorkspace_\(tempUUID)")
        
        do {
            try fm.createDirectory(at: workDir, withIntermediateDirectories: true)
            
            // 1. 解压无根 deb (调用提取权限版本)
            let extractResult = try await DebExtractor.extractAllFilesWithPermissions(from: rootlessDebURL, to: workDir)
            var permissions = extractResult.permissions
            var symlinks = extractResult.symlinks
            let compFormat = extractResult.compressionFormat
            
            // ---------------------------------------------------------
            // 步骤二: 文件系统结构重组 (剥离 var/jb，并彻底删除 var) + 修正权限字典
            // ---------------------------------------------------------
            try restructureFilesystem(workspace: workDir, permissions: &permissions, symlinks: &symlinks)
            
            // ---------------------------------------------------------
            // 步骤四: 配置文件修补 (【物理注入】 .roothidepatch)
            // ---------------------------------------------------------
            try patchScriptsAndPlists(workspace: workDir, symlinks: &symlinks)
            
            // ---------------------------------------------------------
            // 步骤五: 控制文件修改 (精准修改架构防止重叠)
            // ---------------------------------------------------------
            try patchControlFile(workspace: workDir)
            
            // 4. 利用 DebPackager 重新打包隐根
            let packagedDebURL = try await DebPackager.packageProject(projectURL: workDir, permissions: permissions, symlinks: symlinks, compressionFormat: compFormat)
            
            // 5. 迁移并重命名最终文件
            let finalDebName = rootlessDebURL.lastPathComponent
                .replacingOccurrences(of: "-roothide-temp", with: "-roothide")
                .replacingOccurrences(of: "-rootless", with: "-roothide")
                .replacingOccurrences(of: "iphoneos-arm64", with: "iphoneos-arm64e")
            
            let outputURL = fm.temporaryDirectory.appendingPathComponent(finalDebName)
            if fm.fileExists(atPath: outputURL.path) {
                try fm.removeItem(at: outputURL)
            }
            try fm.moveItem(at: packagedDebURL, to: outputURL)
            
            // 清理临时工作目录
            try? fm.removeItem(at: workDir)
            
            // 安全防误删：确保生成的产物路径与原无根路径不同时，才清理原无根包
            if rootlessDebURL.path != outputURL.path {
                try? fm.removeItem(at: rootlessDebURL)
            }
            
            return outputURL
            
        } catch {
            try? fm.removeItem(at: workDir)
            throw error
        }
    }
    
    // MARK: - 核心处理逻辑
    
    private static func restructureFilesystem(workspace: URL, permissions: inout [String: UInt16], symlinks: inout [String: String]) throws {
        let fm = FileManager.default
        let rootfsDir = workspace.appendingPathComponent("rootfs")
        try fm.createDirectory(at: rootfsDir, withIntermediateDirectories: true)
        
        let items = try fm.contentsOfDirectory(atPath: workspace.path)
        for item in items {
            if item == "DEBIAN" || item == "rootfs" || item == "var" { continue }
            let src = workspace.appendingPathComponent(item)
            let dst = rootfsDir.appendingPathComponent(item)
            try fm.moveItem(at: src, to: dst)
        }
        
        // 提取 var/jb 内部文件到根级
        let varJb = workspace.appendingPathComponent("var/jb")
        if fm.fileExists(atPath: varJb.path) {
            let jbItems = try fm.contentsOfDirectory(atPath: varJb.path)
            for item in jbItems {
                let src = varJb.appendingPathComponent(item)
                let dst = workspace.appendingPathComponent(item)
                if fm.fileExists(atPath: dst.path) { try fm.removeItem(at: dst) }
                try fm.moveItem(at: src, to: dst)
            }
        }
        
        // 按照您的要求：彻底删除 var 目录（不要 var 文件了）
        let varDir = workspace.appendingPathComponent("var")
        if fm.fileExists(atPath: varDir.path) {
            try? fm.removeItem(at: varDir)
        }
        
        if let rootfsItems = try? fm.contentsOfDirectory(atPath: rootfsDir.path), rootfsItems.isEmpty {
            try? fm.removeItem(at: rootfsDir)
        }
        
        // 同步修正权限与链接字典的相对路径
        var newPermissions: [String: UInt16] = [:]
        for (k, v) in permissions {
            let newK = mapRoothidePath(k)
            if !newK.isEmpty { newPermissions[newK] = v }
        }
        permissions = newPermissions
        
        var newSymlinks: [String: String] = [:]
        for (k, v) in symlinks {
            let newK = mapRoothidePath(k)
            var newV = v
            if newV.hasPrefix("/var/jb/") {
                newV = newV.replacingOccurrences(of: "/var/jb/", with: "/")
            } else if newV.hasPrefix("/var/jb") {
                newV = "/"
            } else if newV.hasPrefix("/") && !newV.hasPrefix("/var/") {
                newV = "/rootfs" + newV
            }
            if !newK.isEmpty { newSymlinks[newK] = newV }
        }
        symlinks = newSymlinks
    }
    
    private static func mapRoothidePath(_ oldPath: String) -> String {
        if oldPath.hasPrefix("DEBIAN") { return oldPath }
        if oldPath.hasPrefix("var/jb/") {
            return String(oldPath.dropFirst(7))
        }
        if oldPath == "var/jb" || oldPath == "var" { return "" }
        if !oldPath.hasPrefix("rootfs/") {
            return "rootfs/" + oldPath
        }
        return oldPath
    }
    
    /// 步骤四：修补 Plist 与 Bash 脚本，并【物理生成】兼容层软链接
    private static func patchScriptsAndPlists(workspace: URL, symlinks: inout [String: String]) throws {
        let fm = FileManager.default
        guard let enumerator = fm.enumerator(at: workspace, includingPropertiesForKeys: nil) else { return }
        
        var newSymlinks = symlinks
        
        for case let fileURL as URL in enumerator {
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: fileURL.path, isDirectory: &isDir), !isDir.boolValue {
                let ext = fileURL.pathExtension.lowercased()
                let filename = fileURL.lastPathComponent
                
                if ext == "plist" {
                    patchPlistFile(fileURL)
                } else if ["preinst", "prerm", "postinst", "postrm", "extrainst_"].contains(filename) {
                    patchBashScript(fileURL)
                } 
                
                // 物理创建 .roothidepatch 软链接
                if ext == "dylib" || ext == "exec" || ext == "app" {
                    let patchSymlinkURL = fileURL.appendingPathExtension("roothidepatch")
                    
                    do {
                        if fm.fileExists(atPath: patchSymlinkURL.path) {
                            try fm.removeItem(at: patchSymlinkURL)
                        }
                        // 统一使用 String 纯路径模式
                        try fm.createSymbolicLink(atPath: patchSymlinkURL.path, withDestinationPath: "/usr/lib/DynamicPatches/AutoPatches.dylib")
                    } catch {
                        // 如果底层不支持创建软链，则退化为一个文本文件（兼容 ZIP 模式）
                        try? "/usr/lib/DynamicPatches/AutoPatches.dylib".write(to: patchSymlinkURL, atomically: true, encoding: .utf8)
                    }
                    
                    // 加入打包字典让打包器能够正确索引
                    let relativePath = patchSymlinkURL.path.replacingOccurrences(of: workspace.path + "/", with: "")
                    newSymlinks[relativePath] = "/usr/lib/DynamicPatches/AutoPatches.dylib"
                }
            }
        }
        
        symlinks = newSymlinks
    }
    
    private static func patchPlistFile(_ url: URL) {
        guard let data = try? Data(contentsOf: url),
              let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let xmlData = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0),
              var content = String(data: xmlData, encoding: .utf8) else { return }
        
        content = content.replacingOccurrences(of: "/var/jb/", with: "/")
        
        if url.path.contains("libSandy") {
            content = content.replacingOccurrences(of: ">/<", with: ">/rootfs/<")
            let paths = ["Applications", "Library", "private", "System", "sbin", "bin", "etc", "lib", "usr", "var"]
            for p in paths {
                content = content.replacingOccurrences(of: ">/\(p)/", with: ">/rootfs/\(p)/")
            }
        }
        if let newData = content.data(using: .utf8) {
            try? newData.write(to: url)
        }
    }
    
    private static func patchBashScript(_ url: URL) {
        guard var script = try? String(contentsOf: url, encoding: .utf8) else { return }
        
        script = script.replacingOccurrences(of: "iphoneos-arm64", with: "iphoneos-arm64e")
        script = script.replacingOccurrences(of: "/var/jb/", with: "/-var/jb/-")
        script = script.replacingOccurrences(of: "/var/jb", with: "/-var/jb-")
        
        let rootfsPaths = ["/Applications/", "/Library/", "/private/", "/System/", "/sbin/", "/bin/", "/etc/", "/lib/", "/usr/", "/var/"]
        for p in rootfsPaths {
            script = script.replacingOccurrences(of: " \(p)", with: " /rootfs\(p)")
        }
        script = script.replacingOccurrences(of: "DIR=\"/Library/", with: "DIR=\"/rootfs/Library/")
        
        if script.hasPrefix("#! /rootfs/") {
            script = script.replacingOccurrences(of: "#! /rootfs/", with: "#! /")
        }
        
        script = script.replacingOccurrences(of: "/-var/jb/-", with: "/")
        script = script.replacingOccurrences(of: "/-var/jb-", with: "/var/jb")
        try? script.write(to: url, atomically: true, encoding: .utf8)
    }
    
    /// 步骤五：修改 Control 文件信息
    private static func patchControlFile(workspace: URL) throws {
        let controlURL = workspace.appendingPathComponent("DEBIAN/control")
        guard FileManager.default.fileExists(atPath: controlURL.path),
              var controlStr = try? String(contentsOf: controlURL, encoding: .utf8) else { return }
        
        // 【精准替换】：只替换整句，防止相互覆盖出现 64e64e
        if let range = controlStr.range(of: "Architecture: iphoneos-arm64\n") {
            controlStr.replaceSubrange(range, with: "Architecture: iphoneos-arm64e\n")
        } else if let range = controlStr.range(of: "Architecture: iphoneos-arm\n") {
            controlStr.replaceSubrange(range, with: "Architecture: iphoneos-arm64e\n")
        } else if let range = controlStr.range(of: "Architecture: iphoneos-arm64") {
            // 处理没加回车符的边界情况
            controlStr.replaceSubrange(range, with: "Architecture: iphoneos-arm64e")
        }
        
        controlStr = controlStr.replacingOccurrences(of: "Conflicts: roothide", with: "Conflicts: r-o-o-t-l-e-s-s-")
        
        let preDependsStr = "Pre-Depends: rootless-compat(>= 0.9)"
        if controlStr.contains("Pre-Depends:") {
            if !controlStr.contains("rootless-compat") {
                controlStr = controlStr.replacingOccurrences(of: "Pre-Depends:", with: "Pre-Depends: rootless-compat(>= 0.9), ")
            }
        } else {
            controlStr += "\n\(preDependsStr)"
        }
        
        let lines = controlStr.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
        controlStr = lines.joined(separator: "\n") + "\n"
        try controlStr.write(to: controlURL, atomically: true, encoding: .utf8)
    }
}
