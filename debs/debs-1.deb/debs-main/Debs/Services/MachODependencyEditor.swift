//
//  MachODependencyEditor.swift
//  Debs
//
//  Created by Z on 2025/11/6.
//

import Foundation

/// Mach-O 编辑器专属错误枚举
enum MachOEditorError: LocalizedError {
    case fileReadFailed(Error)
    case fileWriteFailed(Error)
    case invalidMachO(String)
    case dependencyNotFound(String)
    case notEnoughPadding(old: Int, new: Int)
    case unsupportedArchitecture(String)
    
    var errorDescription: String? {
        switch self {
        case .fileReadFailed(let error): return "读取文件失败: \(error.localizedDescription)"
        case .fileWriteFailed(let error): return "写入文件失败: \(error.localizedDescription)"
        case .invalidMachO(let reason): return "无效的 Mach-O 文件: \(reason)"
        case .dependencyNotFound(let path): return "未在 dylib 中找到依赖: \(path)"
        case .notEnoughPadding(_, _): return "替换失败：该文件未保留足够的 Header Padding (空闲空间)，无法容纳更长的路径。请使用与原路径等长或更短的路径。"
        case .unsupportedArchitecture(let arch): return "暂不支持此架构的解析: \(arch)"
        }
    }
}

/// 专业级 Mach-O 依赖编辑器（纯 Swift 无外部依赖版，全面支持 Fat Binary，完美复刻 install_name_tool，防闪退）
class MachODependencyEditor {
    
    // MARK: - Mach-O 规范常量
    static let MH_MAGIC_64: UInt32 = 0xfeedfacf
    static let FAT_MAGIC: UInt32 = 0xcafebabe
    static let FAT_CIGAM: UInt32 = 0xbebafeca
    static let MH_MAGIC: UInt32 = 0xfeedface
    static let MH_CIGAM: UInt32 = 0xcefaedfe
    
    // Load Commands 常量
    static let LC_SEGMENT: UInt32 = 0x1
    static let LC_SEGMENT_64: UInt32 = 0x19
    static let LC_ID_DYLIB: UInt32 = 0xd
    static let LC_LOAD_DYLIB: UInt32 = 0xc
    static let LC_LOAD_WEAK_DYLIB: UInt32 = 0x80000018
    static let LC_REEXPORT_DYLIB: UInt32 = 0x8000001f
    static let LC_LAZY_LOAD_DYLIB: UInt32 = 0x20
    static let LC_LOAD_UPWARD_DYLIB: UInt32 = 0x80000023
    
    // 8字节对齐辅助函数 (64位 Mach-O 的命令大小必须是 8 的倍数)
    private static func align8(_ value: Int) -> Int {
        return (value + 7) & ~7
    }
    
    // 安全读取大端序 32位 整数 (Fat Header 使用大端序存储)
    private static func readUInt32BE(from data: Data, offset: Int) -> UInt32 {
        let b0 = UInt32(data[offset])
        let b1 = UInt32(data[offset + 1])
        let b2 = UInt32(data[offset + 2])
        let b3 = UInt32(data[offset + 3])
        return (b0 << 24) | (b1 << 16) | (b2 << 8) | b3
    }
    
    // 判断是否是依赖相关的 Command
    private static func isDylibCommand(_ cmd: UInt32) -> Bool {
        return cmd == LC_LOAD_DYLIB || cmd == LC_LOAD_WEAK_DYLIB ||
               cmd == LC_REEXPORT_DYLIB || cmd == LC_LAZY_LOAD_DYLIB ||
               cmd == LC_LOAD_UPWARD_DYLIB || cmd == LC_ID_DYLIB
    }
    
    // MARK: - 读取所有依赖路径
    static func readDependencies(from fileURL: URL) throws -> [String] {
        var fileData: Data
        do {
            fileData = try Data(contentsOf: fileURL)
        } catch {
            throw MachOEditorError.fileReadFailed(error)
        }
        
        guard fileData.count >= 32 else {
            throw MachOEditorError.invalidMachO("文件太小，不包含完整的 Mach 头部")
        }
        
        let magic = fileData.withUnsafeBytes { $0.load(as: UInt32.self) }
        
        switch magic {
        case MH_MAGIC_64:
            return try extractDependencies64(data: fileData)
        case FAT_MAGIC, FAT_CIGAM:
            return try extractDependenciesFat(data: fileData)
        case MH_MAGIC, MH_CIGAM:
            throw MachOEditorError.unsupportedArchitecture("32-bit Mach-O (已过时)")
        default:
            throw MachOEditorError.invalidMachO("未知的 Magic Number: \(String(format: "0x%X", magic))")
        }
    }
    
    // MARK: - Fat Binary 依赖读取引擎
    private static func extractDependenciesFat(data: Data) throws -> [String] {
        let nfat_arch = Int(readUInt32BE(from: data, offset: 4))
        var dependencies: Set<String> = []
        
        var archOffset = 8
        
        for _ in 0..<nfat_arch {
            guard archOffset + 20 <= data.count else { break }
            
            let sliceOffset = Int(readUInt32BE(from: data, offset: archOffset + 8))
            let sliceSize = Int(readUInt32BE(from: data, offset: archOffset + 12))
            
            guard sliceOffset + sliceSize <= data.count else {
                archOffset += 20
                continue
            }
            
            let sliceData = data.subdata(in: sliceOffset ..< sliceOffset + sliceSize)
            guard sliceData.count >= 32 else {
                archOffset += 20
                continue
            }
            
            let sliceMagic = sliceData.withUnsafeBytes { $0.load(as: UInt32.self) }
            if sliceMagic == MH_MAGIC_64 {
                let deps = try extractDependencies64(data: sliceData)
                for dep in deps {
                    dependencies.insert(dep)
                }
            }
            archOffset += 20
        }
        
        return Array(dependencies).sorted()
    }
    
    // MARK: - Thin Binary 依赖读取引擎
    private static func extractDependencies64(data: Data) throws -> [String] {
        let headerSize = 32
        let ncmds = Int(data.withUnsafeBytes { $0.load(fromByteOffset: 16, as: UInt32.self) })
        
        var currentOffset = headerSize
        var dependencies: [String] = []
        
        for _ in 0..<ncmds {
            guard currentOffset + 8 <= data.count else { break }
            
            let cmd = data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset, as: UInt32.self) }
            let cmdsize = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 4, as: UInt32.self) })
            
            if isDylibCommand(cmd) {
                let nameOffset = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 8, as: UInt32.self) })
                let stringOffset = currentOffset + nameOffset
                let maxStringLength = cmdsize - nameOffset
                
                guard stringOffset < data.count, maxStringLength > 0 else {
                    currentOffset += cmdsize
                    continue
                }
                
                let stringData = data.subdata(in: stringOffset..<(stringOffset + maxStringLength))
                if let depString = String(data: stringData.prefix(while: { $0 != 0 }), encoding: .utf8) {
                    dependencies.append(depString)
                }
            }
            currentOffset += cmdsize
        }
        
        return dependencies
    }
    
    // MARK: - 核心：修改依赖路径
    static func changeDependency(in fileURL: URL, oldPath: String, newPath: String) throws {
        var fileData: Data
        do {
            fileData = try Data(contentsOf: fileURL)
        } catch {
            throw MachOEditorError.fileReadFailed(error)
        }
        
        guard fileData.count >= 32 else {
            throw MachOEditorError.invalidMachO("文件太小，不包含完整的 Mach 头部")
        }
        
        let magic = fileData.withUnsafeBytes { $0.load(as: UInt32.self) }
        var modified = false
        
        switch magic {
        case MH_MAGIC_64:
            modified = try processThinMachO64(data: &fileData, oldPath: oldPath, newPath: newPath)
        case FAT_MAGIC, FAT_CIGAM:
            modified = try processFatMachO(data: &fileData, oldPath: oldPath, newPath: newPath)
        case MH_MAGIC, MH_CIGAM:
            throw MachOEditorError.unsupportedArchitecture("32-bit Mach-O (已过时)")
        default:
            throw MachOEditorError.invalidMachO("未知的 Magic Number: \(String(format: "0x%X", magic))")
        }
        
        guard modified else {
            throw MachOEditorError.dependencyNotFound(oldPath)
        }
        
        do {
            try fileData.write(to: fileURL, options: .atomic)
        } catch {
            throw MachOEditorError.fileWriteFailed(error)
        }
    }
    
    // MARK: - Fat Binary 依赖覆写引擎
    private static func processFatMachO(data: inout Data, oldPath: String, newPath: String) throws -> Bool {
        let nfat_arch = Int(readUInt32BE(from: data, offset: 4))
        var anyReplaced = false
        var archOffset = 8
        
        for _ in 0..<nfat_arch {
            guard archOffset + 20 <= data.count else { break }
            
            let sliceOffset = Int(readUInt32BE(from: data, offset: archOffset + 8))
            let sliceSize = Int(readUInt32BE(from: data, offset: archOffset + 12))
            
            guard sliceOffset + sliceSize <= data.count else {
                archOffset += 20
                continue
            }
            
            // 解决切片越界：通过 Data() 强制分配新的 0 起始索引缓冲
            var sliceData = Data(data[sliceOffset ..< sliceOffset + sliceSize])
            guard sliceData.count >= 32 else {
                archOffset += 20
                continue
            }
            
            let sliceMagic = sliceData.withUnsafeBytes { $0.load(as: UInt32.self) }
            if sliceMagic == MH_MAGIC_64 {
                let replaced = try processThinMachO64(data: &sliceData, oldPath: oldPath, newPath: newPath)
                if replaced {
                    anyReplaced = true
                    data.replaceSubrange(sliceOffset ..< sliceOffset + sliceSize, with: sliceData)
                }
            }
            archOffset += 20
        }
        
        return anyReplaced
    }
    
    // MARK: - 计算实际的安全 Padding 极限位置 (完美复刻 install_name_tool)
    private static func getLowFileoff(data: Data, ncmds: Int, headerSize: Int) -> Int {
        var low_fileoff = data.count
        var currentOffset = headerSize
        for _ in 0..<ncmds {
            guard currentOffset + 8 <= data.count else { break }
            let cmd = data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset, as: UInt32.self) }
            let cmdsize = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 4, as: UInt32.self) })
            
            if cmd == LC_SEGMENT_64 {
                if currentOffset + 72 <= data.count {
                    let fileoff = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 40, as: UInt64.self) })
                    let filesize = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 48, as: UInt64.self) })
                    if filesize > 0 && fileoff > 0 && fileoff < low_fileoff {
                        low_fileoff = fileoff
                    }
                }
            } else if cmd == LC_SEGMENT {
                if currentOffset + 56 <= data.count {
                    let fileoff = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 28, as: UInt32.self) })
                    let filesize = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 32, as: UInt32.self) })
                    if filesize > 0 && fileoff > 0 && fileoff < low_fileoff {
                        low_fileoff = fileoff
                    }
                }
            }
            currentOffset += cmdsize
        }
        return low_fileoff
    }
    
    // MARK: - Thin Binary 依赖覆写引擎 (防切片闪退增强版)
    private static func processThinMachO64(data: inout Data, oldPath: String, newPath: String) throws -> Bool {
        let headerSize = 32
        let ncmds = Int(data.withUnsafeBytes { $0.load(fromByteOffset: 16, as: UInt32.self) })
        let sizeofcmdsOffset = 20
        var sizeofcmds = Int(data.withUnsafeBytes { $0.load(fromByteOffset: sizeofcmdsOffset, as: UInt32.self) })
        
        var currentOffset = headerSize
        var replaced = false
        
        for _ in 0..<ncmds {
            guard currentOffset + 8 <= data.count else { break }
            let cmd = data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset, as: UInt32.self) }
            let cmdsize = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 4, as: UInt32.self) })
            
            if isDylibCommand(cmd) {
                let nameOffset = Int(data.withUnsafeBytes { $0.load(fromByteOffset: currentOffset + 8, as: UInt32.self) })
                let stringOffset = currentOffset + nameOffset
                let maxStringLength = cmdsize - nameOffset
                
                guard stringOffset < data.count, maxStringLength > 0 else {
                    currentOffset += cmdsize
                    continue
                }
                
                let stringData = data.subdata(in: stringOffset..<(stringOffset + maxStringLength))
                if let currentString = String(data: stringData.prefix(while: { $0 != 0 }), encoding: .utf8) {
                    if currentString == oldPath {
                        
                        let oldCmdSize = cmdsize
                        let newCmdSize = align8(nameOffset + newPath.utf8.count + 1)
                        let sizeDiff = newCmdSize - oldCmdSize
                        
                        if sizeDiff > 0 {
                            // 需求变大：向后占用空闲的 Padding
                            let endOfCmds = headerSize + sizeofcmds
                            let low_fileoff = getLowFileoff(data: data, ncmds: ncmds, headerSize: headerSize)
                            let available_padding = low_fileoff - endOfCmds
                            
                            // 像 install_name_tool 一样，严格检查真实的安全空闲区界限
                            if sizeDiff > available_padding {
                                throw MachOEditorError.notEnoughPadding(old: oldCmdSize, new: newCmdSize)
                            }
                            
                            // 🔥 核心防闪退点：必须用 Data() 包裹，将 InlineSlice 重置为从 0 起始的常规数据
                            var newCmdData = Data(data[currentOffset ..< currentOffset + nameOffset])
                            newCmdData.append(contentsOf: newPath.utf8)
                            newCmdData.append(0) // \0 结尾
                            while newCmdData.count < newCmdSize {
                                newCmdData.append(0) // 补齐 8 字节对齐
                            }
                            
                            // 修正内部 cmdsize 字段 (因为 newCmdData 索引从 0 开始，现在 4..<8 绝对安全)
                            var newCmdSizeU32 = UInt32(newCmdSize)
                            withUnsafeBytes(of: &newCmdSizeU32) { bytes in
                                newCmdData.replaceSubrange(4..<8, with: bytes)
                            }
                            
                            var replacementData = Data()
                            replacementData.append(newCmdData)
                            
                            // 截取其后的所有旧的 Commands，同样使用 Data() 防止索引残留
                            let shiftData = Data(data[(currentOffset + oldCmdSize) ..< endOfCmds])
                            replacementData.append(shiftData)
                            
                            // 将新数据精准覆盖，彻底保持 Mach-O 总文件大小不增不减
                            data.replaceSubrange(currentOffset ..< (endOfCmds + sizeDiff), with: replacementData)
                            
                            // 更新头部 sizeofcmds
                            sizeofcmds += sizeDiff
                            var newSizeOfCmdsU32 = UInt32(sizeofcmds)
                            withUnsafeBytes(of: &newSizeOfCmdsU32) { bytes in
                                data.replaceSubrange(sizeofcmdsOffset ..< sizeofcmdsOffset + 4, with: bytes)
                            }
                            
                            // 成功替换后，偏移量跟进变大后的新尺寸
                            currentOffset += newCmdSize
                            replaced = true
                            continue
                            
                        } else {
                            // 等长或变短：直接在当前 Command 空间内覆盖并补 0
                            var newCmdData = Data(data[currentOffset ..< currentOffset + nameOffset])
                            newCmdData.append(contentsOf: newPath.utf8)
                            newCmdData.append(0)
                            while newCmdData.count < oldCmdSize {
                                newCmdData.append(0)
                            }
                            data.replaceSubrange(currentOffset ..< currentOffset + oldCmdSize, with: newCmdData)
                            
                            currentOffset += oldCmdSize
                            replaced = true
                            continue
                        }
                    }
                }
            }
            currentOffset += cmdsize
        }
        return replaced
    }
}
