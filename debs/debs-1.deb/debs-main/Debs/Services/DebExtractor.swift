//
//  DebExtractor.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import Foundation
import ArArchiveKit
import SWCompression

enum DebExtractorError: Error, LocalizedError {
    case failedToCreateTempDirectory
    case archiveReadFailed(String)
    case dataArchiveNotFound
    case dylibSearchFailed

    public var errorDescription: String? {
        switch self {
        case .failedToCreateTempDirectory:
            return "创建临时文件夹失败。请检查应用权限或设备存储空间。"
        case .archiveReadFailed(let reason):
            return "读取归档文件失败: \(reason)"
        case .dataArchiveNotFound:
            return "在 .deb 文件中未能找到 data.tar 归档。"
        case .dylibSearchFailed:
            return "在解压后的文件中查找 .dylib 时发生错误。"
        }
    }
}

class DebExtractor {
    
    static func extractDylibs(from debURL: URL) async throws -> [URL] {
        let fileManager = FileManager.default
        let tempDir = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fileManager.createDirectory(at: tempDir, withIntermediateDirectories: true)
        
        var dylibURLs: Set<URL> = []
        
        do {
            let debData = try Data(contentsOf: debURL)
            let arReader = try ArArchiveReader(archive: [UInt8](debData))
            
            var tarPayload: Data?
            
            for (header, data) in arReader {
                // 【容错增强】：强制清理文件名中的隐藏字符
                let cleanHeaderName = header.name.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\0", with: "")
                
                if cleanHeaderName.starts(with: "data.tar") {
                    let compressedData = Data(data)
                    
                    if cleanHeaderName.hasSuffix(".gz") {
                        tarPayload = try GzipArchive.unarchive(archive: compressedData)
                    } else if cleanHeaderName.hasSuffix(".xz") {
                        tarPayload = try XZArchive.unarchive(archive: compressedData)
                    } else if cleanHeaderName.hasSuffix(".bz2") {
                        tarPayload = try BZip2.decompress(data: compressedData)
                    } else if cleanHeaderName.hasSuffix(".tar") {
                        tarPayload = compressedData
                    } else if cleanHeaderName.hasSuffix(".zst") {
                        tarPayload = try DebExtractor.decompressZstdMultiFrame(compressedData)
                    }
                    
                    if tarPayload != nil {
                        break
                    }
                }
            }
            
            if tarPayload == nil {
                for (header, data) in arReader {
                    let cleanHeaderName = header.name.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\0", with: "")
                    if cleanHeaderName.contains("data.tar") {
                        let compressedData = Data(data)
                        
                        let algorithms: [(String, (Data) throws -> Data)] = [
                            ("Gzip",  { try GzipArchive.unarchive(archive: $0) }),
                            ("XZ",    { try XZArchive.unarchive(archive: $0) }),
                            ("BZip2", { try BZip2.decompress(data: $0) }),
                            ("LZMA",  { try LZMA.decompress(data: $0) }),
                            ("Zstd", { try DebExtractor.decompressZstdMultiFrame($0) }),
                            ("LZip",  { try LZMA.decompress(data: $0) }),
                            ("ZIP",   {
                                let entries = try ZipContainer.open(container: $0)
                                if let first = entries.first(where: { $0.data != nil }) {
                                    return first.data!
                                } else {
                                    throw DebExtractorError.archiveReadFailed("ZIP 内部未找到数据")
                                }
                            })
                        ]
                        
                        for (name, algorithm) in algorithms {
                            do {
                                print("尝试使用 \(name) 解压 \(cleanHeaderName)...")
                                tarPayload = try algorithm(compressedData)
                                print("使用 \(name) 成功解压。")
                                break
                            } catch {
                                continue
                            }
                        }
                        
                        if tarPayload != nil {
                            break
                        }
                    }
                }
            }
            
            guard let tarContainerData = tarPayload else {
                throw DebExtractorError.dataArchiveNotFound
            }
            
            let tarEntries = try TarContainer.open(container: tarContainerData)
            
            for entry in tarEntries {
                guard entry.info.name.hasSuffix(".dylib"), let dylibData = entry.data else {
                    continue
                }
                
                let fileName = URL(fileURLWithPath: entry.info.name).lastPathComponent
                let destinationURL = tempDir.appendingPathComponent(fileName)
                
                try dylibData.write(to: destinationURL)
                dylibURLs.insert(destinationURL)
            }
            
        } catch {
            try? fileManager.removeItem(at: tempDir)
            throw DebExtractorError.archiveReadFailed(error.localizedDescription)
        }
        
        return Array(dylibURLs)
    }
    
    static func decompressZstdMultiFrame(_ compressedData: Data) throws -> Data {
        guard let dstream = ZSTD_createDStream() else {
            throw DebExtractorError.archiveReadFailed("Failed to create ZSTD decompression stream")
        }
        defer {
            ZSTD_freeDStream(dstream)
        }
        
        let initResult = ZSTD_initDStream(dstream)
        if ZSTD_isError(initResult) != 0 {
            let initErrorName = String(cString: ZSTD_getErrorName(initResult))
            throw DebExtractorError.archiveReadFailed("ZSTD stream init error: \(initErrorName)")
        }
        
        var output = Data()
        let chunkSize = 128 * 1024
        
        try compressedData.withUnsafeBytes { (srcBuffer: UnsafeRawBufferPointer) in
            guard let srcBase = srcBuffer.baseAddress?.assumingMemoryBound(to: UInt8.self) else {
                throw DebExtractorError.archiveReadFailed("Invalid source buffer")
            }
            
            var input = ZSTD_inBuffer(src: srcBase, size: compressedData.count, pos: 0)
            
            while input.pos < input.size {
                var outBuffer = [UInt8](repeating: 0, count: chunkSize)
                try outBuffer.withUnsafeMutableBytes { outPtr in
                    var outputBuffer = ZSTD_outBuffer(
                        dst: outPtr.baseAddress!,
                        size: chunkSize,
                        pos: 0
                    )
                    
                    let ret = ZSTD_decompressStream(dstream, &outputBuffer, &input)
                    if ZSTD_isError(ret) != 0 {
                        let errorName = String(cString: ZSTD_getErrorName(ret))
                        throw DebExtractorError.archiveReadFailed("ZSTD decompression stream error: \(errorName)")
                    }
                    
                    output.append(contentsOf: outPtr[..<outputBuffer.pos])
                    
                    if ret == 0 && input.pos == input.size {
                        return
                    }
                }
                if input.pos == input.size {
                    break
                }
            }
        }
        
        if output.isEmpty {
            throw DebExtractorError.archiveReadFailed("ZSTD streaming decompression produced no output")
        }
        
        return output
    }
    
    // ▼▼▼ 完整的解压所有文件函数 ▼▼▼
    static func extractAllFilesWithPermissions(from debURL: URL, to destinationDirectory: URL) async throws -> (permissions: [String: UInt16], symlinks: [String: String], compressionFormat: String) {
        var permissions: [String: UInt16] = [:]
        var symlinks: [String: String] = [:]
        var detectedCompressionFormat = "gz"
        let debData = try Data(contentsOf: debURL)
        let arReader = try ArArchiveReader(archive: [UInt8](debData))
        
        var dataPayload: Data?
        var controlPayload: Data?

        for (header, data) in arReader {
            let compressedData = Data(data)
            var decompressed: Data?
            
            // 【容错增强】：强制清理文件名中的隐藏字符
            let cleanHeaderName = header.name.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\0", with: "")

            if cleanHeaderName.hasSuffix(".gz") {
                decompressed = try? GzipArchive.unarchive(archive: compressedData)
            } else if cleanHeaderName.hasSuffix(".xz") {
                decompressed = try? XZArchive.unarchive(archive: compressedData)
            } else if cleanHeaderName.hasSuffix(".bz2") {
                decompressed = try? BZip2.decompress(data: compressedData)
            } else if cleanHeaderName.hasSuffix(".lzma") {
                decompressed = try? LZMA.decompress(data: compressedData)
            } else if cleanHeaderName.hasSuffix(".zst") {
                decompressed = try? DebExtractor.decompressZstdMultiFrame(compressedData)
            } else if cleanHeaderName.hasSuffix(".tar") {
                decompressed = compressedData
            }

            // 【容错增强】：如果包后缀瞎写导致没解压出来，但它确实是我们需要的数据包，则暴力尝试所有算法
            if decompressed == nil && (cleanHeaderName.starts(with: "data.tar") || cleanHeaderName.starts(with: "control.tar")) {
                let fallbackAlgorithms: [(Data) throws -> Data] = [
                    { try GzipArchive.unarchive(archive: $0) },
                    { try XZArchive.unarchive(archive: $0) },
                    { try BZip2.decompress(data: $0) },
                    { try LZMA.decompress(data: $0) },
                    { try DebExtractor.decompressZstdMultiFrame($0) }
                ]
                for algorithm in fallbackAlgorithms {
                    if let result = try? algorithm(compressedData) {
                        decompressed = result
                        break
                    }
                }
            }

            if cleanHeaderName.starts(with: "data.tar") {
                dataPayload = decompressed
                if decompressed != nil {
                    if cleanHeaderName.hasSuffix(".gz") { detectedCompressionFormat = "gz" }
                    else if cleanHeaderName.hasSuffix(".xz") { detectedCompressionFormat = "xz" }
                    else if cleanHeaderName.hasSuffix(".bz2") { detectedCompressionFormat = "bz2" }
                    else if cleanHeaderName.hasSuffix(".lzma") { detectedCompressionFormat = "lzma" }
                    else if cleanHeaderName.hasSuffix(".zst") { detectedCompressionFormat = "zst" }
                }
            } else if cleanHeaderName.starts(with: "control.tar") {
                controlPayload = decompressed
            }
        }

        guard let dataTarContainerData = dataPayload else {
            throw DebExtractorError.dataArchiveNotFound
        }

        let fileManager = FileManager.default
        let dataEntries = try TarContainer.open(container: dataTarContainerData)
                
        for entry in dataEntries {
            var entryPath = entry.info.name
            if entryPath.hasPrefix("./") {
                entryPath.removeFirst(2)
            }

            let fullDestinationURL = destinationDirectory.appendingPathComponent(entryPath)
            
            if let perms = entry.info.permissions {
                permissions[entryPath] = UInt16(perms.rawValue) // 使用统一格式的路径作为 Key
            }

            if entry.info.type == .directory {
                try fileManager.createDirectory(at: fullDestinationURL, withIntermediateDirectories: true, attributes: nil)
            } else if entry.info.type == .symbolicLink {
                let linkDestination = entry.info.linkName
                let parentDir = fullDestinationURL.deletingLastPathComponent()
                if !fileManager.fileExists(atPath: parentDir.path) {
                    try fileManager.createDirectory(at: parentDir, withIntermediateDirectories: true, attributes: nil)
                }
                try fileManager.createSymbolicLink(atPath: fullDestinationURL.path, withDestinationPath: linkDestination)
                symlinks[entryPath] = linkDestination
            } else if let fileData = entry.data {
                let parentDir = fullDestinationURL.deletingLastPathComponent()
                if !fileManager.fileExists(atPath: parentDir.path) {
                    try fileManager.createDirectory(at: parentDir, withIntermediateDirectories: true, attributes: nil)
                }
                try fileData.write(to: fullDestinationURL, options: .atomic)
            }
        }
            
        if let controlTarData = controlPayload {
            let controlEntries = try TarContainer.open(container: controlTarData)
            let debianDir = destinationDirectory.appendingPathComponent("DEBIAN")
            if !fileManager.fileExists(atPath: debianDir.path) {
                try fileManager.createDirectory(at: debianDir, withIntermediateDirectories: true, attributes: nil)
            }
            
            for entry in controlEntries {
                var entryName = entry.info.name
                if entryName.hasPrefix("./") {
                    entryName.removeFirst(2)
                }
                let fullDestinationURL = debianDir.appendingPathComponent(entryName)
                let permissionPath = "DEBIAN/\(entryName)"
                
                if let perms = entry.info.permissions {
                    permissions[permissionPath] = UInt16(perms.rawValue) // 使用统一格式的路径作为 Key
                }
                if let fileData = entry.data {
                    try fileData.write(to: fullDestinationURL, options: .atomic)
                }
            }
        }

        return (permissions: permissions, symlinks: symlinks, compressionFormat: detectedCompressionFormat)
    }
}
