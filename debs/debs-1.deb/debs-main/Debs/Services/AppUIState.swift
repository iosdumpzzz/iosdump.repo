//
//  AppUIState.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import Foundation
import SwiftUI

@MainActor
class AppUIState: ObservableObject {
    @Published var isExtracting: Bool = false
    @Published var isZipping: Bool = false
    @Published var isAddingSources: Bool = false
    @Published var loadingMessage: String = ""
    @Published var isRefreshing: Bool = false
    @Published var isDeleting: Bool = false
    @Published var selectedTab: Int = 0 // 0 = 越狱源, 1 = Debs, 2 = 管理文件
    @Published var pendingIpaAnalysisURL: URL? // 用于存放从外部传入的、等待分析的IPA URL
    @Published var needsFileListRefresh: Int = 0
    @Published var pendingDebExtractionURL: URL?
    @Published var activeTemporaryFileURL: URL?
}
