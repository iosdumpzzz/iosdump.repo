//
//  FileImportService.swift
//  Debs
//
//  Created by Z on 2025/10/11.
//

// 文件路径: Debs/Services/FileImportService.swift
import Foundation

class FileImportService {
    
    static let shared = FileImportService()
    private init() {}

    private func downloadsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        let debsDir = documentsDirectory.appendingPathComponent("Downloads/DEBs")
        if !FileManager.default.fileExists(atPath: debsDir.path) {
            try? FileManager.default.createDirectory(at: debsDir, withIntermediateDirectories: true, attributes: nil)
        }
        return debsDir
    }

    /// 将一个外部文件复制到应用的下载目录中。
    @discardableResult
    func copyFileToDownloads(from sourceURL: URL) -> URL? {
        let fileManager = FileManager.default
        let destinationDir = downloadsDirectory()
        var destinationURL = destinationDir.appendingPathComponent(sourceURL.lastPathComponent)
        var counter = 1
        let baseFileName = destinationURL.deletingPathExtension().lastPathComponent
        let fileExtension = destinationURL.pathExtension

        while fileManager.fileExists(atPath: destinationURL.path) {
            let newFileName = "\(baseFileName) (\(counter)).\(fileExtension)"
            destinationURL = destinationDir.appendingPathComponent(newFileName)
            counter += 1
        }
        
        do {
               let shouldStopAccessing = sourceURL.startAccessingSecurityScopedResource()
               defer {
                   if shouldStopAccessing {
                       sourceURL.stopAccessingSecurityScopedResource()
                   }
               }
               
               try fileManager.copyItem(at: sourceURL, to: destinationURL)
               print("Successfully imported file to permanent directory: \(destinationURL.path)")
               return destinationURL // 成功后返回新的 URL
           } catch {
               print("Error importing file to permanent directory: \(error.localizedDescription)")
               return nil // 失败后返回 nil
           }
       }
       // ▲▲▲ 替换结束 ▲▲▲
    
    // ▼▼▼ 在这里添加以下两个新函数 ▼▼▼
    
    /// 将外部文件复制到一个唯一的临时目录中，用于临时处理。
    func copyFileToTemporaryDirectory(from sourceURL: URL) -> URL? {
        let fileManager = FileManager.default
        // 创建一个基于 UUID 的唯一临时文件夹路径
        let tempDir = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        
        do {
            try fileManager.createDirectory(at: tempDir, withIntermediateDirectories: true)
            let destinationURL = tempDir.appendingPathComponent(sourceURL.lastPathComponent)
            try fileManager.copyItem(at: sourceURL, to: destinationURL)
            print("Successfully copied file to temporary directory: \(destinationURL.path)")
            return destinationURL
        } catch {
            print("Error copying file to temporary directory: \(error.localizedDescription)")
            return nil
        }
    }
    
    /// 清理临时文件。会删除传入 URL 的整个父目录。
    func cleanup(temporaryItemURL: URL?) {
        guard let url = temporaryItemURL else { return }
        let fileManager = FileManager.default
        // 我们删除的是包含该文件的整个临时文件夹 (UUID命名的那个)
        let parentDirectory = url.deletingLastPathComponent()
        
        do {
            try fileManager.removeItem(at: parentDirectory)
            print("Successfully cleaned up temporary directory: \(parentDirectory.path)")
        } catch {
            print("Failed to clean up temporary directory: \(error.localizedDescription)")
        }
    }
    // ▲▲▲ 新增结束 ▲▲▲
    // ▼▼▼ 在 FileImportService.swift 类的末尾，添加这个新函数 ▼▼▼

    /// 安全地将一个可能来自沙盒外部的 URL 复制到应用内部的一个指定位置。
    /// 这个函数会自动处理安全作用域 URL 的权限问题。
    /// - Parameters:
    ///   - sourceURL: 从 DocumentPicker 等获取的外部 URL。
    ///   - destinationURL: 应用沙盒内的目标完整路径。
    /// - Returns: 如果复制成功，返回 true；否则返回 false。
    func secureCopyItem(from sourceURL: URL, to destinationURL: URL) -> Bool {
        let shouldStopAccessing = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if shouldStopAccessing {
                sourceURL.stopAccessingSecurityScopedResource()
            }
        }
        
        do {
            // 在复制前，如果目标位置已存在文件，先尝试删除
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.copyItem(at: sourceURL, to: destinationURL)
            print("Securely copied item to: \(destinationURL.path)")
            return true
        } catch {
            print("Error during secure copy: \(error.localizedDescription)")
            return false
        }
    }
}
