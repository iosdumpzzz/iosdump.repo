//
//  DownloadMetadataService.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import Foundation

@MainActor
class DownloadMetadataService: ObservableObject {
    static let shared = DownloadMetadataService()

    @Published private(set) var items: [String: DownloadedItem] = [:]

    private let storageURL: URL

    private init() {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.storageURL = documentsDirectory.appendingPathComponent("downloaded_metadata.plist")
        
        loadItems()
    }

    /// 从磁盘加载“下载清单”
    private func loadItems() {
        do {
            let data = try Data(contentsOf: storageURL)
            let decoder = PropertyListDecoder()
            let loadedItems = try decoder.decode([DownloadedItem].self, from: data)
            
            // 将加载的数组转换为字典以便快速访问
            var itemsDict: [String: DownloadedItem] = [:]
            for item in loadedItems {
                itemsDict[item.fileName] = item
            }
            self.items = itemsDict
            
        } catch {
            print("未能加载下载元数据，可能文件尚不存在。 \(error.localizedDescription)")
            self.items = [:]
        }
    }

    /// 将当前的“下载清单”保存到磁盘
    private func saveItems() {
        do {
            let encoder = PropertyListEncoder()
            // 将字典的值（数组）进行编码
            let data = try encoder.encode(Array(items.values))
            try data.write(to: storageURL, options: .atomic)
        } catch {
            print("保存下载元数据失败: \(error.localizedDescription)")
        }
    }

    /// 添加一条新的下载记录
    func addItem(fileName: String, package: Package, source: Source) {
        let newItem = DownloadedItem(fileName: fileName, package: package, source: source)
        items[fileName] = newItem
        saveItems()
    }

    /// 根据文件名删除一条下载记录
    func removeItem(for fileName: String) {
        items.removeValue(forKey: fileName)
        saveItems()
    }
    
    /// 根据文件名获取一条下载记录
    func getItem(for fileName: String) -> DownloadedItem? {
        return items[fileName]
    }
}
