//
//  ZipService.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

// 文件路径: Debs/Services/ZipService.swift
import Foundation
import ZIPFoundation // 确保您已经通过 SPM 添加了这个依赖

enum ZipError: LocalizedError {
    // 现在这个枚举可以简化，但我们保留它以便提供自定义的错误信息
    case fileAdditionFailed(Error)

    var errorDescription: String? {
        switch self {
        case .fileAdditionFailed(let underlyingError):
            return "向压缩包添加文件时出错: \(underlyingError.localizedDescription)"
        }
    }
}

class ZipService {
    
    static func createZip(from files: [URL], zipFileName: String) async throws -> URL {
        let fileManager = FileManager.default
        let tempDirectory = fileManager.temporaryDirectory
        let zipFileURL = tempDirectory.appendingPathComponent("\(zipFileName).zip")

        if fileManager.fileExists(atPath: zipFileURL.path) {
            try? fileManager.removeItem(at: zipFileURL)
        }

        let archive = try Archive(url: zipFileURL, accessMode: .create)

        for fileURL in files {
            var isDirectory: ObjCBool = false
            if fileManager.fileExists(atPath: fileURL.path, isDirectory: &isDirectory) {
                
                // --- 这是关键的修正逻辑 ---
                if isDirectory.boolValue {
                    // 如果是文件夹，则递归遍历并添加其所有内容
                    let resourceKeys: [URLResourceKey] = [.nameKey, .isDirectoryKey]
                    guard let enumerator = fileManager.enumerator(at: fileURL, includingPropertiesForKeys: resourceKeys, options: .skipsHiddenFiles) else {
                        continue
                    }

                    while let item = enumerator.nextObject() {
                        guard let itemURL = item as? URL else { continue }

                        // 计算文件在压缩包内的相对路径... (这部分逻辑保持不变)
                        let relativePath = itemURL.path.replacingOccurrences(of: fileURL.deletingLastPathComponent().path + "/", with: "")

                        do {
                            try archive.addEntry(with: relativePath, fileURL: itemURL)
                        } catch {
                            throw ZipError.fileAdditionFailed(error)
                        }
                    }
                } else {
                    // 如果是单个文件，则使用旧的逻辑
                    do {
                        try archive.addEntry(with: fileURL.lastPathComponent, fileURL: fileURL)
                    } catch {
                        throw ZipError.fileAdditionFailed(error)
                    }
                }
            }
        }

        return zipFileURL
    }
}
