//
//  GitHubRepoService.swift
//  Debs
//

import Foundation

struct ManagedRepo: Identifiable, Codable {
    var id = UUID()
    let owner: String      // GitHub 用户名
    let repoName: String   // 仓库名
    let token: String      // GitHub Personal Access Token
    var customPath: String? // 新增：自定义目录路径
}

struct GitHubContent: Codable {
    let name: String
    let sha: String
    let type: String
}

// 用于获取文件详细内容的结构体（重命名时需要获取原文件的Base64内容）
struct GitHubFileDetail: Codable {
    let content: String
    let sha: String
}

@MainActor
class GitHubRepoService: ObservableObject {
    static let shared = GitHubRepoService()
    
    @Published var repos: [ManagedRepo] = []
    private let storageURL: URL
    
    private init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.storageURL = docs.appendingPathComponent("managed_github_repos.plist")
        loadRepos()
    }
    
    // 获取指定目录下的文件列表（智能处理根目录）
    func fetchDebs(for repo: ManagedRepo, targetPath: String) async throws -> [GitHubContent] {
        let urlString = targetPath.isEmpty ? "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents" : "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents/\(targetPath)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(repo.token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        // 如果状态码是 404，说明该文件夹还不存在，返回空数组
        if let httpResp = response as? HTTPURLResponse, httpResp.statusCode == 404 {
            return []
        }
        
        return try JSONDecoder().decode([GitHubContent].self, from: data)
    }
    
    // 直接上传/覆盖 Deb 文件到 GitHub 指定目录
    func pushDeb(to repo: ManagedRepo, fileURL: URL, targetPath: String) async throws {
        let fileName = fileURL.lastPathComponent
        let basePath = targetPath.isEmpty ? "" : "\(targetPath)/"
        let urlString = "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents/\(basePath)\(fileName)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        // 1. 读取本地文件并转为 Base64
        let fileData = try Data(contentsOf: fileURL)
        let base64Content = fileData.base64EncodedString()
        
        // 2. 检查文件是否已存在 (以获取对应的 SHA 以便覆盖)
        var existingSha: String? = nil
        if let existingDebs = try? await fetchDebs(for: repo, targetPath: targetPath) {
            existingSha = existingDebs.first(where: { $0.name == fileName })?.sha
        }
        
        // 3. 构建上传请求
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("Bearer \(repo.token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        // 生成时间戳作为 Commit Message
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        let timeString = formatter.string(from: Date())
        let commitMessage = "Auto Upload Deb: \(timeString)"
        
        var bodyDict: [String: Any] = [
            "message": commitMessage,
            "content": base64Content
        ]
        if let sha = existingSha {
            bodyDict["sha"] = sha // 如果覆盖原文件，必须带上原来的 SHA
        }
        
        request.httpBody = try JSONSerialization.data(withJSONObject: bodyDict)
        
        // 4. 执行上传
        let (_, response) = try await URLSession.shared.data(for: request)
        if let httpResp = response as? HTTPURLResponse, !(200...201).contains(httpResp.statusCode) {
            throw NSError(domain: "GitHubAPI", code: httpResp.statusCode, userInfo: [NSLocalizedDescriptionKey: "上传失败，HTTP 状态码: \(httpResp.statusCode)。请检查 Token 权限或仓库是否存在。"])
        }
    }
    
    // 删除远程仓库中的文件
    func deleteRemoteFile(repo: ManagedRepo, fileName: String, sha: String, targetPath: String) async throws {
        let basePath = targetPath.isEmpty ? "" : "\(targetPath)/"
        let urlString = "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents/\(basePath)\(fileName)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(repo.token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        let bodyDict: [String: Any] = [
            "message": "Delete \(fileName)",
            "sha": sha
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: bodyDict)
        
        let (_, response) = try await URLSession.shared.data(for: request)
        if let httpResp = response as? HTTPURLResponse, httpResp.statusCode != 200 {
            throw NSError(domain: "GitHubAPI", code: httpResp.statusCode, userInfo: [NSLocalizedDescriptionKey: "删除失败，HTTP 状态码: \(httpResp.statusCode)"])
        }
    }
    
    // 重命名远程仓库中的文件 (获取原内容 -> PUT新文件 -> DELETE老文件)
    func renameRemoteFile(repo: ManagedRepo, oldFileName: String, oldSha: String, newFileName: String, targetPath: String) async throws {
        let basePath = targetPath.isEmpty ? "" : "\(targetPath)/"
        
        // 1. 获取原文件的完整内容 (Base64)
        let getUrlString = "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents/\(basePath)\(oldFileName)"
        guard let getUrl = URL(string: getUrlString) else { throw URLError(.badURL) }
        var getReq = URLRequest(url: getUrl)
        getReq.httpMethod = "GET"
        getReq.setValue("Bearer \(repo.token)", forHTTPHeaderField: "Authorization")
        getReq.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        let (getData, getResp) = try await URLSession.shared.data(for: getReq)
        guard let httpGetResp = getResp as? HTTPURLResponse, httpGetResp.statusCode == 200 else {
            throw NSError(domain: "GitHubAPI", code: (getResp as? HTTPURLResponse)?.statusCode ?? 500, userInfo: [NSLocalizedDescriptionKey: "获取原文件内容失败"])
        }
        
        let fileDetail = try JSONDecoder().decode(GitHubFileDetail.self, from: getData)
        let base64Content = fileDetail.content.replacingOccurrences(of: "\n", with: "") // GitHub API有时带有换行符，需剔除
        
        // 2. 将内容以新的文件名 PUT 上去
        let putUrlString = "https://api.github.com/repos/\(repo.owner)/\(repo.repoName)/contents/\(basePath)\(newFileName)"
        guard let putUrl = URL(string: putUrlString) else { throw URLError(.badURL) }
        var putReq = URLRequest(url: putUrl)
        putReq.httpMethod = "PUT"
        putReq.setValue("Bearer \(repo.token)", forHTTPHeaderField: "Authorization")
        putReq.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        let putBody: [String: Any] = [
            "message": "Rename \(oldFileName) to \(newFileName)",
            "content": base64Content
        ]
        putReq.httpBody = try JSONSerialization.data(withJSONObject: putBody)
        let (_, putResp) = try await URLSession.shared.data(for: putReq)
        guard let httpPutResp = putResp as? HTTPURLResponse, (200...201).contains(httpPutResp.statusCode) else {
            throw NSError(domain: "GitHubAPI", code: (putResp as? HTTPURLResponse)?.statusCode ?? 500, userInfo: [NSLocalizedDescriptionKey: "创建新文件名文件失败"])
        }
        
        // 3. 成功后删除老文件
        try await deleteRemoteFile(repo: repo, fileName: oldFileName, sha: oldSha, targetPath: targetPath)
    }
    
    func addRepo(owner: String, repoName: String, token: String) {
        let newRepo = ManagedRepo(owner: owner.trimmingCharacters(in: .whitespacesAndNewlines),
                                  repoName: repoName.trimmingCharacters(in: .whitespacesAndNewlines),
                                  token: token.trimmingCharacters(in: .whitespacesAndNewlines),
                                  customPath: "debs") // 默认目录
        repos.append(newRepo)
        saveRepos()
    }
    
    func deleteRepo(at offsets: IndexSet) {
        repos.remove(atOffsets: offsets)
        saveRepos()
    }
    
    // 更新自定义路径
    func updateCustomPath(for repoID: UUID, newPath: String) {
        if let index = repos.firstIndex(where: { $0.id == repoID }) {
            repos[index].customPath = newPath
            saveRepos()
        }
    }
    
    private func loadRepos() {
        if let data = try? Data(contentsOf: storageURL),
           let decoded = try? PropertyListDecoder().decode([ManagedRepo].self, from: data) {
            self.repos = decoded
        }
    }
    
    private func saveRepos() {
        if let data = try? PropertyListEncoder().encode(repos) {
            try? data.write(to: storageURL)
        }
    }
}
