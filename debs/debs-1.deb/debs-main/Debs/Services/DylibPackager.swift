//
//  DylibPackager.swift
//  Debs
//
//  Created by Z on 2025/11/6.
//

import Foundation
import SWCompression
import ArArchiveKit

enum PackageScheme: String {
    case rootfulArm      // iphoneos-arm
    case rootlessArm64   // iphoneos-arm64
    case roothideArm64e  // 隐根
}

enum DylibPackagerError: LocalizedError {
    case dylibReadFailed(String, Error)
    case archiveCreationFailed(String)
    case writeFailed(Error)
    
    var errorDescription: String? { 
        switch self {
        case .dylibReadFailed(let name, let error):
            return "读取文件 \(name) 失败，请重新导入: \(error.localizedDescription)"
        case .archiveCreationFailed(let reason):
            return "创建归档失败: \(reason)"
        case .writeFailed(let error):
            return "写入临时文件失败: \(error.localizedDescription)"
        }
    }
}

struct DylibItem: Identifiable {
    let id = UUID()
    let url: URL
    let name: String
    var targetsText: String = ""
    var targetKeyRaw: String = "auto"
    var plistModeRaw: String = "Any"
}

class DylibPackager {

    struct Metadata {
        let packageName: String 
        let version: String 
        let author: String 
        let description: String 
        let displayName: String 
        let maintainer: String?
        let dylibs: [DylibItem] 

        init(
            packageName: String,
            version: String,
            author: String,
            description: String,
            displayName: String,
            maintainer: String? = nil,
            dylibs: [DylibItem]
        ) {
            self.packageName = packageName
            self.version = version
            self.author = author
            self.description = description
            self.displayName = displayName
            self.maintainer = maintainer
            self.dylibs = dylibs
        }
    }

    static func package(
        metadata: Metadata,
        scheme: PackageScheme = .rootfulArm
    ) async throws -> URL {
        
        do {
            let pkg = metadata.packageName
            if !pkg.canBeConverted(to: .ascii) {
                throw DylibPackagerError.archiveCreationFailed("包名只能包含 ASCII 字符（小写字母、数字、+.-），不能包含中文或空格。示例：com.example.tweak")
            }
            let pattern = "^[a-z0-9][a-z0-9+.-]*$"
            if pkg.range(of: pattern, options: .regularExpression) == nil {
                 throw DylibPackagerError.archiveCreationFailed("包名无效：仅允许小写字母、数字、+ .-，不能包含中文、空格或大写字母。示例：com.example.tweak")
            }
        }

        // 核心修改：为了彻底契合标准的 Roothide Compat 包结构，初始组装时指定目录
        let (archString, tweakDir): (String, String) = {
            switch scheme {
            case .rootfulArm:
                return ("iphoneos-arm", "Library/MobileSubstrate/DynamicLibraries")
            case .rootlessArm64:
                return ("iphoneos-arm64", "var/jb/usr/lib/TweakInject")
            case .roothideArm64e:
                // 隐根专属初始路径（剥离 var/jb 后即为标准结构）
                return ("iphoneos-arm64", "var/jb/Library/MobileSubstrate/DynamicLibraries")
            }
        }()
        
        let maint = (metadata.maintainer?.isEmpty == false) ? metadata.maintainer! : metadata.author
        var controlString = """
Package: \(metadata.packageName)
Version: \(metadata.version)
Section: Tweaks
Priority: optional
Architecture: \(archString)
Replaces: \(metadata.packageName)
Provides: \(metadata.packageName)
Conflicts: \(metadata.packageName)
Essential: no
Maintainer: \(maint)
Description: \(metadata.description)
Name: \(metadata.displayName)
Author: \(metadata.author)
"""
        if !controlString.hasSuffix("\n") { controlString += "\n" }

        let controlTarData = try createTarData(
            files: [(name: "control", data: controlString.data(using: .utf8)!)],
            permissions: [:]
        )
        let compressedControlData = try GzipArchive.archive(data: controlTarData)
         
        var dataTarFiles: [(name: String, data: Data)] = []
        var dataTarPermissions: [String: UInt16] = [:]

        for item in metadata.dylibs {
            let dylibData: Data
            do {
                let secured = item.url.startAccessingSecurityScopedResource()
                defer {
                    if secured { item.url.stopAccessingSecurityScopedResource() }
                }
                dylibData = try Data(contentsOf: item.url)
            } catch {
                throw DylibPackagerError.dylibReadFailed(item.name, error)
            }

            let dylibBaseName = item.name.replacingOccurrences(of: ".dylib", with: "")

            let rawTargets = item.targetsText
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
            
            guard !rawTargets.isEmpty else {
                throw DylibPackagerError.archiveCreationFailed("未指定 \(item.name) 的注入目标")
            }
            
            let keyChoice = item.targetKeyRaw.lowercased()
            let mode = item.plistModeRaw.trimmingCharacters(in: .whitespacesAndNewlines)
            
            var bundlesList: [String] = []
            var executablesList: [String] = []
             
            switch keyChoice {
            case "bundles":
                bundlesList = rawTargets
            case "executables":
                executablesList = rawTargets
            default: // auto
                for t in rawTargets {
                    if t.contains(".") { bundlesList.append(t) } else { executablesList.append(t) }
                }
            }
            
            if bundlesList.isEmpty && executablesList.isEmpty, let first = rawTargets.first {
                executablesList = [first]
            }

            // --- ▼▼▼ 核心修复点：废弃旧的字符串拼接，改用原生字典转 XML ---
            var filterDict: [String: Any] = ["Mode": mode]
            
            if !bundlesList.isEmpty {
                filterDict["Bundles"] = bundlesList
            }
            if !executablesList.isEmpty {
                filterDict["Executables"] = executablesList
            }
            
            let plistDict: [String: Any] = ["Filter": filterDict]
            let plistData: Data
            
            do {
                // 原生生成极其规范、无兼容性问题的 XML 格式 Plist
                plistData = try PropertyListSerialization.data(fromPropertyList: plistDict, format: .xml, options: 0)
            } catch {
                throw DylibPackagerError.archiveCreationFailed("生成 Plist 失败: \(error.localizedDescription)")
            }

            let dylibPath = "\(tweakDir)/\(dylibBaseName).dylib"
            let plistPath = "\(tweakDir)/\(dylibBaseName).plist"
            
            dataTarFiles.append((name: dylibPath, data: dylibData))
            dataTarFiles.append((name: plistPath, data: plistData))
            // --- ▲▲▲ 核心修复点结束 ---
            
            dataTarPermissions[dylibPath] = 0o755 
            dataTarPermissions[plistPath] = 0o644 
        }

        let dataTarData = try createTarData(files: dataTarFiles, permissions: dataTarPermissions)
        let compressedData = try GzipArchive.archive(data: dataTarData)

        let debianBinaryData = "2.0\n".data(using: .utf8)!

        var arWriter = ArArchiveWriter()
        let modificationTime = Int(Date().timeIntervalSince1970)
        
        arWriter.addFile(
            header: Header(name: "debian-binary", userID: 0, groupID: 0, mode: 0o644, modificationTime: modificationTime),
            contents: Array(debianBinaryData)
        )
         
        arWriter.addFile(
            header: Header(name: "control.tar.gz", userID: 0, groupID: 0, mode: 0o644, modificationTime: modificationTime),
            contents: Array(compressedControlData)
        )
        
        arWriter.addFile(
            header: Header(name: "data.tar.gz", userID: 0, groupID: 0, mode: 0o644, modificationTime: modificationTime),
            contents: Array(compressedData)
        )

        let finalDebBytes = arWriter.finalize()
        let finalDebData = Data(finalDebBytes)

        let tempDir = FileManager.default.temporaryDirectory
        let suffix: String = {
            switch scheme {
            case .rootfulArm:     return "-rootful"
            case .rootlessArm64:  return "-rootless"
            case .roothideArm64e: return "-roothide-temp" // 用于隐根转译时的防冲突基础名
            }
        }()
        let finalDebURL = tempDir.appendingPathComponent("\(metadata.packageName)-\(metadata.version)\(suffix).deb")
        
        if FileManager.default.fileExists(atPath: finalDebURL.path) {
            try FileManager.default.removeItem(at: finalDebURL)
        }
        
         do {
            try finalDebData.write(to: finalDebURL)
        } catch {
            throw DylibPackagerError.writeFailed(error)
        }
        
        return finalDebURL
    }

    private static func createTarData(
        files: [(name: String, data: Data)],
        permissions: [String: UInt16]
    ) throws -> Data {
        var entries: [TarEntry] = []
        var directories = Set<String>()

        for (path, data) in files {
            var currentPath = ""
            let components = path.split(separator: "/")
             
            for i in 0..<(components.count - 1) { 
                currentPath += (i > 0 ? "/" : "") + components[i]
                if !directories.contains(currentPath) {
                    var dirInfo = TarEntryInfo(name: currentPath, type: .directory)
                    dirInfo.permissions = Permissions(rawValue: 0o755) 
                    entries.append(TarEntry(info: dirInfo, data: Data()))
                    directories.insert(currentPath)
                }
            }
            
            var fileInfo = TarEntryInfo(name: path, type: .regular)
            let perms = permissions[path] ?? 0o644
            fileInfo.permissions = Permissions(rawValue: UInt32(perms))
            fileInfo.modificationTime = Date()
            
            entries.append(TarEntry(info: fileInfo, data: data))
        }

        let tarData = TarContainer.create(from: entries, force: .ustar)
        if tarData.isEmpty && !entries.isEmpty {
            throw DylibPackagerError.archiveCreationFailed("TarContainer.create returned empty data")
        }
        return tarData
    }
}
