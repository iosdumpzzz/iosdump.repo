//
//  DownloadManager.swift
//  Debs
//
//  Created by Z on 2025/10/8.
//

import SwiftUI

@MainActor
class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published var isDownloading = false
    @Published var progress: Double = 0.0
    @Published var showSuccessAlert = false
    @Published var downloadedFileName: String = ""

    @AppStorage("renameDebsToPackageNameEnabled") private var renameEnabled = true

    private var downloadTask: URLSessionDownloadTask?
    private var session: URLSession!
    
    private var activeDownloads: [URLSessionDownloadTask: (package: Package, source: Source)] = [:]

    override init() {
        super.init()
        let config = URLSessionConfiguration.default
        self.session = URLSession(configuration: config, delegate: self, delegateQueue: .main)
    }
    
    func startDownload(package: Package, from source: Source) {
        let url = source.url.appendingPathComponent(package.filename)
        let downloadTask = session.downloadTask(with: url)

        activeDownloads[downloadTask] = (package, source)

        var finalFileName: String
        if renameEnabled {
            let illegalChars = CharacterSet(charactersIn: "/\\?%*|\"<>:")
            let sanitizedName = package.name.components(separatedBy: illegalChars).joined(separator: "_")
            finalFileName = "\(sanitizedName)-\(package.version)-\(package.architecture).deb"
        } else {
            finalFileName = (package.filename as NSString).lastPathComponent
        }
        
        downloadTask.taskDescription = finalFileName
        downloadTask.resume()
        isDownloading = true
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let originalFileName = downloadTask.taskDescription else {
            Task { @MainActor in self.isDownloading = false }
            return
        }
        
        let downloadInfo = Task { @MainActor in
            return self.activeDownloads[downloadTask]
        }

        let fileManager = FileManager.default
        let docsDir = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let debsDir = docsDir.appendingPathComponent("Downloads/DEBs")
        if !fileManager.fileExists(atPath: debsDir.path) {
            try? fileManager.createDirectory(at: debsDir, withIntermediateDirectories: true, attributes: nil)
        }
        var destinationURL = debsDir.appendingPathComponent(originalFileName)
        var counter = 1
        let baseFileName = destinationURL.deletingPathExtension().lastPathComponent
        let fileExtension = destinationURL.pathExtension
        while fileManager.fileExists(atPath: destinationURL.path) {
            let newFileName = "\(baseFileName) (\(counter)).\(fileExtension)"
            destinationURL = debsDir.appendingPathComponent(newFileName)
            counter += 1
        }
        
        do {
            try fileManager.moveItem(at: location, to: destinationURL)
            
            let finalFileName = destinationURL.lastPathComponent
            
            Task {
                if let info = await downloadInfo.value {
                    await DownloadMetadataService.shared.addItem(
                        fileName: finalFileName,
                        package: info.package,
                        source: info.source
                    )
                }
                
                await MainActor.run {
                    self.isDownloading = false
                    self.progress = 0.0
                    self.downloadedFileName = finalFileName
                    self.showSuccessAlert = true
                }
            }
        } catch {
            print("Error moving file: \(error)")
            Task { @MainActor in
                self.isDownloading = false
            }
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let newProgress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        Task { @MainActor in
            self.progress = newProgress
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let downloadTask = task as? URLSessionDownloadTask {
            Task { @MainActor in
                self.activeDownloads[downloadTask] = nil
            }
        }

        Task { @MainActor in
            if let error = error, (error as NSError).code != NSURLErrorCancelled {
                print("Download failed: \(error.localizedDescription)")
                self.isDownloading = false
            }
        }
    }
}
