//
//  DebPackager.swift
//  Debs
//
//  Created by Z on 2025/10/13.
//

// File: Debs/Services/DebPackager.swift
import Foundation
import SWCompression
import ArArchiveKit

enum DebPackagerError: LocalizedError {
    case controlDirectoryNotFound
    case failedToCreateTarArchive(String)
    case failedToCreateArArchive(String)
    case failedToWriteDebFile(Error)
    
    var errorDescription: String? {
        switch self {
        case .controlDirectoryNotFound:
            return "未能找到 'DEBIAN' 控制文件夹。"
        case .failedToCreateTarArchive(let reason):
            return "创建 tar 归档失败: \(reason)"
        case .failedToCreateArArchive(let reason):
            return "创建 ar 归档失败: \(reason)"
        case .failedToWriteDebFile(let error):
            return "将最终的 deb 文件写入磁盘时失败: \(error.localizedDescription)"
        }
    }
}

class DebPackager {
    
    static func packageProject(projectURL: URL, permissions: [String: UInt16], symlinks: [String: String], compressionFormat: String) async throws -> URL {
        let fileManager = FileManager.default
        let controlDirName = "DEBIAN"
        let controlDirURL = projectURL.appendingPathComponent(controlDirName)

        guard fileManager.fileExists(atPath: controlDirURL.path) else {
            throw DebPackagerError.controlDirectoryNotFound
        }

        let controlTarData = createTarData(from: controlDirURL, baseURL: controlDirURL, permissions: permissions, symlinks: symlinks)
            let dataTarData = createTarData(from: projectURL, baseURL: projectURL, excluding: [controlDirName], permissions: permissions, symlinks: symlinks)
        let debianBinaryData = "2.0\n".data(using: .utf8)!

        // Part A: 为确保商店兼容性，强制对 control 文件使用 GZIP
        let compressedControlData = try GzipArchive.archive(data: controlTarData)
        let controlFileName = "control.tar.gz"

        // Part B: 动态压缩 data 文件，并正确处理回退逻辑
        let compressedData: Data
        let dataFormat = compressionFormat.isEmpty ? "gz" : compressionFormat
        
        // 这个变量将持有最终使用的文件后缀名
        var finalDataFileExtension = dataFormat

        switch dataFormat {
        
        case "xz":
            print("Warning: XZ compression is not supported by this configuration. Falling back to Gzip.")
            finalDataFileExtension = "gz"
            compressedData = try GzipArchive.archive(data: dataTarData)
            break

        // ▼▼▼ 修改开始：将 LZMA 逻辑修改为回退到 Gzip ▼▼▼
        case "lzma":
            print("Warning: LZMA compression is disabled. Falling back to Gzip.")
            finalDataFileExtension = "gz" // 确保最终文件名也是 .gz
            compressedData = try GzipArchive.archive(data: dataTarData) // 直接执行 Gzip 压缩
            break
        // ▲▲▲ 修改结束 ▲▲▲

        case "bz2":
            compressedData = BZip2.compress(data: dataTarData)
            break

        case "zst":
            compressedData = try DebPackager.compressZstd(data: dataTarData)
            break

        case "gz":
            fallthrough

        default:
            compressedData = try GzipArchive.archive(data: dataTarData)
        }
        
        let dataFileName = "data.tar.\(finalDataFileExtension)"

        // --- 文件打包部分 ---
        var arWriter = ArArchiveWriter()

        arWriter.addFile(
            header: Header(name: "debian-binary", userID: 0, groupID: 0, mode: 0o644, modificationTime: Int(Date().timeIntervalSince1970)),
            contents: Array(debianBinaryData)
        )

        arWriter.addFile(
            header: Header(name: controlFileName, userID: 0, groupID: 0, mode: 0o644, modificationTime: Int(Date().timeIntervalSince1970)),
            contents: Array(compressedControlData)
        )
        
        arWriter.addFile(
            header: Header(name: dataFileName, userID: 0, groupID: 0, mode: 0o644, modificationTime: Int(Date().timeIntervalSince1970)),
            contents: Array(compressedData)
        )

        let finalDebBytes = arWriter.finalize()
        let finalDebData = Data(finalDebBytes)

        let tempDir = fileManager.temporaryDirectory
        let newDebName = projectURL.lastPathComponent + ".deb"
        let finalDebURL = tempDir.appendingPathComponent(newDebName)

        if fileManager.fileExists(atPath: finalDebURL.path) {
            try fileManager.removeItem(at: finalDebURL)
        }

        do {
            try finalDebData.write(to: finalDebURL)
        } catch {
            throw DebPackagerError.failedToWriteDebFile(error)
        }

        return finalDebURL
    }
    
    // ▼▼▼ 在 DebPackager.swift 类的内部，添加下面这个全新的函数 ▼▼▼

    /// 使用 Zstandard C 库来压缩数据。
    /// - Parameter data: 需要被压缩的原始数据。
    /// - Returns: 压缩后的数据。
    /// - Throws: 如果 Zstd 压缩失败，则抛出错误。
    private static func compressZstd(data: Data) throws -> Data {
        // 1. 获取 Zstd 推荐的最大压缩后尺寸，以确保我们的输出缓冲区足够大。
        let outputBufferSize = ZSTD_compressBound(data.count)
        
        // 2. 创建一个空的输出缓冲区。
        var outputBuffer = [UInt8](repeating: 0, count: outputBufferSize)
        
        // 3. 调用 ZSTD_compress C 函数来执行压缩。
        // 我们使用 withUnsafeBytes 和 withUnsafeMutableBytes 来安全地获取指向数据内存的指针。
        let compressedSize = try data.withUnsafeBytes { (inputPtr: UnsafeRawBufferPointer) -> Int in
            try outputBuffer.withUnsafeMutableBytes { (outputPtr: UnsafeMutableRawBufferPointer) -> Int in
                
                // 调用核心压缩函数
                let result = ZSTD_compress(outputPtr.baseAddress,   // 目标缓冲区指针
                                           outputBufferSize,        // 目标缓冲区大小
                                           inputPtr.baseAddress,    // 源数据指针
                                           data.count,              // 源数据大小
                                           ZSTD_CLEVEL_DEFAULT)    // 使用默认压缩等级
                
                // 4. 错误检查。如果 ZSTD_isError 返回非零值，说明发生了错误。
                if ZSTD_isError(result) != 0 {
                    // 获取 Zstd C 库提供的错误描述字符串。
                    if let errorName = ZSTD_getErrorName(result) {
                        let errorString = String(cString: errorName)
                        throw DebPackagerError.failedToCreateTarArchive("ZSTD compression failed: \(errorString)")
                    } else {
                        throw DebPackagerError.failedToCreateTarArchive("ZSTD compression failed with unknown error.")
                    }
                }
                
                return result
            }
        }
        
        // 5. 压缩成功，根据实际压缩后的大小，从输出缓冲区创建最终的 Data 对象。
        return Data(outputBuffer.prefix(compressedSize))
    }

    // ▲▲▲ 新函数添加结束 ▲▲▲

    // ▼▼▼ 请用这个全新的函数，完整替换掉旧的 createTarData 函数 ▼▼▼
    private static func createTarData(from directoryURL: URL, baseURL: URL, excluding excludedItems: [String] = [], permissions: [String: UInt16], symlinks: [String: String]) -> Data {
            let fileManager = FileManager.default
            var entries: [TarEntry] = []
            
            _ = baseURL.path
            
            guard let enumerator = fileManager.enumerator(at: directoryURL, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey], options: []) else {
                return Data()
            }

            let internalFilesToIgnore: Set<String> = [".permissions.plist", ".metadata.plist", ".symlinks.plist"]

                for case let fileURL as URL in enumerator {
                    let lastComponent = fileURL.lastPathComponent
                    
                    // 跳过内部文件与排除项
                    if internalFilesToIgnore.contains(lastComponent) {
                        continue
                    }
                    if excludedItems.contains(where: { fileURL.path.hasSuffix("/\($0)") || fileURL.path.contains("/\($0)/") }) {
                        continue
                    }
                    //跳过带.隐藏文件
                    if lastComponent.hasPrefix(".") || lastComponent.hasPrefix("._") { continue }

                    // ✅ 核心修正：生成正确的相对路径
                    var relativePath = fileURL.path.replacingOccurrences(of: baseURL.path, with: "")
                    if relativePath.hasPrefix("/") { relativePath.removeFirst() }
                    if relativePath.isEmpty { continue }

                    do {
                        var info: TarEntryInfo
                        var data = Data()

                        // 优先符号链接
                        if let linkDestination = symlinks[relativePath] {
                            info = TarEntryInfo(name: relativePath, type: .symbolicLink)
                            info.linkName = linkDestination
                            if let perms = permissions[relativePath] {
                                info.permissions = Permissions(rawValue: UInt32(perms))
                            } else {
                                info.permissions = Permissions(rawValue: 0o777)
                            }
                        } else {
                            let attrs = try fileManager.attributesOfItem(atPath: fileURL.path)
                            if let type = attrs[.type] as? FileAttributeType, type == .typeDirectory {
                                info = TarEntryInfo(name: relativePath, type: .directory)
                            } else {
                                info = TarEntryInfo(name: relativePath, type: .regular)
                                data = (try? Data(contentsOf: fileURL)) ?? Data()
                            }

                            // 权限设置
                            let lookupPath = baseURL.lastPathComponent == "DEBIAN"
                                ? "DEBIAN/\(relativePath)"
                                : relativePath

                            if let savedPerm = permissions[lookupPath] {
                                info.permissions = Permissions(rawValue: UInt32(savedPerm))
                            } else if let fsPerm = attrs[.posixPermissions] as? NSNumber {
                                info.permissions = Permissions(rawValue: fsPerm.uint32Value)
                            }
                        }
                        
                        // ✅ 恢复修改时间
                        if let modDate = try? fileManager.attributesOfItem(atPath: fileURL.path)[.modificationDate] as? Date {
                            info.modificationTime = modDate
                        }

                        entries.append(TarEntry(info: info, data: data))

                    } catch {
                        print("⚠️ 打包文件失败: \(fileURL.path), error: \(error)")
                        continue
                    }
                }

                return TarContainer.create(from: entries, force: .ustar)
            }
    }

fileprivate extension String {
    func replacingFirstOccurrence(of target: String, with replacement: String) -> String? {
        guard let range = self.range(of: target) else { return nil }
        return self.replacingCharacters(in: range, with: replacement)
    }
}
